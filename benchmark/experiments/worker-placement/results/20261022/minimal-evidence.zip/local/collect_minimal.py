"""Append minimal-replay evidence without changing the first raw archive."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
OUT=ROOT/'benchmark/experiments/worker-placement/results/20261022'
def sha(data):return hashlib.sha256(data).hexdigest()
first=json.loads((OUT/'manifest.json').read_text())
assert sha((OUT/'evidence.zip').read_bytes())==first['archive_sha256']
for name,entry in first['entries'].items():
    if name.startswith('repository/engine/'):
        assert sha((ROOT/name.removeprefix('repository/')).read_bytes())==entry['sha256']
replay=json.loads((BASE/'minimal-work-v2/replay.json').read_text())
assert replay['complete'] and not replay['sleep_events'] and len(replay['passes'])==12
assert replay['two_prompt_cold_reference_control']['metrics']['kernel_coverage_checked']
for p in replay['passes']:
    if p['variant']=='after':
        m=p['metrics']
        assert m['repeated_logits_exact'] and m['kernel_coverage_checked']
        assert m['expected_row_terms_prefill']==m['audited_row_terms_prefill']
        assert all(s['passed'] for s in p['stability'].values())
assert not replay['passes'][-1]['stability']['prefill']['passed']
target=OUT/'minimal-evidence.zip'
if target.exists():raise ValueError('Keep previous evidence')
entries={}
for folder in ('minimal-work','minimal-work-v2'):
    for p in (BASE/folder).rglob('*'):
        if p.is_file() and p.suffix in ('.json','.cpp','.h','.py') and 'tmp' not in p.relative_to(BASE).parts:
            entries['local/'+p.relative_to(BASE).as_posix()]=p
for name in ('minimal_work_probe.h','build_minimal_work.py','run_minimal_work.py','collect_minimal.py','trace-preflight.txt'):
    entries['local/'+name]=BASE/name
for name in ('scripts/trace_worker_spread.ps1','benchmark/experiments/worker-placement/replay_unmodified.py'):
    entries['repository/'+name]=ROOT/name
firmware=BASE/'firmware-power-events-private.json'
f=json.loads(firmware.read_text(encoding='utf-8-sig'))
manifest=dict(base_archive_sha256=first['archive_sha256'],release_ready=False,
    scope='Diagnostic minimal replay; no speed promotion; public engine unchanged since base archive',
    firmware_events=dict(raw_sha256=sha(firmware.read_bytes()),count=f['count'],start_utc=f['start_utc'],end_utc=f['end_utc'],
        note='No logged Event 37 does not rule out throttling; no temperature measurement'),
    administrator_trace=dict(preflight_passed=True,actual_recording_not_started=True,app_elevated=False),entries={})
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
    for name,p in sorted(entries.items()):
        data=p.read_bytes();archive.writestr(name,data)
        manifest['entries'][name]=dict(source=str(p),sha256=sha(data),bytes=len(data))
with zipfile.ZipFile(target) as archive:
    assert set(archive.namelist())==set(manifest['entries'])
    assert all(sha(archive.read(n))==e['sha256'] for n,e in manifest['entries'].items())
manifest['archive_sha256']=sha(target.read_bytes())
manifest['archive_bytes']=target.stat().st_size
(OUT/'minimal-manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
print('Verified supplemental archive:',len(entries),'entries;',manifest['archive_bytes'],'bytes;',manifest['archive_sha256'])
