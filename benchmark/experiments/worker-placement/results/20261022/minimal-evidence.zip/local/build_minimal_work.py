"""Retain repeated logits/work checks, removing PDH and dispatch profiling."""
import json
import os
from pathlib import Path
import subprocess
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from tools.validate_decoder import digest,write_record
from tools.decoder_validation import run_native

out=BASE/'minimal-work-v2'
out.mkdir(exist_ok=False)
os.environ['TEMP']=os.environ['TMP']=str(out)
previous=BASE/'native-clock-v4'
old=json.loads((previous/'build.json').read_text())
assert old['complete'] and old['full_logit_bit_exact']
for name in ('decoder.cpp','main_decoder.cpp'):
    data=(previous/name).read_bytes()
    if name=='main_decoder.cpp':
        before=b'diagnostic_counter_version\\\":4'
        assert data.count(before)==1
        data=data.replace(before,b'diagnostic_counter_version\\\":0')
        text=data.decode()
        before='                std::vector<float> reference_prefill, reference_decode;'
        assert text.count(before)==1
        text=text.replace(before,before+'''\n                {
                    leaf::runtime::Decoder independent(argv[1],1,scalar,activation_bits);
                    reference_prefill=independent.forward(prefix); reference_decode=independent.forward(last);
                }''')
        before='                    if (iteration==0) { reference_prefill=repeated_prefill; reference_decode=repeated_decode; }'
        assert text.count(before)==1
        text=text.replace(before,'')
        data=text.encode()
    else:
        text=data.decode()
        before='            packed_float_input.pack(input, tokens, weight.cols, weight.cols, vector_pack);'
        assert text.count(before)==1
        text=text.replace(before,before+'''\n            if (packed_float_input.tokens()!=tokens || packed_float_input.columns()!=weight.cols ||
                packed_float_input.panels()!=(tokens-1)/16+1) throw std::runtime_error("Packed input shape changed");
            leaf::diagnostics::expected_row_terms += std::uint64_t(weight.rows)*weight.cols*((tokens-1)/16+1)*16;''')
        data=text.encode()
    (out/name).write_bytes(data)
(out/'decoder_diagnostic.h').write_bytes((BASE/'minimal_work_probe.h').read_bytes())
row=ROOT/'engine/include/leaf/kernels/row_reuse.h'
row_text='#include "decoder_diagnostic.h"\n'+row.read_text()
before='        std::size_t output_stride, const float* b) {\n    if constexpr (NarrowTail) {'
assert row_text.count(before)==1
row_text=row_text.replace(before,'        std::size_t output_stride, const float* b) {\n'
    '    leaf::diagnostics::audited_row_terms += std::uint64_t(Rows)*columns*(NarrowTail && count<=8 ? 8 : 16);\n'
    '    if constexpr (NarrowTail) {')
private_row=out/'include/leaf/kernels/row_reuse.h'
private_row.parent.mkdir(parents=True)
private_row.write_text(row_text,newline='\n')
sources=[out/'decoder.cpp',out/'main_decoder.cpp',ROOT/'engine/src/kv_cache.cpp',ROOT/'engine/src/kernels/transformer.cpp']
paths=[*sources,*sorted((ROOT/'engine/include').rglob('*.h')),out/'decoder_diagnostic.h',private_row,Path(__file__),previous/'build.json']
binary=out/'leaf_decoder.exe'
command=['C:/msys64/mingw64/bin/g++.exe','-std=c++17','-O3','-DNDEBUG','-DLEAF_DIAGNOSTIC_TIMING=1','-pthread',
    '-I',str(out),'-I',str(out/'include'),'-I',str(ROOT/'engine/include'),*map(str,sources),'-o',str(binary),
    '-static','-static-libgcc','-static-libstdc++','-lpsapi']
record=dict(complete=False,acceptance_timing=False,inputs={str(p):digest(p) for p in paths},command=command)
write_record(out/'build.json',record)
try:
    subprocess.run(command,check=True)
    imports=subprocess.check_output(['C:/msys64/mingw64/bin/objdump.exe','-p',str(binary)],text=True)
    assert not any(name.lower() in imports.lower() for name in ('pdh.dll','EnableThreadProfiling','ReadThreadProfilingData'))
    record['no_pdh_or_dispatch_imports']=True
    artifact=Path(json.loads((ROOT/'build/source-bf16-20261020/prepared.json').read_text())['models']['smol']['before'])
    tokens=ROOT/'build/numerics-20261017/decode-silu/smol-work/tokens.json'
    ordinary=Path((BASE/'final-runtime.txt').read_text().strip())
    ids=json.loads(tokens.read_text())['benchmark_ids'][:33]
    record['parity_hashes']={str(p):digest(p) for p in (artifact,tokens,ordinary,binary)}
    a,_=run_native(ordinary,artifact,[ids],threads=1)
    b,_=run_native(binary,artifact,[ids],threads=1)
    record['full_logit_bit_exact']=bool(np.array_equal(a.view('<u4'),b.view('<u4')))
    assert record['full_logit_bit_exact']
    assert all(digest(Path(p))==h for p,h in record['inputs'].items())
    record.update(complete=True,binary_sha256=digest(binary))
    print('Minimal audit built: exact logits; no PDH or thread-profiling imports',flush=True)
except BaseException as error:
    record['error']=repr(error)
    raise
finally:
    write_record(out/'build.json',record)
