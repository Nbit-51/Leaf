"""Replay the twelve-pass launch pattern with minimal instrumentation AFTER.

Diagnostic only: no PDH, Windows dispatch profiling or operator timing scopes.
Cold independent references check reset/output integrity. Packed-kernel tile
coverage is checked against requested work. Raw samples are never filtered.
"""
import importlib.util
import json
import os
from pathlib import Path
import statistics
import sys
import numpy as np
import psutil

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from leaf.power import keep_awake
from tools.decoder_validation import run_native,latency_stability
from tools.validate_decoder import digest,utc_now,write_record

directory=BASE/'minimal-work-v2'
report=directory/'replay.json'
if report.exists():raise ValueError('Retain previous replay')
build=json.loads((directory/'build.json').read_text())
binary=directory/'leaf_decoder.exe'
assert build['complete'] and build['full_logit_bit_exact'] and build['no_pdh_or_dispatch_imports']
assert digest(binary)==build['binary_sha256']
assert all(digest(Path(p))==h for p,h in build['inputs'].items())
prepared=ROOT/'build/source-bf16-20261020/prepared.json'
baseline=ROOT/'build/source-bf16-20261020/default/leaf_decoder.exe'
row=json.loads(prepared.read_text())['models']['smol']
artifact=Path(row['before'])
assert digest(artifact)==row['before_sha256']
tokens=ROOT/'build/numerics-20261017/decode-silu/smol-work/tokens.json'
ids=json.loads(tokens.read_text())['benchmark_ids']
other_tokens=ROOT/'build/linear-accumulation-20261019-pipeline/full-quality-smol/tokens.json'
other=json.loads(other_tokens.read_text())['sequences'][1][:64]
guard_source=ROOT/'benchmark/experiments/source-bf16/integration.py'
paths=[binary,baseline,directory/'build.json',prepared,artifact,tokens,other_tokens,Path(__file__),
       ROOT/'tools/decoder_validation.py',ROOT/'leaf/power.py',guard_source]
record=dict(complete=False,acceptance_timing=False,scope=__doc__,utc=utc_now(),
    hashes={str(p):digest(p) for p in paths},passes=[])
write_record(report,record)
scratch=directory/'tmp';scratch.mkdir(exist_ok=True)
os.environ['TEMP']=os.environ['TMP']=str(scratch)
import tempfile
tempfile.tempdir=str(scratch)
os.environ['LEAF_BENCHMARK_REQUIRE_AC']='1'
spec=importlib.util.spec_from_file_location('minimal_work_guards',guard_source)
guards=importlib.util.module_from_spec(spec);spec.loader.exec_module(guards)
me=psutil.Process();affinity,priority=me.cpu_affinity(),me.nice()

def check_metrics(m,count):
    assert m['minimal_work_build'] and m['repeated_logits_exact'] and m['kernel_coverage_checked']
    assert m['thread_dispatch_supported'] is False and m['clock_counters_supported'] is False
    for phase in ('prefill','decode'):
        for field in ('logical_cpu_start_','logical_cpu_end_'):
            assert m[field+phase]==[2]*count
        for field in ('audited_linear_calls_','audited_linear_terms_'):
            assert len(m[field+phase])==count and min(m[field+phase])>0
        assert m['expected_row_terms_'+phase]==m['audited_row_terms_'+phase]
    assert min(m['audited_row_terms_prefill'])>0

try:
    me.cpu_affinity([2]);me.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
    with keep_awake(display=True):
        with guards.power_window() as power:
            _,m=run_native(binary,artifact,[ids,other],threads=1,mode='bench',runs=1,warmup=0,windows_above_normal=True)
        record['two_prompt_cold_reference_control']=dict(metrics=m,power=power)
        write_record(report,record);check_metrics(m,2)
        print('Two distinct prompts match independent cold references and packed-kernel coverage',flush=True)
        for index,variant in enumerate(['before','after','after','before']*3):
            with guards.power_window() as power:
                _,m=run_native(baseline if variant=='before' else binary,artifact,[ids],threads=1,
                    mode='bench',runs=31,warmup=10,windows_above_normal=True)
            item=dict(index=index,variant=variant,metrics=m,power=power,
                      stability={p:latency_stability(m[p+'_samples_ms']) for p in ('prefill','decode')})
            record['passes'].append(item);write_record(report,record)
            assert m['benchmark_ac_checked'] and m.get('worker_spin_us',0)==0
            if variant=='after':check_metrics(m,31)
            print(index+1,variant,{p:dict(wall_ms=m[p+'_p50_ms'],spread=item['stability'][p]['p90_p10_ratio'],
                cpu_ms=statistics.median(m['thread_cpu_'+p+'_ms']) if variant=='after' else None,
                wall_tick_ms=statistics.median(m['wall_tick_ms_'+p]) if variant=='after' else None)
                for p in ('prefill','decode')},flush=True)
        record['sleep_events']=guards.sleep_events(record['utc'])
    assert all(digest(Path(p))==h for p,h in record['hashes'].items())
    record['complete']=True
except BaseException as error:
    record['error']=repr(error);raise
finally:
    me.cpu_affinity(affinity);me.nice(priority);write_record(report,record)
