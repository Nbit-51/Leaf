"""Retain repeated logits/work checks, removing PDH and dispatch profiling."""
import json
import os
from pathlib import Path
import subprocess
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from tools.validate_decoder import digest,write_record
from tools.decoder_validation import run_native

out=BASE/'minimal-work'
out.mkdir(exist_ok=False)
os.environ['TEMP']=os.environ['TMP']=str(out)
previous=BASE/'native-clock-v4'
old=json.loads((previous/'build.json').read_text())
assert old['complete'] and old['full_logit_bit_exact']
for name in ('decoder.cpp','main_decoder.cpp'):
    data=(previous/name).read_bytes()
    if name=='main_decoder.cpp':
        before=b'diagnostic_counter_version\\\":4'
        assert data.count(before)==1
        data=data.replace(before,b'diagnostic_counter_version\\\":0')
    (out/name).write_bytes(data)
(out/'decoder_diagnostic.h').write_bytes((BASE/'minimal_work_probe.h').read_bytes())
sources=[out/'decoder.cpp',out/'main_decoder.cpp',ROOT/'engine/src/kv_cache.cpp',ROOT/'engine/src/kernels/transformer.cpp']
paths=[*sources,*sorted((ROOT/'engine/include').rglob('*.h')),out/'decoder_diagnostic.h',Path(__file__),previous/'build.json']
binary=out/'leaf_decoder.exe'
command=['C:/msys64/mingw64/bin/g++.exe','-std=c++17','-O3','-DNDEBUG','-DLEAF_DIAGNOSTIC_TIMING=1','-pthread',
    '-I',str(out),'-I',str(ROOT/'engine/include'),*map(str,sources),'-o',str(binary),
    '-static','-static-libgcc','-static-libstdc++','-lpsapi']
record=dict(complete=False,acceptance_timing=False,inputs={str(p):digest(p) for p in paths},command=command)
write_record(out/'build.json',record)
try:
    subprocess.run(command,check=True)
    imports=subprocess.check_output(['C:/msys64/mingw64/bin/objdump.exe','-p',str(binary)],text=True)
    assert not any(name.lower() in imports.lower() for name in ('pdh.dll','EnableThreadProfiling','ReadThreadProfilingData'))
    record['no_pdh_or_dispatch_imports']=True
    artifact=Path(json.loads((ROOT/'build/source-bf16-20261020/prepared.json').read_text())['models']['smol']['before'])
    tokens=ROOT/'build/numerics-20261017/decode-silu/smol-work/tokens.json'
    ordinary=Path((BASE/'final-runtime.txt').read_text().strip())
    ids=json.loads(tokens.read_text())['benchmark_ids'][:33]
    record['parity_hashes']={str(p):digest(p) for p in (artifact,tokens,ordinary,binary)}
    a,_=run_native(ordinary,artifact,[ids],threads=1)
    b,_=run_native(binary,artifact,[ids],threads=1)
    record['full_logit_bit_exact']=bool(np.array_equal(a.view('<u4'),b.view('<u4')))
    assert record['full_logit_bit_exact']
    assert all(digest(Path(p))==h for p,h in record['inputs'].items())
    record.update(complete=True,binary_sha256=digest(binary))
    print('Minimal audit built: exact logits; no PDH or thread-profiling imports',flush=True)
except BaseException as error:
    record['error']=repr(error)
    raise
finally:
    write_record(out/'build.json',record)
