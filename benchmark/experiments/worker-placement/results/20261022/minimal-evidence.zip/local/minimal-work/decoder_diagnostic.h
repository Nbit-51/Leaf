#pragma once
#include <windows.h>
#include <psapi.h>
#include <cstdint>
#include <ostream>
#include <stdexcept>
#include <vector>
namespace leaf::diagnostics {
inline std::uint64_t audited_linear_calls=0, audited_linear_terms=0;
// Deliberately no PDH or EnableThreadProfiling/ReadThreadProfilingData calls.
class ThreadDispatch {};
enum Part : unsigned { MlpTotal, OtherTotal, MlpPack, OtherPack, Parts };
class Scope { public: Scope(std::size_t,Part) {} };
inline std::uint64_t ticks(FILETIME t) { return (std::uint64_t(t.dwHighDateTime)<<32)|t.dwLowDateTime; }
struct Stamp {
    std::uint64_t cpu,cycles,tick_ms,linear_calls,linear_terms;
    DWORD faults,logical_cpu;
};
inline Stamp stamp() {
    FILETIME created{},exited{},kernel{},user{};
    ULONG64 cycles=0;
    PROCESS_MEMORY_COUNTERS memory{}; memory.cb=sizeof(memory);
    if (!GetThreadTimes(GetCurrentThread(),&created,&exited,&kernel,&user) ||
        !QueryThreadCycleTime(GetCurrentThread(),&cycles) ||
        !GetProcessMemoryInfo(GetCurrentProcess(),&memory,sizeof(memory)))
        throw std::runtime_error("Cannot read minimal thread/work audit");
    return {ticks(kernel)+ticks(user),cycles,GetTickCount64(),audited_linear_calls,audited_linear_terms,
            memory.PageFaultCount,GetCurrentProcessorNumber()};
}
struct Samples {
    std::vector<double> cpu_ms;
    std::vector<std::uint64_t> cycles,tick_ms,linear_calls,linear_terms;
    std::vector<DWORD> faults,cpu_start,cpu_end;
    void reserve(std::size_t n) {
        cpu_ms.reserve(n);cycles.reserve(n);tick_ms.reserve(n);linear_calls.reserve(n);linear_terms.reserve(n);
        faults.reserve(n);cpu_start.reserve(n);cpu_end.reserve(n);
    }
    void add(const Stamp& a,const Stamp& b) {
        if (b.cpu<a.cpu || b.cycles<a.cycles || b.tick_ms<a.tick_ms || b.linear_calls<a.linear_calls || b.linear_terms<a.linear_terms)
            throw std::runtime_error("Nonmonotonic minimal audit");
        cpu_ms.push_back(double(b.cpu-a.cpu)/1e4);cycles.push_back(b.cycles-a.cycles);tick_ms.push_back(b.tick_ms-a.tick_ms);
        linear_calls.push_back(b.linear_calls-a.linear_calls);linear_terms.push_back(b.linear_terms-a.linear_terms);
        faults.push_back(b.faults-a.faults);cpu_start.push_back(a.logical_cpu);cpu_end.push_back(b.logical_cpu);
    }
};
template<class T> inline void values(std::ostream& out,const std::vector<T>& v) {
    out<<'[';for(std::size_t i=0;i<v.size();++i)out<<(i?",":"")<<v[i];out<<']';
}
inline void emit(std::ostream& out,const Samples& prefill,const Samples& decode) {
    out<<",\"diagnostic_timing_build\":true,\"diagnostic_counter_version\":0,\"minimal_work_build\":true,\"repeated_logits_exact\":true"
          ",\"thread_dispatch_supported\":false,\"clock_counters_supported\":false";
    out<<",\"thread_cpu_prefill_ms\":";values(out,prefill.cpu_ms);
    out<<",\"thread_cpu_decode_ms\":";values(out,decode.cpu_ms);
    out<<",\"thread_cycles_prefill\":";values(out,prefill.cycles);
    out<<",\"thread_cycles_decode\":";values(out,decode.cycles);
    out<<",\"wall_tick_ms_prefill\":";values(out,prefill.tick_ms);
    out<<",\"wall_tick_ms_decode\":";values(out,decode.tick_ms);
    out<<",\"logical_cpu_start_prefill\":";values(out,prefill.cpu_start);
    out<<",\"logical_cpu_end_prefill\":";values(out,prefill.cpu_end);
    out<<",\"logical_cpu_start_decode\":";values(out,decode.cpu_start);
    out<<",\"logical_cpu_end_decode\":";values(out,decode.cpu_end);
    out<<",\"process_page_faults_prefill\":";values(out,prefill.faults);
    out<<",\"process_page_faults_decode\":";values(out,decode.faults);
    out<<",\"audited_linear_calls_prefill\":";values(out,prefill.linear_calls);
    out<<",\"audited_linear_calls_decode\":";values(out,decode.linear_calls);
    out<<",\"audited_linear_terms_prefill\":";values(out,prefill.linear_terms);
    out<<",\"audited_linear_terms_decode\":";values(out,decode.linear_terms);
}
}
