"""Retain small raw records/sources; omit weights, logits, binaries and installs."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
OUT=ROOT/'benchmark/experiments/worker-placement/results/20261022'

def sha(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_text())

required=['model/quality.json','model/default.json','jobs-model/quality.json',
    'jobs-ordinary-regression.json','spin-model/quality.json','spin-model/synchronization.json',
    'spin-ordinary-regression.json','final-ordinary-regression.json']
for name in required:
    r=load(BASE/name)
    if not (r['complete'] and r['passed']):raise ValueError('Incomplete/failed required record: '+name)
for name in ('model/placement.json','jobs-model/jobs.json','final-default-model/ordinary.json'):
    r=load(BASE/name)
    if not r['complete'] or r['passed']:raise ValueError('Expected retained failed joint gate: '+name)
for name in ('remaining-jitter','queue-jitter','spin-jitter'):
    r=load(BASE/name/'smol-diagnostic.json')
    if not r['complete'] or r['sleep_events'] or not r['full_logit_bit_exact']:
        raise ValueError('Diagnostic incomplete: '+name)
units=ET.parse(BASE/'units-spin-final.xml').getroot()
if any(int(x.get('failures','0')) or int(x.get('errors','0')) for x in units.iter('testsuite')):
    raise ValueError('Unit failures')
if not load(BASE/'final-installed-check.json')['passed']:raise ValueError('Installed smoke failed')
if len(load(BASE/'architectures-final.json')['results'])!=10:raise ValueError('Architecture coverage changed')
audit=load(BASE/'native-clock-v4/audit.json')
if not audit['complete'] or audit['sleep_events'] or len(audit['passes'])!=4:raise ValueError('Native audit incomplete')

skip={'installed','final-installed','installed-model','final-installed-model',
      'installed-cache','final-installed-cache','final-wheels','wheels',
      'units-all','units-final','unit-focused'}
entries={}
for p in BASE.rglob('*'):
    if not p.is_file():continue
    relative=p.relative_to(BASE)
    if p.name=='environment-private.json':continue
    if any(part in skip or part=='tmp' or part.endswith('-tmp') or part.endswith('-cache')
           or part.startswith(('pip-','evidence-')) or part=='__pycache__' or part=='native' for part in relative.parts):continue
    if p.suffix not in ('.json','.xml','.py','.h','.cpp','.txt'):continue
    entries['local/'+relative.as_posix()]=p
for name in ('prepared.json','quality.json'):
    entries['prior/source-bf16/'+name]=ROOT/'build/source-bf16-20261020'/name
for model in ('smol','qwen'):
    for name in ('tokens.json','quality.json'):
        entries['prior/full-quality-'+model+'/'+name]=ROOT/'build/linear-accumulation-20261019-pipeline'/('full-quality-'+model)/name
for folder in ('engine','benchmark/experiments/worker-placement'):
    for p in (ROOT/folder).rglob('*'):
        if p.is_file() and p.suffix in ('.h','.cpp','.py','.txt') and 'results' not in p.relative_to(ROOT).parts:
            entries['repository/'+p.relative_to(ROOT).as_posix()]=p
for name in ('tools/decoder_validation.py','tools/validate_decoder.py','tools/benchmark_core_scaling.py',
             'tools/diagnose_windows_benchmark.py','leaf/affinity.py','leaf/power.py','leaf/cli.py',
             'tests/native/test_worker_affinity.cpp','tests/native/decoder_diagnostic.h',
             'tests/unit/test_worker_placement.py','setup.py','pyproject.toml'):
    entries['repository/'+name]=ROOT/name

OUT.mkdir(parents=True,exist_ok=False)
manifest=dict(scope='Raw evidence, including failed controls; no weights/logits/binaries',
    release_ready=False,qualified_scope='Assigned four-core synchronization comparison, accurate K=256 FP32, Windows',
    unresolved=['ordinary one-core spread guard','ordinary Smol/Qwen strict logit tolerance'],entries={})
with zipfile.ZipFile(OUT/'evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for entry,p in sorted(entries.items()):
        data=p.read_bytes()
        archive.writestr(entry,data)
        manifest['entries'][entry]=dict(source=str(p),sha256=sha(data),bytes=len(data))
with zipfile.ZipFile(OUT/'evidence.zip') as archive:
    if set(archive.namelist())!=set(manifest['entries']):raise ValueError('Archive inventory mismatch')
    for name,info in manifest['entries'].items():
        if sha(archive.read(name))!=info['sha256']:raise ValueError('Archive changed bytes: '+name)
manifest['archive_sha256']=sha((OUT/'evidence.zip').read_bytes())
manifest['archive_bytes']=(OUT/'evidence.zip').stat().st_size
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
summary={name:{k:load(BASE/name).get(k) for k in ('complete','passed','sleep_events')}
    for name in ('model/placement.json','model/default.json','jobs-model/jobs.json',
                 'spin-model/synchronization.json','final-default-model/ordinary.json')}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'.gitattributes').write_text('* -text\n')
print('Verified',len(entries),'raw entries;',manifest['archive_bytes'],'bytes;',manifest['archive_sha256'])
