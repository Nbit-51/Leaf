"""Private native-loop clock/work/logit audit, without an external sampler."""
import json
import os
from pathlib import Path
import subprocess
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from tools.validate_decoder import digest,write_record
from tools.decoder_validation import run_native

def once(text,before,after):
    if text.count(before)!=1:raise ValueError('Inspect clock-audit source anchor: '+before[:65])
    return text.replace(before,after)

out=BASE/'native-clock-v4'
out.mkdir(exist_ok=False)
os.environ['TEMP']=os.environ['TMP']=str(out)
header=ROOT/'tests/native/decoder_diagnostic.h'
text='#include "native_clock_probe.h"\n'+header.read_text()
text=once(text,'    DWORD page_faults, logical_cpu, context_switches;',
    '    DWORD page_faults, logical_cpu, context_switches;\n    double performance, sibling_busy, clock_age;\n    std::uint64_t linear_calls, linear_terms;')
text=once(text,'    return {value(kernel)',
    '    const auto clocks=native_clock_read();\n    return {value(kernel)')
text=once(text,'memory.PageFaultCount, GetCurrentProcessorNumber(), dispatch.ContextSwitchCount};',
    'memory.PageFaultCount, GetCurrentProcessorNumber(), dispatch.ContextSwitchCount, clocks.performance, clocks.sibling_busy, clocks.age_seconds, audited_linear_calls, audited_linear_terms};')
text=once(text,'    void reserve(std::size_t count) {',
    '    std::vector<double> performance_start, performance_end, sibling_busy_start, sibling_busy_end, clock_age;\n'
    '    std::vector<std::uint64_t> linear_calls, linear_terms;\n    void reserve(std::size_t count) {')
text=once(text,'        cpu_ms.push_back(double(after.cpu_100ns',
    '        performance_start.push_back(before.performance); performance_end.push_back(after.performance);\n'
    '        sibling_busy_start.push_back(before.sibling_busy); sibling_busy_end.push_back(after.sibling_busy);\n'
    '        clock_age.push_back(after.clock_age);\n'
    '        linear_calls.push_back(after.linear_calls-before.linear_calls); linear_terms.push_back(after.linear_terms-before.linear_terms);\n'
    '        cpu_ms.push_back(double(after.cpu_100ns')
text=once(text,'    out << ",\\\"diagnostic_timing_build\\\":true,\\\"thread_cpu_prefill_ms\\\":";',
    '''    out << ",\\\"native_clock_build\\\":true,\\\"repeated_logits_exact\\\":true";
    out << ",\\\"performance_start_prefill\\\":"; values(out,prefill.performance_start);
    out << ",\\\"performance_end_prefill\\\":"; values(out,prefill.performance_end);
    out << ",\\\"performance_end_decode\\\":"; values(out,decode.performance_end);
    out << ",\\\"sibling_busy_end_prefill\\\":"; values(out,prefill.sibling_busy_end);
    out << ",\\\"sibling_busy_end_decode\\\":"; values(out,decode.sibling_busy_end);
    out << ",\\\"clock_age_end_prefill\\\":"; values(out,prefill.clock_age);
    out << ",\\\"clock_age_end_decode\\\":"; values(out,decode.clock_age);
    out << ",\\\"audited_linear_calls_prefill\\\":"; values(out,prefill.linear_calls);
    out << ",\\\"audited_linear_calls_decode\\\":"; values(out,decode.linear_calls);
    out << ",\\\"audited_linear_terms_prefill\\\":"; values(out,prefill.linear_terms);
    out << ",\\\"audited_linear_terms_decode\\\":"; values(out,decode.linear_terms);
    out << ",\\\"diagnostic_timing_build\\\":true,\\\"thread_cpu_prefill_ms\\\":";''')
(out/'decoder_diagnostic.h').write_text(text,newline='\n')
(out/'native_clock_probe.h').write_bytes((BASE/'native_clock_probe.h').read_bytes())
decoder=(ROOT/'engine/src/decoder.cpp').read_text().replace('"../../tests/native/decoder_diagnostic.h"','"decoder_diagnostic.h"')
decoder=once(decoder,'        const auto& weight = weights.at(name + ".weight");',
    '        const auto& weight = weights.at(name + ".weight");\n'
    '        ++leaf::diagnostics::audited_linear_calls;\n'
    '        leaf::diagnostics::audited_linear_terms += std::uint64_t(tokens)*weight.rows*weight.cols;')
(out/'decoder.cpp').write_text(decoder,newline='\n')
main='#include <cstring>\n'+(ROOT/'engine/src/main_decoder.cpp').read_text().replace('"../../tests/native/decoder_diagnostic.h"','"decoder_diagnostic.h"')
main=once(main,'                for (unsigned iteration = 0; iteration < runs + warmup; ++iteration) {',
    '                std::vector<float> reference_prefill, reference_decode;\n'
    '                for (unsigned iteration = 0; iteration < runs + warmup; ++iteration) {')
main=once(main,'                    auto start = Clock::now(); decoder.forward(prefix); const double prefill = elapsed(start);',
    '                    auto start = Clock::now(); auto repeated_prefill=decoder.forward(prefix); const double prefill = elapsed(start);')
main=once(main,'start = Clock::now(); decoder.forward(last); const double decode = elapsed(start);\n                    const auto cpu_end',
    'start = Clock::now(); auto repeated_decode=decoder.forward(last); const double decode = elapsed(start);\n                    const auto cpu_end')
main=once(main,'                    const auto cpu_end = leaf::diagnostics::stamp();',
    '''                    const auto cpu_end = leaf::diagnostics::stamp();
                    if (iteration==0) { reference_prefill=repeated_prefill; reference_decode=repeated_decode; }
                    if (reference_prefill.size()!=repeated_prefill.size() || reference_decode.size()!=repeated_decode.size() ||
                        std::memcmp(reference_prefill.data(),repeated_prefill.data(),repeated_prefill.size()*sizeof(float)) ||
                        std::memcmp(reference_decode.data(),repeated_decode.data(),repeated_decode.size()*sizeof(float)))
                        throw std::runtime_error("Repeated prefix/decode logits changed after reset");''')
(out/'main_decoder.cpp').write_text(main,newline='\n')
sources=[out/'decoder.cpp',out/'main_decoder.cpp',ROOT/'engine/src/kv_cache.cpp',ROOT/'engine/src/kernels/transformer.cpp']
inputs=[*sources,*sorted((ROOT/'engine/include').rglob('*.h')),header,out/'decoder_diagnostic.h',out/'native_clock_probe.h',Path(__file__)]
binary=out/'leaf_decoder.exe'
command=['C:/msys64/mingw64/bin/g++.exe','-std=c++17','-O3','-DNDEBUG','-DLEAF_DIAGNOSTIC_TIMING=1','-pthread',
    '-I',str(out),'-I',str(ROOT/'engine/include'),*map(str,sources),'-o',str(binary),
    '-static','-static-libgcc','-static-libstdc++','-lpsapi','-lpdh']
record=dict(complete=False,acceptance_timing=False,inputs={str(p):digest(p) for p in inputs},command=command)
write_record(out/'build.json',record)
try:
    subprocess.run(command,check=True)
    prepared=ROOT/'build/source-bf16-20261020/prepared.json'
    artifact=Path(json.loads(prepared.read_text())['models']['smol']['before'])
    tokens=ROOT/'build/numerics-20261017/decode-silu/smol-work/tokens.json'
    ordinary=Path((BASE/'final-runtime.txt').read_text().strip())
    ids=json.loads(tokens.read_text())['benchmark_ids'][:33]
    record['parity_hashes']={str(p):digest(p) for p in (prepared,artifact,tokens,ordinary,binary)}
    a,_=run_native(ordinary,artifact,[ids],threads=1)
    b,_=run_native(binary,artifact,[ids],threads=1)
    record['full_logit_bit_exact']=bool(np.array_equal(a.view('<u4'),b.view('<u4')))
    assert record['full_logit_bit_exact']
    assert all(digest(Path(p))==h for p,h in record['inputs'].items())
    record.update(complete=True,binary_sha256=digest(binary))
    print('Built native clock/work/repeated-logit audit; full 33-token logits match',flush=True)
except BaseException as error:
    record['error']=repr(error)
    raise
finally:
    write_record(out/'build.json',record)
