#pragma once
#include <pdh.h>
#include <pdhmsg.h>
#include <cstdint>
#include <stdexcept>
namespace leaf::diagnostics {
inline std::uint64_t audited_linear_calls=0, audited_linear_terms=0;
struct ClockReading { double performance, sibling_busy; };
class NativeClockProbe {
    PDH_HQUERY query_{};
    PDH_HCOUNTER performance_{}, sibling_{};
    static double value(PDH_HCOUNTER counter) {
        PDH_FMT_COUNTERVALUE result{};
        const auto status=PdhGetFormattedCounterValue(counter, PDH_FMT_DOUBLE|PDH_FMT_NOCAP100, nullptr, &result);
        if (status || (result.CStatus!=PDH_CSTATUS_VALID_DATA && result.CStatus!=PDH_CSTATUS_NEW_DATA)) return -1;
        return result.doubleValue;
    }
public:
    NativeClockProbe() {
        // Machine-specific diagnostic: CPU 2 and its checked SMT sibling 3.
        if (PdhOpenQueryW(nullptr,0,&query_)) throw std::runtime_error("Cannot open native clock query");
        if (PdhAddEnglishCounterW(query_,LR"(\Processor Information(0,2)\% Processor Performance)",0,&performance_) ||
            PdhAddEnglishCounterW(query_,LR"(\Processor Information(0,3)\% Processor Time)",0,&sibling_) ||
            PdhCollectQueryData(query_)) {
            PdhCloseQuery(query_); throw std::runtime_error("Cannot initialize native clock counters");
        }
    }
    ~NativeClockProbe() { PdhCloseQuery(query_); }
    ClockReading read() {
        if (PdhCollectQueryData(query_)) throw std::runtime_error("Cannot collect native clock counters");
        return {value(performance_),value(sibling_)};
    }
};
inline ClockReading native_clock_read() { static NativeClockProbe probe; return probe.read(); }
}
