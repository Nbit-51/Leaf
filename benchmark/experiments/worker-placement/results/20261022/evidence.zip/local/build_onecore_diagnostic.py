"""Private dispatch/clock diagnostic for the new unbound one-core variation."""
import json
import os
from pathlib import Path
import subprocess
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from tools.validate_decoder import digest,write_record
from tools.decoder_validation import run_native

out=BASE/'one-core-env'
out.mkdir(exist_ok=False)
os.environ['TEMP']=os.environ['TMP']=str(out)
sources=[ROOT/'engine'/p for p in ('src/decoder.cpp','src/main_decoder.cpp','src/kv_cache.cpp','src/kernels/transformer.cpp')]
inputs=[*sources,*sorted((ROOT/'engine/include').rglob('*.h')),ROOT/'tests/native/decoder_diagnostic.h',Path(__file__)]
binary=out/'leaf_decoder.exe'
command=['C:/msys64/mingw64/bin/g++.exe','-std=c++17','-O3','-DNDEBUG','-DLEAF_DIAGNOSTIC_TIMING=1','-pthread',
    '-I',str(ROOT/'engine/include'),'-I',str(ROOT/'tests/native'),*map(str,sources),'-o',str(binary),
    '-static','-static-libgcc','-static-libstdc++','-lpsapi']
record=dict(complete=False,acceptance_timing=False,inputs={str(p):digest(p) for p in inputs},command=command)
write_record(out/'build.json',record)
try:
    subprocess.run(command,check=True)
    info=json.loads(subprocess.check_output([str(binary),'--runtime-info'],text=True))
    assert info['diagnostic_counter_version']==4
    prepared=ROOT/'build/source-bf16-20261020/prepared.json'
    artifact=Path(json.loads(prepared.read_text())['models']['smol']['before'])
    tokens=ROOT/'build/numerics-20261017/decode-silu/smol-work/tokens.json'
    ordinary=Path((BASE/'final-runtime.txt').read_text().strip())
    ids=json.loads(tokens.read_text())['benchmark_ids'][:33]
    record['parity_hashes']={str(p):digest(p) for p in (prepared,artifact,tokens,ordinary,binary)}
    a,_=run_native(ordinary,artifact,[ids],threads=1)
    b,_=run_native(binary,artifact,[ids],threads=1)
    record['full_logit_bit_exact']=bool(np.array_equal(a.view('<u4'),b.view('<u4')))
    assert record['full_logit_bit_exact']
    assert all(digest(Path(p))==h for p,h in record['inputs'].items())
    record.update(complete=True,binary_sha256=digest(binary),runtime_info=info)
    print('Built private version-4 diagnostic; all 33-token logits match final ordinary runtime',flush=True)
except BaseException as error:
    record['error']=repr(error)
    raise
finally:
    write_record(out/'build.json',record)
