#pragma once
#include <pdh.h>
#include <pdhmsg.h>
#include <cstdint>
#include <chrono>
#include <stdexcept>
namespace leaf::diagnostics {
inline std::uint64_t audited_linear_calls=0, audited_linear_terms=0;
struct ClockReading { double performance, sibling_busy, age_seconds; };
class NativeClockProbe {
    PDH_HQUERY query_{};
    PDH_HCOUNTER performance_{}, sibling_{};
    std::chrono::steady_clock::time_point last_collect_=std::chrono::steady_clock::now(), last_valid_=last_collect_;
    double cached_performance_=-1, cached_sibling_=-1;
    static double value(PDH_HCOUNTER counter) {
        PDH_FMT_COUNTERVALUE result{};
        const auto status=PdhGetFormattedCounterValue(counter, PDH_FMT_DOUBLE|PDH_FMT_NOCAP100, nullptr, &result);
        if (status || (result.CStatus!=PDH_CSTATUS_VALID_DATA && result.CStatus!=PDH_CSTATUS_NEW_DATA)) return -1;
        return result.doubleValue;
    }
public:
    NativeClockProbe() {
        // Machine-specific diagnostic: CPU 2 and its checked SMT sibling 3.
        if (PdhOpenQueryW(nullptr,0,&query_)) throw std::runtime_error("Cannot open native clock query");
        if (PdhAddEnglishCounterW(query_,LR"(\Processor Information(0,2)\% Processor Performance)",0,&performance_) ||
            PdhAddEnglishCounterW(query_,LR"(\Processor Information(0,3)\% Processor Time)",0,&sibling_) ||
            PdhCollectQueryData(query_)) {
            PdhCloseQuery(query_); throw std::runtime_error("Cannot initialize native clock counters");
        }
    }
    ~NativeClockProbe() { PdhCloseQuery(query_); }
    ClockReading read() {
        const auto now=std::chrono::steady_clock::now();
        // These rate counters do not refresh once per model operation.
        // Keep a valid >=1-second interval and report the cached reading's age.
        if (now-last_collect_>=std::chrono::milliseconds(1100)) {
            if (PdhCollectQueryData(query_)) throw std::runtime_error("Cannot collect native clock counters");
            const auto performance=value(performance_), sibling=value(sibling_);
            if (performance>=0 && sibling>=0) {
                cached_performance_=performance; cached_sibling_=sibling; last_valid_=now;
            }
            last_collect_=now;
        }
        return {cached_performance_,cached_sibling_,std::chrono::duration<double>(now-last_valid_).count()};
    }
};
inline ClockReading native_clock_read() { static NativeClockProbe probe; return probe.read(); }
}
