"""A/A operation/logit/clock audit; diagnostic only, no external PDH sampler."""
import importlib.util
import json
import os
from pathlib import Path
import statistics
import sys
import numpy as np
import psutil

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from leaf.power import keep_awake
from tools.decoder_validation import run_native,latency_stability
from tools.validate_decoder import digest,utc_now,write_record

directory=BASE/'native-clock-v4'
report=directory/'audit.json'
if report.exists():raise ValueError('Retain previous audit')
build=json.loads((directory/'build.json').read_text())
binary=directory/'leaf_decoder.exe'
assert build['complete'] and build['full_logit_bit_exact'] and digest(binary)==build['binary_sha256']
assert all(digest(Path(p))==h for p,h in build['inputs'].items())
prepared=ROOT/'build/source-bf16-20261020/prepared.json'
row=json.loads(prepared.read_text())['models']['smol']
artifact=Path(row['before'])
assert digest(artifact)==row['before_sha256']
tokens=ROOT/'build/numerics-20261017/decode-silu/smol-work/tokens.json'
ids=json.loads(tokens.read_text())['benchmark_ids']
paths=[binary,directory/'build.json',prepared,artifact,tokens,Path(__file__),ROOT/'tools/decoder_validation.py',ROOT/'leaf/power.py']
record=dict(complete=False,acceptance_timing=False,no_external_sampler=True,utc=utc_now(),
    scope=__doc__,hashes={str(p):digest(p) for p in paths},passes=[])
write_record(report,record)
scratch=directory/'tmp'
scratch.mkdir(exist_ok=True)
os.environ['TEMP']=os.environ['TMP']=str(scratch)
import tempfile
tempfile.tempdir=str(scratch)
os.environ['LEAF_BENCHMARK_REQUIRE_AC']='1'
spec=importlib.util.spec_from_file_location('native_clock_guards',ROOT/'benchmark/experiments/source-bf16/integration.py')
guards=importlib.util.module_from_spec(spec)
spec.loader.exec_module(guards)
me=psutil.Process()
affinity,priority=me.cpu_affinity(),me.nice()
try:
    me.cpu_affinity([2]);me.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
    with keep_awake(display=True):
        for index in range(4):
            with guards.power_window() as power:
                _,m=run_native(binary,artifact,[ids],threads=1,mode='bench',runs=31,warmup=10,windows_above_normal=True)
            item=dict(index=index,metrics=m,power=power,stability={p:latency_stability(m[p+'_samples_ms']) for p in ('prefill','decode')})
            record['passes'].append(item);write_record(report,record)
            assert m['native_clock_build'] and m['repeated_logits_exact'] and m['benchmark_ac_checked']
            assert m['worker_spin_us']==0
            for phase in ('prefill','decode'):
                for field in ('logical_cpu_start_','logical_cpu_end_'):
                    assert m[field+phase]==[2]*31
                for field in ('audited_linear_calls_','audited_linear_terms_'):
                    assert len(m[field+phase])==31 and len(set(m[field+phase]))==1 and m[field+phase][0]>0
                for field in ('performance_end_','sibling_busy_end_'):
                    assert len(m[field+phase])==31 and all(np.isfinite(v) and v>=0 for v in m[field+phase])
                assert all(0<=v<2.5 for v in m['clock_age_end_'+phase])
            print(index+1,{p:dict(wall_ms=m[p+'_p50_ms'],spread=item['stability'][p]['p90_p10_ratio'],
                performance=statistics.median(m['performance_end_'+p]),sibling_busy=statistics.median(m['sibling_busy_end_'+p])) for p in ('prefill','decode')},flush=True)
        record['sleep_events']=guards.sleep_events(record['utc'])
    assert all(digest(Path(p))==h for p,h in record['hashes'].items())
    record['complete']=True
except BaseException as error:
    record['error']=repr(error)
    raise
finally:
    me.cpu_affinity(affinity);me.nice(priority);write_record(report,record)
