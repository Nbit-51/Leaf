using Microsoft.Diagnostics.Tracing;
using System.Text.Json;

if (args.Length == 3) { Extract.Run(args[0], args[1], args[2]); return; }
if (args.Length != 2) throw new ArgumentException("Usage: Reader trace.etl catalogue-private.json");
if (File.Exists(args[1])) throw new IOException("Preserve existing output");
using var source = new ETWTraceEventSource(args[0]);
var catalogue = new Dictionary<string, Dictionary<string, object?>>();
long events = 0;
void Observe(TraceEvent e) {
    ++events;
    var key = $"{e.ProviderGuid}/{(int)e.ID}/{(int)e.Opcode}/{e.Version}";
    if (catalogue.TryGetValue(key, out var row)) { row["count"] = (long)row["count"]! + 1; return; }
    var fields = new Dictionary<string, object?>();
    foreach (var name in e.PayloadNames) {
        try { fields[name] = e.PayloadByName(name)?.ToString(); }
        catch (Exception ex) { fields[name] = "decode-error:" + ex.GetType().Name; }
    }
    catalogue[key] = new() {
        ["provider"] = e.ProviderName, ["event"] = e.EventName, ["count"] = 1L,
        ["key"] = key, ["payload"] = fields, ["payload_bytes"] = e.EventDataLength,
    };
}
source.Kernel.All += Observe;
source.Dynamic.All += Observe;
source.UnhandledEvents += Observe;
source.Process();
File.WriteAllText(args[1], JsonSerializer.Serialize(new {
    complete = true, events, lost_events = source.EventsLost,
    start_utc = source.SessionStartTime.ToUniversalTime(),
    end_utc = source.SessionEndTime.ToUniversalTime(),
    catalogue = catalogue.Values.OrderByDescending(x => (long)x["count"]!).ToArray()
}, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Decoded {events} events; lost={source.EventsLost}; kinds={catalogue.Count}");
