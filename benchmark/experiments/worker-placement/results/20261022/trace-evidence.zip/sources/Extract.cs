using Microsoft.Diagnostics.Tracing;
using System.Text.Json;
using System.Globalization;

static class Extract {
    static object? Value(TraceEvent e, string n) => e.PayloadByName(n);
    static int Int(TraceEvent e, string n) => Convert.ToInt32(Value(e, n), CultureInfo.InvariantCulture);
    public static void Run(string etl, string replay, string directory) {
        if (Directory.Exists(directory)) throw new IOException("Preserve existing extraction");
        Directory.CreateDirectory(directory);
        using var doc = JsonDocument.Parse(File.ReadAllText(replay));
        var owned = doc.RootElement.GetProperty("passes").EnumerateArray().Select(x => x.GetProperty("pid").GetInt32()).ToHashSet();
        using var switches = new StreamWriter(Path.Combine(directory,"switches-private.jsonl"));
        using var power = new StreamWriter(Path.Combine(directory,"power-private.jsonl"));
        using var profile = new StreamWriter(Path.Combine(directory,"profile-private.jsonl"));
        using var interrupts = new StreamWriter(Path.Combine(directory,"interrupts-private.jsonl"));
        var threads = new List<object>();
        long count = 0, cs = 0, pp = 0, samples = 0, ints = 0;
        using var source = new ETWTraceEventSource(etl);
        source.Kernel.All += e => {
            ++count;
            var n = e.EventName;
            if (n == "Thread/Start" && owned.Contains(e.ProcessID)) {
                threads.Add(new {t=e.TimeStampRelativeMSec,pid=e.ProcessID,tid=e.ThreadID});
            }
            if (e.ProcessorNumber != 2 && e.ProcessorNumber != 3) return;
            if (n == "Thread/CSwitch") {
                switches.WriteLine(JsonSerializer.Serialize(new {
                    t=e.TimeStampRelativeMSec,cpu=e.ProcessorNumber,
                    old_tid=Int(e,"OldThreadID"),new_tid=Int(e,"NewThreadID"),
                    old_pid=Int(e,"OldProcessID"),new_pid=Int(e,"NewProcessID"),
                    old_state=Value(e,"OldThreadState")?.ToString(),reason=Value(e,"OldThreadWaitReason")?.ToString(),
                    old_priority=Value(e,"OldThreadPriority"),new_priority=Value(e,"NewThreadPriority")
                })); ++cs;
            } else if (n == "PerfInfo/Sample" && owned.Contains(e.ProcessID)) {
                profile.WriteLine(JsonSerializer.Serialize(new {t=e.TimeStampRelativeMSec,cpu=e.ProcessorNumber,pid=e.ProcessID,tid=e.ThreadID,ip=Value(e,"InstructionPointer"),dpc=Value(e,"ExecutingDPC"),isr=Value(e,"ExecutingISR")})); ++samples;
            } else if (n == "PerfInfo/DPC" || n == "PerfInfo/ISR") {
                interrupts.WriteLine(JsonSerializer.Serialize(new {t=e.TimeStampRelativeMSec,cpu=e.ProcessorNumber,kind=n,ms=Value(e,"ElapsedTimeMSec"),routine=Value(e,"Routine")})); ++ints;
            }
        };
        source.Dynamic.All += e => {
            ++count;
            if (e.ProviderName != "Microsoft-Windows-Kernel-Processor-Power") return;
            var selected = e.PayloadNames.Contains("Number");
            if (selected && (Int(e,"Group") != 0 || (Int(e,"Number") != 2 && Int(e,"Number") != 3))) return;
            if (!selected && !new[]{"QosClassPolicy","DomainPerfStateChange","QosSupportChanged","ProfileChange","ProfileRundown","ProfileSettingChange","ProfileSettingRundown"}.Contains(e.EventName)) return;
            var fields = new Dictionary<string,object?>();
            foreach (var name in e.PayloadNames) {
                var value = Value(e,name);
                if (value is string && name != "Name") continue;
                if (value is Array) continue;
                fields[name] = value;
            }
            power.WriteLine(JsonSerializer.Serialize(new {t=e.TimeStampRelativeMSec,id=(int)e.ID,name=e.EventName,fields})); ++pp;
        };
        source.Process();
        var result = new {complete=true,lost_events=source.EventsLost,start_utc=source.SessionStartTime.ToUniversalTime(),end_utc=source.SessionEndTime.ToUniversalTime(),switches=cs,power=pp,samples,interrupts=ints,threads};
        File.WriteAllText(Path.Combine(directory,"metadata.json"),JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));
        Console.WriteLine(JsonSerializer.Serialize(new {complete=true,lost_events=source.EventsLost,switches=cs,power=pp,samples,interrupts=ints,threads=threads.Count}));
    }
}
