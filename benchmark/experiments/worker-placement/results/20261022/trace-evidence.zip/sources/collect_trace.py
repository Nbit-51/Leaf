"""Retain owned-run evidence and aggregate CPU data, never ETL/process inventory."""
import hashlib
import json
from pathlib import Path
import zipfile

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
D=BASE/'administrator-trace'
OUT=ROOT/'benchmark/experiments/worker-placement/results/20261022'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')

analysis=json.loads((D/'analysis-private-v2.json').read_text())
replay=json.loads((D/'replay.json').read_text())
catalogue=json.loads((D/'catalogue-private.json').read_text())
recording=json.loads((D/'recording.json').read_text(encoding='utf-8-sig'))
preflight=json.loads((BASE/'power-mode-preflight-before.json').read_text())
assert analysis['complete'] and replay['complete'] and len(replay['passes'])==12
assert recording['started'] and recording['stopped'] and recording['stop_exit_code']==0
assert catalogue['lost_events']==0 and not any(analysis['switch_chain_mismatches'].values())
assert preflight['power_mode']['initial_mode']=='better-battery' and not preflight['passed']
power=[json.loads(s) for s in (D/'extracted-v2/power-private.jsonl').open()]
profile_names={r['fields']['Id']:r['fields']['Name'] for r in power if r['name']=='ProfileRundown'}
transitions=[dict(trace_relative_ms=r['t'],previous=profile_names[r['fields']['PreviousProfileId']],
 next=profile_names[r['fields']['NextProfileId']]) for r in power if r['name']=='ProfileChange']
safe_passes=[]
for x,p in zip(analysis['passes'],replay['passes']):
 safe_passes.append({**{k:v for k,v in x.items() if k not in ('pid','thread_ms')},'stability':p['stability']})
summary=dict(complete=True,acceptance_timing=False,release_ready=False,
 scope='Attribution of the captured unmodified one-core Smol timing swing only; not a speed promotion or attribution of every historical outlier.',
 events=catalogue['events'],lost_events=catalogue['lost_events'],switch_chain_mismatches=analysis['switch_chain_mismatches'],
 raw_trace_sha256=sha(D/'scheduler-power.etl'),raw_trace_bytes=(D/'scheduler-power.etl').stat().st_size,
 power_mode_preflight=preflight,profile_transitions=transitions,passes=safe_passes,
 first_pass_seconds=analysis['first_pass_seconds'],sleep_events=replay['sleep_events'],
 findings=[
  'First BEFORE prefill spread 1.2698358718740301 fails the unchanged 1.25 gate; the other eleven passes have passing prefill and decode spreads. No samples excluded.',
  'The faster first-pass band overlaps the Constrained-to-LowLatency PPM transition. CPU 2 delivered-performance event medians reach 248-254 in seconds 7-9, versus 154 in subsequent steady passes.',
  'The first process is scheduled on CPU 2 for 97.10% of its elapsed window; subsequent processes receive 98.57-99.24%. Lost scheduling does not account for the faster band.',
  'Read-only post-trace preflight reports Better battery although AC is online and GetSystemPowerStatus battery_saver is false. This is not proof the effective mode was identical throughout the earlier trace.',
  'PPM profile changes and delivered-performance changes directly corroborate a power-management contribution to this captured swing. No claim of a thermal cause or attribution to a specific app/driver.',
  'The new guard audits effective mode and rejects saving/unknown modes or any mode change. It does not lock CPU frequency or observe every PPM subprofile. Fresh uninstrumented acceptance remains required.'
 ],
 statistics_note='Power quantiles are distributions of decoded events, not time-weighted frequency measurements or normalized benchmark scores.')
write(OUT/'trace-summary.json',summary)
assets={
 'trace-summary.json':OUT/'trace-summary.json',
 'owned-replay.json':D/'replay.json',
 'owned-recording.json':D/'recording.json',
 'power-mode-preflight-before.json':BASE/'power-mode-preflight-before.json',
 'power-modes-units.xml':BASE/'power-modes-units.xml',
 'sources/Reader.csproj':BASE/'etl-reader/Reader.csproj',
 'sources/NuGet.Config':BASE/'etl-reader/NuGet.Config',
 'sources/Program.cs':BASE/'etl-reader/Program.cs',
 'sources/Extract.cs':BASE/'etl-reader/Extract.cs',
 'sources/analyze_trace.py':BASE/'analyze_trace.py',
 'sources/collect_trace.py':Path(__file__),
 'sources/power.py':ROOT/'leaf/power.py',
 'sources/test_effective_power_mode.py':ROOT/'tests/unit/test_effective_power_mode.py',
 'sources/check_benchmark_power.py':ROOT/'tools/check_benchmark_power.py',
 'sources/validate.py':ROOT/'benchmark/experiments/worker-placement/validate.py',
}
package_assets=json.loads((BASE/'etl-reader/obj/project.assets.json').read_text())
dependencies={k:{n:v for n,v in x.items() if n in ('type','sha512')} for k,x in package_assets['libraries'].items()}
write(BASE/'etl-reader/dependencies.json',dependencies)
assets['sources/dependencies.json']=BASE/'etl-reader/dependencies.json'
archive=OUT/'trace-evidence.zip'
if archive.exists():raise ValueError('Preserve existing trace evidence')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,path in assets.items():z.writestr(name,path.read_bytes())
manifest=dict(complete=True,release_ready=False,archive=archive.name,archive_sha256=sha(archive),
 entries={name:sha(path) for name,path in assets.items()},
 omitted='Raw ETL, decoded other-process metadata, private event catalogues/extractions, model weights, binaries, .NET packages. Raw trace is hash-bound in trace-summary.json.',
 prior_manifest_sha256=sha(OUT/'manifest.json'))
write(OUT/'trace-manifest.json',manifest)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(manifest['entries'])
 for name,h in manifest['entries'].items():assert hashlib.sha256(z.read(name)).hexdigest()==h
print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,entries=len(assets),sha256=sha(archive))))
