"""Private trace analysis; only numeric aggregates may be curated for Git."""
import json
from pathlib import Path
from datetime import datetime
from collections import Counter
import numpy as np

ROOT=Path(__file__).resolve().parent
D=ROOT/'administrator-trace'
X=D/'extracted-v2'
replay=json.loads((D/'replay.json').read_text())
meta=json.loads((X/'metadata.json').read_text())
origin=datetime.fromisoformat(meta['start_utc'])
def rel(s):return (datetime.fromisoformat(s)-origin).total_seconds()*1000
def rows(n):
 with (X/n).open() as f:
  for line in f:yield json.loads(line)
def quant(a):
 a=np.asarray(a)
 return {} if not a.size else dict(zip(('p10','median','p90'),map(float,np.quantile(a,[.1,.5,.9]))))

power=list(rows('power-private.jsonl'))
print('Power numeric schemas',[(n,dict(Counter(r['name'] for r in power))[n]) for n in sorted(set(r['name'] for r in power))])
switches=list(rows('switches-private.jsonl'))
timeline=[];previous={};mismatch=Counter()
for e in switches:
 cpu=e['cpu']
 if cpu in previous:
  p=previous[cpu]
  mismatch[cpu]+=p['new_tid']!=e['old_tid']
  timeline.append((p['t'],e['t'],cpu,p['new_tid'],p['new_pid'],e['old_state'],e['reason']))
 previous[cpu]=e
print('Switch chain mismatches',dict(mismatch))

def duration(start,end,pid=None,cpu=2):
 return sum(max(0,min(end,b)-max(start,a)) for a,b,c,tid,p,state,reason in timeline if c==cpu and (pid is None or p==pid))

def sibling_busy(start,end):
 return sum(max(0,min(end,b)-max(start,a)) for a,b,c,tid,p,state,reason in timeline if c==3 and tid!=0)/(end-start)

def power_at(start,end,cpu=2):
 chosen=[r for r in power if start<=r['t']<end and r['fields'].get('Number')==cpu]
 out={}
 for name,fields in [('DeliveredPerfChange',('DeliveredPerformance','DeliveredFrequency')),('RecordedUtility',('Frequency','DeliveredPerformance','BusyTime','StallTime')),('ProcessorPerfStateChange',('Performance','MinPercent','MaxPercent','EppPercent','QosClass'))]:
  rr=[r for r in chosen if r['name']==name]
  out[name]={'count':len(rr),**{f:quant([r['fields'][f] for r in rr if f in r['fields']]) for f in fields}}
 return out

summaries=[]
for p in replay['passes']:
 a,b=rel(p['started_at_utc']),rel(p['ended_at_utc'])
 clocks=power_at(a,b)
 cpu_time=duration(a,b,p['pid'])
 time_by_tid=Counter()
 for x,y,c,tid,pid,state,reason in timeline:
  if c==2 and pid==p['pid']:time_by_tid[tid]+=max(0,min(b,y)-max(a,x))
 item=dict(index=p['index'],variant=p['variant'],pid=p['pid'],start=a,end=b,elapsed_ms=b-a,
  scheduled_ms=cpu_time,scheduled_fraction=cpu_time/(b-a),sibling_busy_fraction=sibling_busy(a,b),thread_ms=dict(time_by_tid),
  prefill_ms=p['metrics']['prefill_p50_ms'],decode_ms=p['metrics']['decode_p50_ms'],power=clocks)
 summaries.append(item)
 print('PASS',p['index'],p['variant'],round(b-a,2),round(cpu_time,2),'fraction',round(cpu_time/(b-a),5),
       'prefill',item['prefill_ms'],'decode',item['decode_ms'],
       'delivered',clocks['DeliveredPerfChange'].get('DeliveredPerformance'),
       'recorded',clocks['RecordedUtility'].get('DeliveredPerformance'))

first=replay['passes'][0];start=rel(first['started_at_utc']);end=rel(first['ended_at_utc'])
bins=[]
for i in range(int((end-start)//1000)+1):
 a=start+i*1000;b=min(a+1000,end)
 if b<=a:continue
 c=power_at(a,b)
 item=dict(second=i,scheduled_fraction=duration(a,b,first['pid'])/(b-a),sibling_busy_fraction=sibling_busy(a,b),power=c)
 bins.append(item)
 print('FIRST SECOND',i,'scheduled',round(item['scheduled_fraction'],4),
       'delivered',c['DeliveredPerfChange'].get('DeliveredPerformance'),
       'recorded',c['RecordedUtility'].get('DeliveredPerformance'))

out=dict(complete=True,trace_events_lost=meta['lost_events'],switch_chain_mismatches=dict(mismatch),passes=summaries,first_pass_seconds=bins)
(D/'analysis-private-v2.json').write_text(json.dumps(out,indent=2)+'\n')
