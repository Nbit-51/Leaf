"""Append final code/test proof and an explicitly interrupted benchmark."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
OUT=ROOT/'benchmark/experiments/worker-placement/results/20261022'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
raw=BASE/'efficiency-default-model/ordinary.json'
record=json.loads(raw.read_text())
counts={n:len(x['passes']) for n,x in record['models'].items()}
assert not record['complete'] and not record['passed'] and counts=={'smol':12,'qwen':7}
assert all(not x['passed'] for x in record['models']['smol']['summary'].values())
stop=dict(complete=False,passed=False,stopped_at_utc=datetime.now(timezone.utc).isoformat(),
 reason='User requested stopping work, pushing a checkpoint and taking a break.',
 retained_passes=counts,raw_record_sha256=digest(raw),raw_record_edited=False,
 missing=['Five Qwen passes','Final effective-mode window verdict','Final sleep audit'],
 system_power_settings_changed=False,next='Ordinary FP32 Smol/Qwen accumulation quality; do not rerun unchanged timing.')
write(BASE/'efficiency-stop.json',stop)
assets={
 'interrupted-ordinary.json':raw,'stop.json':BASE/'efficiency-stop.json',
 'power-mode-preflight-matched.json':BASE/'power-mode-preflight-matched.json',
 'power-modes-explicit-units.xml':BASE/'power-modes-explicit-units.xml',
 'sources/power.py':ROOT/'leaf/power.py',
 'sources/test_effective_power_mode.py':ROOT/'tests/unit/test_effective_power_mode.py',
 'sources/check_benchmark_power.py':ROOT/'tools/check_benchmark_power.py',
 'sources/validate.py':ROOT/'benchmark/experiments/worker-placement/validate.py',
 'sources/collect_efficiency.py':Path(__file__),
}
archive=OUT/'efficiency-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,path in assets.items():z.writestr(name,path.read_bytes())
manifest=dict(complete=False,release_ready=False,archive=archive.name,archive_sha256=digest(archive),
 entries={n:digest(p) for n,p in assets.items()},retained_passes=counts,
 scope='User-requested checkpoint; Smol stability fails and Qwen is incomplete. No new speed claim.',
 trace_manifest_sha256=digest(OUT/'trace-manifest.json'))
write(OUT/'efficiency-manifest.json',manifest)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(manifest['entries'])
 for n,h in manifest['entries'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(json.dumps(dict(entries=len(assets),bytes=archive.stat().st_size,sha256=digest(archive),retained_passes=counts)))
