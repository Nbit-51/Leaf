#pragma once
#include "leaf/runtime/host_support.h"
namespace leaf::experiments {
using leaf::runtime::detail::check;
class AlignedWorkers {
public:
    explicit AlignedWorkers(unsigned threads) : threads_(threads) {
        check(threads >= 1 && threads <= 64, "thread count must be 1..64");
        try {
        for (unsigned i = 1; i < threads_; ++i) workers_.emplace_back([this] {
            std::size_t observed = 0;
            for (;;) {
                std::unique_lock<std::mutex> lock(mutex_);
                ready_.wait(lock, [&] { return stop_ || epoch_ != observed; });
                if (stop_) return;
                observed = epoch_; lock.unlock(); drain(); lock.lock();
                if (--pending_ == 0) finished_.notify_one();
            }
        });
        } catch (...) {
            { std::lock_guard<std::mutex> lock(mutex_); stop_ = true; }
            ready_.notify_all();
            for (auto& worker : workers_) worker.join();
            throw;
        }
    }
    ~AlignedWorkers() {
        { std::lock_guard<std::mutex> lock(mutex_); stop_ = true; }
        ready_.notify_all(); for (auto& worker : workers_) worker.join();
    }
    void run(std::size_t count, std::function<void(std::size_t, std::size_t)> task) {
        if (threads_ == 1) { task(0, count); return; }
        { std::lock_guard<std::mutex> lock(mutex_);
          task_ = std::move(task); count_ = count; grain_ = count / threads_ >= 384 ? 96 : count / threads_ >= 192 ? 48 : 32; next_ = 0; pending_ = threads_ - 1; ++epoch_; }
        ready_.notify_all(); drain();
        std::unique_lock<std::mutex> lock(mutex_);
        finished_.wait(lock, [&] { return pending_ == 0; });
    }
private:
    void drain() {
        for (;;) {
            const std::size_t first = next_.fetch_add(grain_, std::memory_order_relaxed);
            if (first >= count_) return;
            task_(first, std::min(first + grain_, count_));
        }
    }
    unsigned threads_;
    std::size_t grain_ = 32;
    std::vector<std::thread> workers_;
    std::mutex mutex_;
    std::condition_variable ready_, finished_;
    bool stop_ = false;
    std::size_t epoch_ = 0, count_ = 0;
    unsigned pending_ = 0;
    std::atomic<std::size_t> next_{0};
    std::function<void(std::size_t, std::size_t)> task_;
};
}
