"""Compare pinned offline model-ID startup in two installed Leaf wheels."""
import json
import os
from pathlib import Path
from statistics import median
import sys

import psutil

from leaf.cli import model_directory
from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.decoder_validation import latency_stability
from tools.verify_package_runtime import digest, run_process


DRIVER = """
import json, sys
from leaf import cli
sys.argv = ["leaf", *sys.argv[1:]]
status = cli.main()
print("LEAF_HUB_IMPORT " + json.dumps("huggingface_hub" in sys.modules), file=sys.stderr, flush=True)
raise SystemExit(status)
"""
work = Path(__file__).resolve().parent
build = work.parent
wheels = {"before": build / "fp32-long-20261115/wheel-venv", "after": work / "venv"}
runtimes = {key: venv / "Lib/site-packages/leaf/bin/leaf_decoder.exe" for key, venv in wheels.items()}
hashes = {key: digest(exe) for key, exe in runtimes.items()}
report = dict(complete=False, scope=__doc__, processor_affinity=[2], binary_sha256=hashes["before"], bundled_binary_sha256=hashes,
              python_cli_sha256={key: digest(venv / "Lib/site-packages/leaf/cli.py") for key, venv in wheels.items()},
              power_mode={}, cases={})
assert len(set(report["python_cli_sha256"].values())) == 2
output = work / "comparison.json"
environment = {key: value for key, value in os.environ.items()
               if key.upper() != "LEAF_DECODER_BIN" and not key.upper().startswith("LEAF_EXPERIMENTAL_")}
environment["HF_HUB_OFFLINE"] = "1"
environment["LEAF_DECODER_BIN"] = str(runtimes["before"])
environment["PYTHONIOENCODING"] = "utf-8"
opts = ("--offline", "--raw", "--bits", "32", "--fp32-math", "accurate",
        "--prompt", "Once upon a time, a small robot found", "--max-tokens", "16")
measurements = ("external_first_visible_text_ms", "external_wall_ms", "prefill_p50_ms", "decode_p50_ms")
process = psutil.Process()
original = process.cpu_affinity()
cases = (
    ("facebook/opt-125m", "e3bf7e1695cb08c7963df13dbf144e0d1812717c", build / "cpu-model-suite-20261115/cache"),
    ("EleutherAI/pythia-70m", "a39f36b100fe8a5377810d56c3f4789b9c53ac42", build / "manual-model-cache"),
)


def run(side, case_id, model, revision, sample, artifact_bytes):
    require_benchmark_ac()
    metrics_file = work / f"{case_id}-{sample}-{side}.json"
    exe = wheels[side] / "Scripts/python.exe"
    arguments = ["run", model, "--revision", revision, *opts, "--metrics", str(metrics_file)]
    run = run_process([str(exe), "-I", "-u", "-c", DRIVER, *arguments], environment, work,
                      require_package_check=False)
    require_benchmark_ac()
    metrics = json.loads(metrics_file.read_bytes())
    assert metrics["artifact_bytes"] == artifact_bytes and metrics["threads"] == 1
    assert metrics["activation_bits"] == 32 and metrics["fp32_math"] == "accurate"
    assert len(metrics["generated_tokens"]) == 16
    tags = [x.rsplit(" ", 1)[-1] for x in run["stderr"].splitlines() if x.startswith("LEAF_HUB_IMPORT ")]
    assert tags == ["true" if side == "before" else "false"]
    assert "Preparing 32-bit native artifact..." not in run["stderr"]
    return dict({key: run[key] if key in run else metrics[key] for key in measurements},
                generated_tokens=metrics["generated_tokens"], hub_imported=side == "before")


try:
    process.cpu_affinity([2])
    assert process.cpu_affinity() == [2]
    with keep_awake(), benchmark_power_mode_guard(report["power_mode"], required_mode="better-battery"):
        for model, revision, cache in cases:
            case_id = model.split("/")[-1]
            environment["LEAF_CACHE_DIR"] = str(cache)
            snapshot = cache / "hub" / ("models--" + model.replace("/", "--")) / "snapshots" / revision
            artifact = model_directory(snapshot, cache) / "decoder-32.leaf"
            data = dict(revision=revision, artifact_sha256=digest(artifact), pairs=[])
            report["cases"][model] = data
            artifact_bytes = artifact.stat().st_size
            controls = [run(side, case_id, model, revision, "warmup", artifact_bytes) for side in wheels]
            expected = controls[0]["generated_tokens"]
            assert all(row["generated_tokens"] == expected for row in controls)
            for index in range(6):
                order = ("before", "after") if index % 2 == 0 else ("after", "before")
                pair = dict(order=order)
                for side in order:
                    row = run(side, case_id, model, revision, index + 1, artifact_bytes)
                    assert row["generated_tokens"] == expected
                    pair[side] = row
                data["pairs"].append(pair)
                write_record(output, report)
            summary = {}
            for metric in measurements:
                sides = {side: [p[side][metric] for p in data["pairs"]] for side in wheels}
                summary[metric] = dict(
                    p50_ms={side: median(rows) for side, rows in sides.items()},
                    stability={side: latency_stability(rows) for side, rows in sides.items()},
                    median_paired_ratio=median(a / b for b, a in zip(sides["before"], sides["after"])),
                )
            assert data["artifact_sha256"] == digest(artifact)
            data["summary"] = summary
            data["exact_generated_tokens"] = True
            # Exercise the candidate package's own bundled binary separately.
            common_binary = environment.pop("LEAF_DECODER_BIN")
            try:
                bundled = run("after", case_id, model, revision, "bundled", artifact_bytes)
                assert bundled["generated_tokens"] == expected
                data["candidate_bundled_tokens_exact"] = True
            finally:
                environment["LEAF_DECODER_BIN"] = common_binary
            print(model, {metric: (row["p50_ms"], [s["passed"] for s in row["stability"].values()])
                          for metric, row in summary.items()}, flush=True)
    assert hashes == {key: digest(exe) for key, exe in runtimes.items()}
    report["complete"] = True
finally:
    process.cpu_affinity(original)
    write_record(output, report)
