"""Prepare a fixed held-out CIFAR-10 subset for trained VGG-11-BN parity."""

import json
from pathlib import Path

import numpy as np
import torch
from torch import nn

from tools.validate_decoder import digest


work = Path(__file__).resolve().parent / 'graphs'
checkpoint = work / 'cifar10_vgg11_bn-eaeebf42.pt'
expected_hash = digest(checkpoint)
assert expected_hash.startswith('eaeebf42')


class CifarVgg11(nn.Module):
    def __init__(self):
        super().__init__()
        features, inputs = [], 3
        for stage in ((64,), (128,), (256, 256), (512, 512), (512, 512)):
            for outputs in stage:
                features.extend((nn.Conv2d(inputs, outputs, 3, padding=1),
                                 nn.BatchNorm2d(outputs), nn.ReLU()))
                inputs = outputs
            features.append(nn.MaxPool2d(2))
        self.features = nn.Sequential(*features)
        self.classifier = nn.Sequential(nn.Linear(512, 512), nn.ReLU(), nn.Dropout(),
                                        nn.Linear(512, 512), nn.ReLU(), nn.Dropout(), nn.Linear(512, 10))

    def forward(self, x):
        return self.classifier(torch.flatten(self.features(x), start_dim=1))


source = work.parents[1] / 'cifar10_full'
images = np.memmap(source/'inputs.bin',dtype='<f4',mode='r').reshape(10000,3,32,32)
labels = np.fromfile(source/'labels.u32',dtype='<u4')
indices = np.linspace(0, len(labels)-1, 512, dtype=int)
x = np.ascontiguousarray(images[indices], dtype=np.float32)
torch.set_num_threads(4)
model = CifarVgg11().eval()
model.load_state_dict(torch.load(checkpoint, map_location='cpu', weights_only=True))
with torch.inference_mode():
    all_logits = np.concatenate([model(torch.from_numpy(rows)).numpy()
                                 for rows in np.array_split(x, 32)])
torch.onnx.export(model, torch.from_numpy(x[:1]), str(work/'vgg11.onnx'), opset_version=13,
                  input_names=['input'], output_names=['output'], dynamo=False)
x.tofile(work/'vgg-inputs.bin')
all_logits.astype('<f4').tofile(work/'vgg-reference.bin')
labels[indices].tofile(work/'vgg-labels.u32')
(work/'vgg-fixture.json').write_text(json.dumps(dict(
    checkpoint_sha256=expected_hash, inputs_source_sha256=digest(source/'inputs.bin'),
    labels_source_sha256=digest(source/'labels.u32'), heldout_indices=indices.tolist(),
    pytorch=str(torch.__version__), reference_accuracy=float(np.mean(all_logits.argmax(1) == labels[indices])),
),indent=2)+'\n')
