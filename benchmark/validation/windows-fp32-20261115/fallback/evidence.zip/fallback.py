"""Check the FP32 OPT worker and forced-scalar fallback against four-worker Leaf."""
import json
from pathlib import Path
from statistics import median
import tempfile

import numpy as np

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest


work = Path(__file__).resolve().parent
tempfile.tempdir = str(work / "tmp")
quality = json.loads((work / "parallel-quality.json").read_bytes())
assert quality["complete"] and quality["passed"]
model = quality["models"]["opt"]
artifact = Path(model["artifact"])
executable = work / "parallel-decoder.exe"
ids = json.loads((work / "parallel-opt-tokens.json").read_bytes())["benchmark_ids"]
report = dict(complete=False, scope=__doc__, executable_sha256=digest(executable),
              artifact_sha256=digest(artifact), configurations={}, power_mode={})
targets = (("one_worker", [2], False), ("two_workers", [0, 2], False), ("forced_scalar", [2], True))
fp32 = dict(fp32_math="accurate")
reference_opt = dict(threads=4, worker_cpus=[0, 2, 4, 6], **fp32)
expected, _ = run_native(executable, artifact, [ids[:65]], mode="chunked", chunk=64, **reference_opt)
expected = expected.reshape(65, -1)
expected_ids = expected.argmax(axis=-1)
_, generated = run_native(executable, artifact, [ids[:64]], mode="generate", generate=16, **reference_opt)
report_path = work / "opt-fallback.json"
try:
    with keep_awake(), benchmark_power_mode_guard(report["power_mode"], required_mode="better-battery"):
        for name, cpus, force_scalar in targets:
            require_benchmark_ac()
            options = dict(threads=len(cpus), worker_cpus=cpus, scalar=force_scalar, **fp32)
            actual, _ = run_native(executable, artifact, [ids[:65]], mode="chunked", chunk=64, **options)
            actual = actual.reshape(expected.shape)
            _, continuation = run_native(executable, artifact, [ids[:64]], mode="generate", generate=16, **options)
            row = dict(config=options, exact_predictions=bool(np.array_equal(expected_ids, actual.argmax(axis=-1))),
                       max_abs_error=float(np.max(np.abs(actual - expected))),
                       all_logits_close=bool(np.allclose(actual, expected, atol=2e-4, rtol=2e-4)),
                       exact_continuation=continuation["generated_tokens"] == generated["generated_tokens"])
            report["configurations"][name] = row
            assert row["all_logits_close"] and row["exact_predictions"] and row["exact_continuation"], name
            if not force_scalar:
                _, long_logits_metrics = run_native(executable, artifact, [ids], mode="bench", runs=7, warmup=2, **options)
                row["observed_latency"] = {phase: dict(
                    median_ms=median(long_logits_metrics[phase + "_samples_ms"]),
                    stability=latency_stability(long_logits_metrics[phase + "_samples_ms"]),
                    samples_ms=long_logits_metrics[phase + "_samples_ms"]) for phase in ("prefill", "decode")}
            require_benchmark_ac()
            print(name, row["max_abs_error"], row["exact_continuation"], flush=True)
    report["complete"] = True
finally:
    write_record(report_path, report)

