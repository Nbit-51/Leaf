"""Check trained long-context Leaf logits in the installed Windows wheel."""
import hashlib
import json
from pathlib import Path
import tempfile

import numpy as np

from leaf.evaluation import write_record
from tools.decoder_validation import run_native
from tools.validate_decoder import digest


work = Path(__file__).resolve().parent
tempfile.tempdir = str(work / "tmp")
previous = work.parent / "cpu-model-suite-20261115"
relative_executable = "wheel-venv/Lib/site-packages/leaf/bin/leaf_decoder.exe"
baseline = previous / relative_executable
installed = work / relative_executable
qwen = json.loads((previous / "qwen3-quality.json").read_bytes())
qualified = json.loads((work / "parallel-quality.json").read_bytes())
optimizer = Path(qualified["models"]["opt"]["artifact"])
qwen_artifact, = (Path(path) for path in qwen["hashes"] if Path(path).suffix == ".leaf")
report = dict(executable_sha256=digest(installed), previous_executable_sha256=digest(baseline), models={})
for name, model, fixture, math in (
    ("opt", optimizer, work / "parallel-opt-tokens.json", "accurate"),
    ("qwen3", qwen_artifact, previous / "qwen3-768-tokens.json", "fast"),
):
    ids = json.loads(fixture.read_bytes())["benchmark_ids"]
    assert len(ids) == 769
    sizes, hashes = [], []
    for exe in (baseline, installed):
        logits, _ = run_native(exe, model, [ids], mode="chunked", chunk=768, fp32_math=math,
                               threads=4, worker_cpus=[0, 2, 4, 6])
        assert np.isfinite(logits).all()
        sizes.append(int(logits.size))
        hashes.append(hashlib.sha256(memoryview(logits).cast("B")).hexdigest())
        del logits
    assert sizes[0] == sizes[1] and hashes[0] == hashes[1], name
    report["models"][name] = dict(artifact_sha256=digest(model), tokens_sha256=digest(fixture),
                                  fp32_math=math, bit_exact_logits=sizes[0], logits_sha256=hashes[0])
    print(name, sizes[0], "bit-exact logits", flush=True)
write_record(work / "wheel-long-quality.json", report)
