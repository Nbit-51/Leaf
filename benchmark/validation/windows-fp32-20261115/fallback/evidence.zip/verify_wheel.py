"""Verify the shipped binaries in a fresh, compilerless environment."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


work = Path(__file__).resolve().parent
previous = work.parent / "cpu-model-suite-20261115"
smoke = work / "wheel-smoke"
smoke.mkdir()
venv = work / "wheel-venv"
wheel, = (work / "wheel").glob("*.whl")
subprocess.run([sys.executable, "-m", "venv", "--system-site-packages", str(venv)], check=True)
python, leaf = [venv / "Scripts" / name for name in ("python.exe", "leaf.exe")]
subprocess.run([str(python), "-m", "pip", "install", "--no-deps", "--ignore-installed", str(wheel)], check=True)
env = {key: value for key, value in os.environ.items()
       if not key.startswith("LEAF_") and key not in ("PYTHONPATH", "CXX", "CC")}
env.update(PATH=os.pathsep.join((str(leaf.parent), str(Path(os.environ["SystemRoot"]) / "System32"))),
           LEAF_CACHE_DIR=str(previous / "cache"), HF_HUB_OFFLINE="1")
assert all(shutil.which(name, path=env["PATH"]) is None for name in ("g++", "clang++", "cl"))
model = "facebook/opt-125m"
revision = "e3bf7e1695cb08c7963df13dbf144e0d1812717c"


def run(*args):
    result = subprocess.run([str(leaf), *args], cwd=smoke, env=env, capture_output=True, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(result.stderr + result.stdout)
    return result.stdout


doctor = json.loads(run("doctor", "--task", "generation"))
assert doctor["runtimes"]["generation"]["selection"] == "bundled"
info = json.loads(run("inspect", model, "--revision", revision, "--offline"))
assert info["configuration_supported"] and Path(info["snapshot"]).name == revision
assert run("run", model, "--revision", revision, "--offline", "--bits", "32", "--fp32-math", "accurate",
           "--threads", "4", "--worker-cpus", "0", "2", "4", "6",
           "--prompt", "Once upon a time, a small robot found", "--max-tokens", "16", "--metrics", "opt.json").strip()
result = json.loads((smoke / "opt.json").read_bytes())
reference = json.loads((previous / "opt125m-public-run.json").read_bytes())
assert result["generated_tokens"] == reference["generated_tokens"]
assert result["artifact_bytes"] == reference["artifact_bytes"] and result["fp32_math"] == "accurate"
record = dict(wheel=wheel.name, wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
              cached_pin_generation_matches=True, compiler_on_path=False, requested_threads=4,
              generated_tokens=len(result["generated_tokens"]), revision=revision,
              artifact_bytes=result["artifact_bytes"])
(work / "wheel-opt-smoke.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record), flush=True)
