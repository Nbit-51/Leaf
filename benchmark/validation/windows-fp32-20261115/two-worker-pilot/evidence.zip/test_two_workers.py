"""Qualify long-context projections and attention with a two-worker CPU budget."""
import hashlib
import json
from pathlib import Path
from statistics import median
import tempfile

import numpy as np
import psutil

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.benchmark_core_scaling import validate_cores
from tools.decoder_validation import latency_stability, run_native
from tools.diagnose_windows_benchmark import cpu_sets
from tools.validate_decoder import digest


work = Path(__file__).resolve().parent
tempfile.tempdir = str(work / "tmp")
binaries = {"before": work / "wheel-venv/Lib/site-packages/leaf/bin/leaf_decoder.exe",
            "after": work / "two-workers.exe"}
quality = json.loads((work / "parallel-quality.json").read_bytes())
assert quality["complete"] and quality["passed"]
opt = Path(quality["models"]["opt"]["artifact"])
pythia = work.parent / "trained-operator-validation-20261109-211516"
models = {
    "OPT-125M": (opt, work / "parallel-opt-tokens.json"),
    "Pythia-70M": (pythia / "pythia-artifacts/decoder-32.leaf", pythia / "pythia-quality/tokens.json"),
}
cpus = [0, 2]
process = psutil.Process()
original = process.cpu_affinity()
topology = cpu_sets()
core_rows = validate_cores(cpus, topology)
assert core_rows[0]["efficiency_class"] == max(row["efficiency_class"] for row in topology)
process.cpu_affinity(cpus)
assert sorted(process.cpu_affinity()) == cpus
paths = [*binaries.values(), work / "decoder-two-workers.cpp", Path(__file__)]
paths.extend(path for pair in models.values() for path in pair)
report = dict(complete=False, scope=__doc__, placement=core_rows, power_mode={}, results={},
              hashes={str(path): digest(path) for path in paths})
options = dict(threads=2, worker_cpus=cpus, fp32_math="accurate")
output = work / "two-workers.json"


def logits_sha(exe, artifact, ids):
    values, _ = run_native(exe, artifact, [ids], mode="chunked", chunk=len(ids)-1, **options)
    assert np.isfinite(values).all()
    return int(values.size), hashlib.sha256(memoryview(values).cast("B")).hexdigest()


try:
    with keep_awake(), benchmark_power_mode_guard(report["power_mode"], required_mode="better-battery"):
        for name, (artifact, fixture) in models.items():
            payload = json.loads(fixture.read_bytes())
            ids = payload.get("benchmark_ids")
            if ids is None:
                ids = [token for sequence in payload["sequences"] for token in sequence][:769]
            assert len(ids) == 769
            result = dict(pairs=[], logits={}, tokens=ids)
            report["results"][name] = result
            for length in (64, 768):
                before, after = (logits_sha(exe, artifact, ids[:length+1]) for exe in binaries.values())
                assert before == after, (name, length)
                result["logits"][length] = dict(count=after[0], bit_exact_sha256=after[1])
            previous, candidate = (run_native(exe, artifact, [ids[:-1]], mode="generate",
                                               generate=16, **options)[1]["generated_tokens"]
                                   for exe in binaries.values())
            assert len(candidate) == 16 and candidate == previous
            result["greedy_exact"] = candidate
            write_record(output, report)
            for i in range(6):
                order = ("before", "after") if i % 2 == 0 else ("after", "before")
                pair = dict(order=order)
                for side in order:
                    require_benchmark_ac()
                    _, measurements = run_native(binaries[side], artifact, [ids], mode="bench",
                                                 runs=5, warmup=2, **options)
                    require_benchmark_ac()
                    assert measurements["benchmark_ac_checked"] and measurements["optimized_fp32_active"]
                    pair[side] = {key: measurements[key + "_samples_ms"] for key in ("prefill", "decode")}
                result["pairs"].append(pair)
                print(name, i+1, *(round(median(pair[s]["prefill"]), 2) for s in binaries), flush=True)
                write_record(output, report)
            result["summary"] = {}
            for phase, limit in (("prefill", .98), ("decode", 1.02)):
                stages = {k: [p[k][phase] for p in result["pairs"]] for k in binaries}
                pooled = {k: sum(rows, []) for k, rows in stages.items()}
                tests = [latency_stability(r) for rows in (*stages.values(), list(pooled.values())) for r in rows]
                ratio = median(median(a) / median(b) for b, a in zip(stages["before"], stages["after"]))
                stable = all(t["passed"] for t in tests)
                result["summary"][phase] = dict(medians_ms={k: median(r) for k, r in pooled.items()}, stable=stable,
                                                paired_ratio=ratio, passed=stable and ratio <= limit)
            print(name, result["summary"], flush=True)
            write_record(output, report)
    assert all(digest(Path(path)) == sha for path, sha in report["hashes"].items())
    report["complete"] = True
finally:
    process.cpu_affinity(original)
    write_record(output, report)
