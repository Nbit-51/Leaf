"""Paired CPU FP32 OPT-125M comparison at 768 WikiText-2 tokens on four cores."""

import json
import os
from pathlib import Path
from statistics import median
import tempfile
from types import SimpleNamespace

import numpy as np
import torch
import psutil

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest, load_pytorch_model, measure_pytorch_latency


work = Path(__file__).resolve().parent
scratch = work/'opt-tmp'
scratch.mkdir(exist_ok=True)
tempfile.tempdir = str(scratch)
quality_file = work/'opt-accurate-quality/quality.json'
quality = json.loads(quality_file.read_bytes())
assert quality['complete'] and quality['passed'] and quality['fp32_math'] == 'accurate'
snapshot = Path(quality['snapshot'])
runtime = work/'parallel-decoder.exe'
assert digest(runtime) == quality['executable_sha256']
artifact, = (p for p in (work.parent/'cpu-model-suite-20261115/cache/models').glob('*/decoder-32.leaf')
             if digest(p) == quality['artifact_sha256'])
tokens = quality_file.with_name('tokens.json')
assert digest(tokens) == quality['tokens_sha256']
rows = json.loads(tokens.read_bytes())['sequences']
source_ids = [token for row in rows for token in row]
mode = json.loads((work/'parallel-opt-paired/comparison.json').read_bytes())['power_mode']['initial_mode']
cpus = [0, 2, 4, 6]
args = SimpleNamespace(model=snapshot, threads=4, runs=5, warmup=2)
psutil.Process().cpu_affinity(cpus)
model, _ = load_pytorch_model(args)
model.set_attn_implementation('sdpa')
bindings = {str(path): digest(path) for path in (runtime, artifact, quality_file, tokens, Path(__file__))}
for name,sha in quality['source_sha256'].items():
    path = snapshot / name
    assert digest(path) == sha
    bindings[str(path)] = sha
record = dict(format='leaf-opt-paired-v1', complete=False, model='facebook/opt-125m',
              revision=snapshot.name, scope=__doc__, quality_passed=True, worker_cpus=cpus, threads=4,
              torch=str(torch.__version__), fp32_math='accurate', pairs=6, runs=args.runs,
              warmup=args.warmup, inputs=bindings, power_mode={}, workloads={})
output = work/'opt-four-core-competitor.json'
os.environ['LEAF_BENCHMARK_REQUIRE_AC'] = '1'
try:
    with keep_awake(), benchmark_power_mode_guard(record['power_mode'], required_mode=mode):
        for length in (768,):
            ids = source_ids[:length+1]
            assert len(ids) == length+1
            logits, _ = run_native(runtime, artifact, [ids], mode='chunked', chunk=length, fp32_math='accurate', threads=4, worker_cpus=cpus)
            actual = logits.reshape(len(ids), -1)[-2:].copy()
            del logits
            with torch.inference_mode():
                prefix = model(torch.tensor([ids[:-1]]), use_cache=True, logits_to_keep=1)
                final = model(torch.tensor([[ids[-1]]]), past_key_values=prefix.past_key_values,
                              use_cache=True, logits_to_keep=1)
                expected = np.concatenate((prefix.logits[0].numpy(), final.logits[0].numpy()))
                del prefix, final
            same = bool(np.allclose(actual, expected, atol=2e-4, rtol=2e-4) and
                        np.array_equal(actual.argmax(axis=1), expected.argmax(axis=1)))
            data = dict(token_ids=ids, boundary_logits_close=same,
                        max_abs_error=float(np.max(np.abs(actual-expected))), passes=[])
            record['workloads'][length] = data
            for index in range(6):
                pair = dict(order=('leaf','pytorch') if index % 2 == 0 else ('pytorch','leaf'))
                for side in pair['order']:
                    require_benchmark_ac()
                    if side == 'leaf':
                        _, timings = run_native(runtime, artifact, [ids], mode='bench', fp32_math='accurate',
                                                runs=args.runs, warmup=args.warmup, threads=4, worker_cpus=cpus)
                        assert timings['benchmark_ac_checked']
                    else:
                        timings = measure_pytorch_latency(model, ids, args, implementations=('sdpa',))['sdpa']
                    require_benchmark_ac()
                    pair[side] = {phase: timings[phase+'_samples_ms'] for phase in ('prefill','decode')}
                data['passes'].append(pair)
                print(length, index+1, *(round(median(pair[s]['prefill']),2) for s in ('leaf','pytorch')),
                      flush=True)
                write_record(output, record)
            summary = {}
            for phase in ('prefill','decode'):
                values = {side: [p[side][phase] for p in data['passes']] for side in ('leaf','pytorch')}
                pooled = {side: sum(rows, []) for side, rows in values.items()}
                stable = all(latency_stability(samples)['passed'] for samples in
                             [*pooled.values(), *values['leaf'], *values['pytorch']])
                ratio = median(median(a)/median(b) for a,b in zip(values['leaf'],values['pytorch']))
                summary[phase] = dict(stable=stable, paired_ratio=ratio,
                                      medians_ms={s:median(x) for s,x in pooled.items()},
                                      speed_qualified=same and stable and ratio <= .98)
            data['summary'] = summary
    assert all(digest(Path(p)) == checksum for p, checksum in bindings.items())
    record['complete'] = True
finally:
    write_record(output, record)
