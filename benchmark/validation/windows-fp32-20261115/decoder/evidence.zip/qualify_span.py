"""Bit-exact trained verification for masked softmax work removal."""

import hashlib
import json
from pathlib import Path
import sys
import tempfile

import numpy as np

from leaf.evaluation import write_record
from tools.decoder_validation import run_native
from tools.validate_decoder import digest


work = Path(__file__).resolve().parent
tempfile.tempdir = str(work/'tmp')
parallel = sys.argv[1:] == ['parallel']
prefix = 'parallel-' if parallel else ''
build = work.parent
previous = build/'cpu-model-suite-20261115'
before = previous/'wheel-venv/Lib/site-packages/leaf/bin/leaf_decoder.exe'
after = work/('parallel-decoder.exe' if parallel else 'leaf_decoder.exe')
opt_reference = json.loads((previous/'opt125m-pinned-quality-retry/quality.json').read_bytes())
opt, = (p for p in (previous/'cache/models').glob('*/decoder-32.leaf')
        if digest(p) == opt_reference['artifact_sha256'])
assert opt_reference['complete'] and opt_reference['passed']
smol = (build/'ollama-family-20261019/smol/decoder-32.leaf' if parallel else
        build/'presentation-20261115/smol-source-bf16/decoder-32-source-bf16.leaf')
sources = [opt, smol, before, after, Path('engine/include/leaf/kernels/attention_vector.h').resolve()]
if parallel:
    sources += [Path(p).resolve() for p in ('engine/src/decoder.cpp','engine/include/leaf/kernels/accurate_fp32.h')]
record = dict(complete=False, passed=False, scope=__doc__, parallel_fp32=parallel,
              hashes={str(p):digest(p) for p in sources}, models={})
for name, artifact, fixture, options in (
    ('opt', opt, previous/'opt125m-768-tokens.json', dict(threads=4 if parallel else 1,
          worker_cpus=[0,2,4,6] if parallel else [2], fp32_math='accurate')),
    ('smol', smol, build/'presentation-20261115/release-candidate/smol-tokens.json',
     dict(threads=4, worker_cpus=[0,2,4,6], fp32_math='fast')),
):
    ids = json.loads(fixture.read_bytes())['benchmark_ids']
    write_record(work/f'{prefix}{name}-tokens.json', dict(benchmark_ids=ids))
    report = {}
    for length in (64, 768):
        hashes = []
        for exe in (before, after):
            logits, _ = run_native(exe, artifact, [ids[:length+1]], mode='chunked', chunk=length, **options)
            assert np.isfinite(logits).all()
            hashes.append(hashlib.sha256(memoryview(logits).cast('B')).hexdigest())
            count = logits.size
            del logits
        assert hashes[0] == hashes[1], (name, length)
        report[length] = dict(bit_exact_logits=count, logits_sha256=hashes[0])
    generations = [run_native(exe, artifact, [ids[:-1]], mode='generate', generate=16, **options)[1]['generated_tokens']
                   for exe in (before, after)]
    assert generations[0] and generations[0] == generations[1]
    record['models'][name] = dict(artifact=str(artifact), mode=options, workloads=report,
                                 generated_tokens=generations[0], generation_exact=True)
    write_record(work/f'{prefix}quality.json', record)
    print(name, {k:v['bit_exact_logits'] for k,v in report.items()}, 'greedy exact', len(generations[0]), flush=True)
assert all(digest(p) == record['hashes'][str(p)] for p in sources)
record.update(complete=True, passed=True)
write_record(work/f'{prefix}quality.json', record)
