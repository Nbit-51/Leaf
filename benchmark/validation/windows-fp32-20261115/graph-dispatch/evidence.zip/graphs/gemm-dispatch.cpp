#include "gemm.h"

#include <cstring>

#if (defined(__x86_64__) && defined(__GNUC__)) || (defined(__AVX2__) && defined(__FMA__))
#include <immintrin.h>
#define LEAF_GRAPH_AVX2 1
#endif

namespace leaf {
namespace {

#if LEAF_GRAPH_AVX2
// Im2col exposes spatial positions as adjacent columns. Load them once
// and reuse them across up to four output channels.
template <size_t Rows>
#if defined(__x86_64__) && defined(__GNUC__)
__attribute__((target("avx2,fma")))
#endif
void gemm_vector_rows(const float* weights, const float* input, float* output,
                      size_t channels, size_t columns, size_t vector_columns, float alpha) {
    const __m256 scale = _mm256_set1_ps(alpha);
    for (size_t column = 0; column < vector_columns; column += 8) {
        __m256 sums[Rows] = {};
        for (size_t channel = 0; channel < channels; ++channel) {
            const __m256 values = _mm256_loadu_ps(input + channel * columns + column);
            for (size_t row = 0; row < Rows; ++row) {
                const __m256 weight = _mm256_set1_ps(weights[row * channels + channel]);
                sums[row] = _mm256_fmadd_ps(weight, values, sums[row]);
            }
        }
        for (size_t row = 0; row < Rows; ++row) {
            float* dest = output + row * columns + column;
            _mm256_storeu_ps(dest, _mm256_add_ps(_mm256_loadu_ps(dest), _mm256_mul_ps(sums[row], scale)));
        }
    }
}
#endif

template <size_t Rows>
void gemm_scalar_tail(const float* weights, const float* input, float* output,
                      size_t channels, size_t columns, size_t first_column, float alpha) {
    for (size_t column = first_column; column < columns; ++column) {
        float sums[Rows] = {};
        for (size_t channel = 0; channel < channels; ++channel) {
            const float value = input[channel * columns + column];
            for (size_t row = 0; row < Rows; ++row) {
                sums[row] += weights[row * channels + channel] * value;
            }
        }
        for (size_t row = 0; row < Rows; ++row) output[row * columns + column] += alpha * sums[row];
    }
}

}  // namespace

void gemm_f32(
    const float* A, const float* B, float* C,
    size_t M, size_t K, size_t N,
    float alpha, float beta
) {
    if (beta == 0.0f) {
        std::memset(C, 0, M * N * sizeof(float));
    } else if (beta != 1.0f) {
        for (size_t i = 0; i < M * N; ++i) C[i] *= beta;
    }

    size_t vector_columns = 0;
#if defined(__x86_64__) && defined(__GNUC__)
    if (__builtin_cpu_supports("avx2") && __builtin_cpu_supports("fma")) vector_columns = N & ~size_t(7);
#elif LEAF_GRAPH_AVX2
    vector_columns = N & ~size_t(7);
#endif
    size_t row = 0;
    for (; row + 4 <= M; row += 4) {
#if LEAF_GRAPH_AVX2
        if (vector_columns) gemm_vector_rows<4>(A + row * K, B, C + row * N, K, N, vector_columns, alpha);
#endif
        gemm_scalar_tail<4>(A + row * K, B, C + row * N, K, N, vector_columns, alpha);
    }
    for (; row < M; ++row) {
#if LEAF_GRAPH_AVX2
        if (vector_columns) gemm_vector_rows<1>(A + row * K, B, C + row * N, K, N, vector_columns, alpha);
#endif
        gemm_scalar_tail<1>(A + row * K, B, C + row * N, K, N, vector_columns, alpha);
    }
}

}  // namespace leaf
