"""Compare portable graph builds before and after CPU dispatch on mixed CNNs."""
import json
import os
from itertools import permutations
from pathlib import Path
from statistics import median
from types import SimpleNamespace

import numpy as np

from benchmark.bench_graph_onnxruntime import leaf_run, ort_run, require_parity
from leaf.affinity import pin_cpu
from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.decoder_validation import latency_stability
from tools.validate_decoder import digest


work = Path(__file__).resolve().parent / "graphs"
root = work.parents[2]
binaries = {side: work / name for side, name in (("before", "leaf_dataset.exe"), ("after", "leaf_dispatch.exe"))}
records = {}
pin_cpu(2)
os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
for model, fixture in (
    ("resnet20", (root / "build/cifar10_full/inputs.bin", root / "build/cifar10_full/expected.bin",
                  root / "build/cifar10_full/labels.u32", 10000)),
    ("vgg11", (work / "vgg-inputs.bin", work / "vgg-reference.bin", work / "vgg-labels.u32", 512)),
):
    sample_dir = work / model
    artifact = sample_dir / "graph.leaf"
    original = json.loads((sample_dir / "comparison.json").read_bytes())
    assert original["complete"] and original["timing_samples"] == 101
    data = tuple(sample_dir / name for name in ("inputs.bin", "logits.bin", "labels.u32"))
    onnx = root / "build/cifar10_full/resnet20.onnx" if model == "resnet20" else work / "vgg11.onnx"
    images = np.fromfile(data[0], dtype="<f4").reshape(101, 3, 32, 32)
    expected = np.fromfile(data[1], dtype="<f4").reshape(101, -1)
    labels = np.fromfile(data[2], dtype="<u4")
    output = work / f"{model}-dispatch"
    output.mkdir()
    report = dict(complete=False, scope=__doc__, pairs=[], power_mode={}, cpu=2, threads=1, timing_samples=101)
    bound = (onnx, artifact, *binaries.values(), *fixture[:-1], *data, Path(__file__), work / "gemm-dispatch.cpp")
    report["hashes"] = {str(path): digest(path) for path in bound}
    records[model] = report
    manifest = output / "comparison.json"

    def run(side, dataset, name):
        return leaf_run(SimpleNamespace(executable=binaries[side], shape=(3, 32, 32)), dataset,
                        artifact, output / name)

    try:
        quality = run("after", fixture, "quality.json")
        require_parity(quality, fixture[-1])
        quality.pop("latency_samples_ms")
        report["quality"] = quality
        with keep_awake(), benchmark_power_mode_guard(report["power_mode"], required_mode="better-battery"):
            for index, order in enumerate(permutations(("before", "after", "onnxruntime"))):
                pair = dict(order=order)
                for side in order:
                    require_benchmark_ac()
                    if side == "onnxruntime":
                        result = ort_run(SimpleNamespace(onnx=onnx), images, expected, labels, timing=True)
                    else:
                        result = run(side, (*data, 101), f"{index+1}-{side}.json")
                    require_benchmark_ac()
                    require_parity(result, 101)
                    samples = result["latency_samples_ms"]
                    pair[side] = dict(samples_ms=samples, stability=latency_stability(samples))
                report["pairs"].append(pair)
                write_record(manifest, report)
        report["summary"] = {}
        for rival in ("before", "onnxruntime"):
            series = {side: [pair[side]["samples_ms"] for pair in report["pairs"]] for side in (rival, "after")}
            pooled = {side: sum(values, []) for side, values in series.items()}
            ratio = median(median(a) / median(b) for b, a in zip(series[rival], series["after"]))
            stable = all(latency_stability(row)["passed"] for rows in series.values() for row in rows)
            stable = stable and all(latency_stability(row)["passed"] for row in pooled.values())
            report["summary"][rival] = dict(medians_ms={side: median(row) for side, row in pooled.items()},
                                            median_paired_ratio=ratio, stable=stable, speed_qualified=ratio <= .98 and stable)
        assert all(digest(Path(path)) == checksum for path, checksum in report["hashes"].items())
        report["complete"] = True
        print(model, report["summary"], flush=True)
    finally:
        write_record(manifest, report)
