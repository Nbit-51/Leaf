"""Measure short native Pythia generation with and without AVX2 dispatch."""
import json
import os
from pathlib import Path
from statistics import median
import tempfile

import psutil

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest


root = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
tempfile.tempdir = str(work)
previous = root / "build/trained-operator-validation-20261109-211516"
artifact = previous / "pythia-artifacts/decoder-32.leaf"
exe = root / "build/fp32-long-20261115/wheel-venv/Lib/site-packages/leaf/bin/leaf_decoder.exe"
ids = json.loads((previous / "pythia-quality/tokens.json").read_bytes())["sequences"][0][:64]
assert len(ids) == 64
os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
process = psutil.Process()
original = process.cpu_affinity()
record = dict(complete=False, permitted_cpus=[0, 2], prompt_ids=ids, power_mode={}, rows=[],
              fingerprints=dict(artifact=digest(artifact), binary=digest(exe)))
cases = [(1, False), (1, True), (2, False), (2, True)]
try:
    process.cpu_affinity(record["permitted_cpus"])
    with keep_awake(), benchmark_power_mode_guard(record["power_mode"], required_mode="better-battery"):
        for workers, scalar in [*cases, *reversed(cases)]:
            _, native = run_native(exe, artifact, [ids], mode="bench-generate", threads=workers,
                                   runs=6, warmup=2, generate=16, scalar=scalar, fp32_math="accurate")
            assert native["avx2"] is not scalar and native["benchmark_ac_checked"]
            assert len(native["generated_tokens"]) == 16
            if record["rows"]:
                assert record["rows"][0]["native"]["generated_tokens"] == native["generated_tokens"]
            record["rows"].append(dict(workers=workers, forced_scalar=scalar, native=native))
            print(workers, scalar, native["prefill_p50_ms"], native["decode_p50_ms"], flush=True)
    summary = {}
    for workers, scalar in cases:
        samples = [r["native"] for r in record["rows"] if (r["workers"], r["forced_scalar"]) == (workers, scalar)]
        phases = dict(
            prefill=[x for row in samples for x in row["prefill_samples_ms"]],
            decode=[median(steps) for row in samples for steps in row["decode_steps_by_generation_ms"]],
        )
        summary[f"{workers}-{'scalar' if scalar else 'avx2'}"] = {
            name: dict(p50_ms=median(rows), stability=latency_stability(rows)) for name, rows in phases.items()
        }
    record["summary"] = summary
    record["complete"] = True
finally:
    process.cpu_affinity(original)
    write_record(work / "native-scalar.json", record)
