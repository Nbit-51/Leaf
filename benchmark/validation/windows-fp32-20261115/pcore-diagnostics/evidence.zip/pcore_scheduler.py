"""Validate scheduling fallbacks with one and two visible P-cores."""
import json
from pathlib import Path
import tempfile

import numpy as np
import psutil

from leaf.evaluation import write_record
from tools.benchmark_core_scaling import validate_cores
from tools.decoder_validation import run_native
from tools.diagnose_windows_benchmark import cpu_sets
from tools.validate_decoder import digest


work = Path(__file__).resolve().parent
tempfile.tempdir = str(work / "tmp")
cpus = [0, 2, 4, 6]
topology = cpu_sets()
pcores = validate_cores(cpus, topology)
assert pcores[0]["efficiency_class"] == max(row["efficiency_class"] for row in topology)
exe = work / "wheel-venv/Lib/site-packages/leaf/bin/leaf_decoder.exe"
artifact = Path(json.loads((work / "parallel-quality.json").read_bytes())["models"]["opt"]["artifact"])
tokens = work / "parallel-opt-tokens.json"
ids = json.loads(tokens.read_bytes())["benchmark_ids"]
process = psutil.Process()
original = process.cpu_affinity()
reference, _ = run_native(exe, artifact, [ids], mode="chunked", chunk=768,
                          threads=4, worker_cpus=cpus, fp32_math="accurate")
_, generation = run_native(exe, artifact, [ids[:64]], mode="generate", generate=16,
                           threads=4, worker_cpus=cpus, fp32_math="accurate")
report = dict(complete=False, scope=__doc__, pcores=pcores, artifact_sha256=digest(artifact),
              executable_sha256=digest(exe), token_fixture_sha256=digest(tokens), cases={})
try:
    for case, allowed, workers, scalar, length in (
        ("one_worker", [2], 1, False, 768),
        ("two_workers", [0, 2], 2, False, 768),
        ("forced_scalar", [2], 1, True, 64),
    ):
        process.cpu_affinity(allowed)
        assert sorted(process.cpu_affinity()) == allowed
        options = dict(threads=workers, scalar=scalar, fp32_math="accurate")
        actual, metrics = run_native(exe, artifact, [ids[:length+1]], mode="chunked", chunk=length, **options)
        if length == 768:
            expected = reference
        else:
            # Match the length of the first prefill and the position of the cached step.
            expected, _ = run_native(exe, artifact, [ids[:length+1]], mode="chunked", chunk=length,
                                     threads=1, fp32_math="accurate")
        _, continuation = run_native(exe, artifact, [ids[:64]], mode="generate", generate=16, **options)
        assert actual.shape == expected.shape and np.isfinite(actual).all()
        assert metrics["threads"] == workers and metrics["worker_cpus"] == []
        assert metrics["optimized_fp32_active"] is not scalar
        assert continuation["generated_tokens"] == generation["generated_tokens"]
        error = float(np.max(np.abs(actual - expected)))
        assert np.allclose(actual, expected, atol=2e-4, rtol=2e-4)
        report["cases"][case] = dict(allowed_cpus=allowed, worker_threads=workers, explicit_worker_pinning=False,
                                     prompt_tokens=length, checked_logits=int(actual.size), max_abs_error=error,
                                     continuation_exact=True, optimized_fp32_active=metrics["optimized_fp32_active"])
        print(case, error, flush=True)
    report["complete"] = True
finally:
    process.cpu_affinity(original)
    write_record(work / "opt-pcore-scheduling.json", report)
