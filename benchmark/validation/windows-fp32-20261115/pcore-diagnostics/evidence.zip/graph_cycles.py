"""Diagnostic per-inference cycle accounting on one P-core."""
import json
from pathlib import Path
from statistics import median
from types import SimpleNamespace

from benchmark.bench_graph_onnxruntime import leaf_run, require_parity
from leaf.affinity import pin_cpu
from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.validate_decoder import digest


root = Path(__file__).resolve().parent
work = root / "graphs"
pin_cpu(2)
report = dict(complete=False, scope=__doc__, cpu=2, power_mode={}, models={})
binaries = {side: work / name for side, name in
            (("previous", "old-counters.exe"), ("dispatch", "new-counters.exe"))}
report["hashes"] = {str(path): digest(path) for path in (*binaries.values(), work / "dataset-counters.cpp")}
try:
    with keep_awake(), benchmark_power_mode_guard(report["power_mode"], required_mode="better-battery"):
        for model in ("resnet20", "vgg11"):
            fixture = work / model
            artifact = fixture / "graph.leaf"
            data = tuple(fixture / name for name in ("inputs.bin", "logits.bin", "labels.u32"))
            report["hashes"].update({str(path): digest(path) for path in (artifact, *data)})
            results = {"rounds": []}
            report["models"][model] = results
            for i, order in enumerate((("previous","dispatch"),("dispatch","previous"))):
                record = dict(order=order)
                for side in order:
                    require_benchmark_ac()
                    result = leaf_run(SimpleNamespace(executable=binaries[side], shape=(3,32,32)),
                                      (*data, 101), artifact, work / f"{model}-counters-{side}-{i}.json")
                    require_benchmark_ac()
                    require_parity(result, 101)
                    counters = result["counters"]
                    assert all(v == 2 for key in ("caller_cpu_start", "caller_cpu_end") for v in counters[key])
                    assert all(v == 0 for key in ("caller_group_start", "caller_group_end") for v in counters[key])
                    assert len(result["latency_samples_ms"]) == len(counters["caller_cycles"]) == 101
                    assert all(v > 0 for v in counters["caller_cycles"])
                    record[side] = result
                results["rounds"].append(record)
            summary = {}
            for side in binaries:
                records = [row[side] for row in results["rounds"]]
                summary[side] = dict(
                    median_thread_cycles=median(v for row in records for v in row["counters"]["caller_cycles"]),
                    median_ms=median(v for row in records for v in row["latency_samples_ms"]),
                    page_faults=sum(v for row in records for v in row["counters"]["process_page_faults"]),
                )
            results["summary"] = summary
            print(model, summary, flush=True)
    assert all(digest(Path(path)) == sha for path, sha in report["hashes"].items())
    report["complete"] = True
finally:
    write_record(work / "cycle-diagnostics.json", report)
