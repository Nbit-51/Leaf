#include "leaf/runtime/decoder.h"
#include "leaf/runtime/host_support.h"
#include "leaf/runtime/decoder_config.h"
#include "leaf/runtime/kv_cache.h"
#ifdef LEAF_DIAGNOSTIC_TRACE
#include "../../tests/native/decoder_trace.h"
#define LEAF_TRACE(name, values) trace.write(name, values)
#else
#define LEAF_TRACE(name, values) ((void)0)
#endif
#include "leaf/kernels/token_panel.h"
#include "leaf/kernels/accurate_fp32.h"
#ifdef LEAF_EXPERIMENTAL_GELU_ERF
#include "leaf/kernels/gelu_erf.h"
#endif
#if LEAF_OPTIMIZED_SILU_W8A8 || LEAF_OPTIMIZED_SILU_FP32 || defined(LEAF_EXPERIMENTAL_SILU_GATE)
#include "leaf/kernels/silu_gate.h"
#endif
#ifdef LEAF_DIAGNOSTIC_TIMING
#include "../../tests/native/decoder_diagnostic.h"
#endif
#if LEAF_OPTIMIZED_FP32 || defined(LEAF_EXPERIMENTAL_GEMV_PAIR) || defined(LEAF_TEST_GEMV)
#include "leaf/kernels/gemv_pair.h"
#endif
#if LEAF_OPTIMIZED_FP32 || defined(LEAF_EXPERIMENTAL_ROW_REUSE)
#include "leaf/kernels/row_reuse.h"
#endif
#include "leaf/kernels/source_bf16.h"
#if LEAF_OPTIMIZED_FP32 || defined(LEAF_EXPERIMENTAL_ATTENTION_AVX2)
#include "leaf/kernels/attention_vector.h"
#endif
#if LEAF_OPTIMIZED_FP32 || defined(LEAF_EXPERIMENTAL_VECTOR_GELU)
#include "leaf/kernels/gelu.h"
#endif

#include <algorithm>
#include <atomic>
#include <array>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <iostream>
#include <limits>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <thread>
#include <unordered_map>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

#if (defined(__x86_64__) || defined(__i386__)) && defined(__GNUC__)
#include <immintrin.h>
#define LEAF_DECODER_AVX 1
#define LEAF_AVX_TARGET __attribute__((target("avx2,fma")))
#else
#define LEAF_DECODER_AVX 0
#endif

#if LEAF_DECODER_AVX && ((!defined(__clang__) && __GNUC__ >= 11) || (defined(__clang__) && __clang_major__ >= 15))
#define LEAF_DECODER_VNNI 1
#define LEAF_VNNI_TARGET __attribute__((target("avx2,avxvnni")))
#else
#define LEAF_DECODER_VNNI 0
#endif

namespace leaf::runtime {
namespace {

constexpr std::size_t parallel_prefill_tokens = 768;
constexpr std::size_t parallel_decode_context = 512;
constexpr std::size_t bf16_max_expanded_values = (32 * 1024 * 1024) / sizeof(float);
void check(bool valid, const std::string& message) {
    if (!valid) throw std::runtime_error("Leaf decoder: " + message);
}

// v6 extends original-source BF16 storage to canonical matrices only. Norms,
// biases and calibration vectors keep FP32 storage; a shape alone does not
// authorize a new tensor role. v5 retains its narrower historical I/O policy.
bool source_bf16_matrix(const std::string& name, std::size_t rows, std::size_t layers) {
    if (rows <= 1) return false;
    if (name == "lm_head.weight" || name == "model.embed_tokens.weight" ||
        name == "model.position_embeddings.weight") return true;
    const std::string prefix = "model.layers.";
    if (name.compare(0, prefix.size(), prefix) != 0) return false;
    const auto end = name.find('.', prefix.size());
    if (end == std::string::npos || end == prefix.size() ||
        (end > prefix.size() + 1 && name[prefix.size()] == '0')) return false;
    std::size_t layer = 0;
    for (auto i = prefix.size(); i < end; ++i) {
        if (name[i] < '0' || name[i] > '9') return false;
        const auto digit = static_cast<std::size_t>(name[i] - '0');
        if (layer > (std::numeric_limits<std::size_t>::max() - digit) / 10) return false;
        layer = layer * 10 + digit;
    }
    if (layer >= layers) return false;
    const auto role = name.substr(end + 1);
    return role == "self_attn.q_proj.weight" || role == "self_attn.k_proj.weight" ||
           role == "self_attn.v_proj.weight" || role == "self_attn.o_proj.weight" ||
           role == "mlp.up_proj.weight" || role == "mlp.gate_proj.weight" ||
           role == "mlp.down_proj.weight";
}

// Optional diagnostics only: fixed operation classes keep profiling independent
// of import-adapter names. A disabled scope never reads the clock or aggregates.
class DecoderProfile {
public:
    enum class Phase : std::size_t {
        Forward, Embedding, RMSNorm, LayerNorm, LinearFP32, LinearW8A32,
        LinearW4A32, LinearW8A8, LinearW4A8, RoPE, PositionReorder,
        Attention, Activation, KVAppend, CausalMask, Residual, Count
    };
    DecoderProfile() {
        const char* value = std::getenv("LEAF_DECODER_PROFILE");
        enabled_ = value && value[0];
    }
    void forward_tokens(std::size_t tokens) noexcept { bucket_ = tokens == 1 ? 1 : 0; }
    class Scope {
    public:
        Scope(DecoderProfile& profile, Phase phase, std::size_t tokens)
            : profile_(profile.enabled_ ? &profile : nullptr), phase_(phase), tokens_(tokens) {
            if (profile_) start_ = Clock::now();
        }
        ~Scope() {
            if (profile_) {
                auto& total = profile_->totals_[profile_->bucket_][static_cast<std::size_t>(phase_)];
                ++total.calls; total.tokens += tokens_;
                total.milliseconds += std::chrono::duration<double, std::milli>(Clock::now() - start_).count();
            }
        }
        Scope(const Scope&) = delete;
        Scope& operator=(const Scope&) = delete;
    private:
        using Clock = std::chrono::steady_clock;
        DecoderProfile* profile_;
        Phase phase_;
        std::size_t tokens_;
        Clock::time_point start_{};
    };
    // Nested projection roles are reported separately from the nonoverlapping
    // phase breakdown. Disabled diagnostics never read the clock or aggregate.
    class LinearScope {
    public:
        LinearScope(DecoderProfile& profile, bool mlp, bool packing, std::size_t tokens)
            : profile_(profile.enabled_ ? &profile : nullptr),
              part_((packing ? 2u : 0u) + (mlp ? 0u : 1u)), tokens_(tokens) {
            if (profile_) start_ = Clock::now();
        }
        ~LinearScope() {
            if (profile_) {
                auto& total = profile_->linear_details_[profile_->bucket_][part_];
                ++total.calls; total.tokens += tokens_;
                total.milliseconds += std::chrono::duration<double, std::milli>(Clock::now() - start_).count();
            }
        }
        LinearScope(const LinearScope&) = delete;
        LinearScope& operator=(const LinearScope&) = delete;
    private:
        using Clock = std::chrono::steady_clock;
        DecoderProfile* profile_;
        unsigned part_;
        std::size_t tokens_;
        Clock::time_point start_{};
    };
    void packed_input(bool reused) noexcept {
        if (enabled_) ++(reused ? reuses_[bucket_] : packs_[bucket_]);
    }
    void emit() const noexcept {
        if (!enabled_) return;
        // Destruction must not turn a successful inference into a failure if
        // diagnostics cannot be allocated or stderr has been closed.
        try {
            static const char* names[] = {
                "forward", "embedding", "rms_norm", "layer_norm", "linear_fp32", "linear_w8a32",
                "linear_w4a32", "linear_w8a8", "linear_w4a8", "rope", "position_reorder",
                "attention", "activation", "kv_append", "causal_mask", "residual"
            };
            std::ostringstream output; output.precision(10);
            output << "{\"leaf_decoder_profile\":1,\"clock\":\"steady_clock\","
                      "\"bucket_by\":\"forward_input_tokens\",\"timings\":{";
            for (std::size_t bucket = 0; bucket < totals_.size(); ++bucket) {
                output << (bucket ? ",\"decode\":{" : "\"prefill\":{");
                bool first = true;
                for (std::size_t phase = 0; phase < names_count; ++phase) {
                    const auto& total = totals_[bucket][phase];
                    if (!total.calls) continue;
                    output << (first ? "" : ",") << '"' << names[phase]
                           << "\":{\"calls\":" << total.calls << ",\"tokens\":" << total.tokens
                           << ",\"milliseconds\":" << total.milliseconds << '}';
                    first = false;
                }
                output << '}';
            }
            output << "},\"linear_details\":{";
            static const char* linear_names[] = {"mlp_total", "other_total", "mlp_pack", "other_pack"};
            for (std::size_t bucket = 0; bucket < linear_details_.size(); ++bucket) {
                output << (bucket ? ",\"decode\":{" : "\"prefill\":{");
                for (std::size_t part = 0; part < 4; ++part) {
                    const auto& total = linear_details_[bucket][part];
                    output << (part ? "," : "") << '\"' << linear_names[part]
                           << "\":{\"calls\":" << total.calls << ",\"tokens\":" << total.tokens
                           << ",\"milliseconds\":" << total.milliseconds << '}';
                }
                output << ",\"packs\":" << packs_[bucket] << ",\"reuses\":" << reuses_[bucket] << '}';
            }
            output << "}}\n"; std::cerr << output.str();
        } catch (...) {}
    }
private:
    struct Total { std::uint64_t calls = 0, tokens = 0; double milliseconds = 0; };
    static constexpr auto names_count = static_cast<std::size_t>(Phase::Count);
    std::array<std::array<Total, names_count>, 2> totals_{};
    std::array<std::array<Total, 4>, 2> linear_details_{};
    std::array<std::uint64_t, 2> packs_{}, reuses_{};
    bool enabled_ = false;
    std::size_t bucket_ = 0;
};

using detail::Mapping;
using detail::Reader;
using detail::Workers;

struct Weight {
    std::size_t rows = 0, cols = 0, bits = 0, group = 0;
    const std::uint8_t* data = nullptr;
    const float* scales = nullptr;
    std::vector<std::int32_t> signed_sums;
    float value(std::size_t row, std::size_t col) const {
        const std::size_t index = row * cols + col;
        if (bits == 32) return reinterpret_cast<const float*>(data)[index];
        if (bits == 16) return leaf::kernels::source_bf16_value(reinterpret_cast<const std::uint16_t*>(data)[index]);
        int quantized;
        if (bits == 8) quantized = reinterpret_cast<const std::int8_t*>(data)[index];
        else { quantized = (data[index / 2] >> ((index % 2) * 4)) & 15;
               if (quantized >= 8) quantized -= 16; }
        return static_cast<float>(quantized) * scales[row * (cols / group) + col / group];
    }
};

using Dot = void (*)(const Weight&, std::size_t, const float*, std::size_t, float*);
using QuantDot = void (*)(const Weight&, std::size_t, const std::int16_t*,
                         std::size_t, const float*, float*);
void dot_scalar(const Weight& w, std::size_t row, const float* inputs, std::size_t tokens, float* result) {
    std::fill_n(result, tokens, 0.0f);
    for (std::size_t col = 0; col < w.cols; ++col) {
        const float value = w.value(row, col);
        for (std::size_t t = 0; t < tokens; ++t) result[t] += value * inputs[t * w.cols + col];
    }
}

void dot_scalar_precise(const Weight& w, std::size_t row, const float* inputs,
                        std::size_t tokens, float* result) {
    for (std::size_t token = 0; token < tokens; ++token) {
        double total = 0.0;
        for (std::size_t col = 0; col < w.cols; ++col)
            total += static_cast<double>(w.value(row, col)) * inputs[token * w.cols + col];
        result[token] = static_cast<float>(total);
    }
}

void quant_dot_scalar(const Weight& w, std::size_t row, const std::int16_t* inputs,
                      std::size_t tokens, const float* input_scales, float* result) {
    std::fill_n(result, tokens, 0.0f);
    for (std::size_t first = 0; first < w.cols; first += w.group) {
        for (std::size_t t = 0; t < tokens; ++t) {
            std::int32_t accumulator = 0;
            for (std::size_t col = first; col < first + w.group; ++col) {
                const auto index = row * w.cols + col;
                int value = w.bits == 8 ? reinterpret_cast<const std::int8_t*>(w.data)[index] :
                                         (w.data[index / 2] >> ((index % 2) * 4)) & 15;
                if (w.bits == 4 && value >= 8) value -= 16;
                accumulator += value * inputs[t * w.cols + col];
            }
            result[t] += static_cast<float>(accumulator) * input_scales[t] *
                         w.scales[row * (w.cols / w.group) + first / w.group];
        }
    }
}

#if LEAF_DECODER_AVX
LEAF_AVX_TARGET float reduce(__m256 v) {
    const __m128 halves = _mm_add_ps(_mm256_castps256_ps128(v), _mm256_extractf128_ps(v, 1));
    const __m128 pairs = _mm_add_ps(halves, _mm_movehl_ps(halves, halves));
    return _mm_cvtss_f32(_mm_add_ss(pairs, _mm_shuffle_ps(pairs, pairs, 1)));
}
__attribute__((always_inline)) LEAF_AVX_TARGET inline __m256 weight8(
        const Weight& w, std::size_t row, std::size_t col) {
        __m256 values;
        const std::size_t index = row * w.cols + col;
        if (w.bits == 32) values = _mm256_loadu_ps(reinterpret_cast<const float*>(w.data) + index);
        else {
            __m256i integers;
            if (w.bits == 8) {
                integers = _mm256_cvtepi8_epi32(_mm_loadl_epi64(reinterpret_cast<const __m128i*>(w.data + index)));
            } else {
                std::uint32_t packed;
                std::memcpy(&packed, w.data + index / 2, 4);
                const __m256i lanes = _mm256_setr_epi32(0, 4, 8, 12, 16, 20, 24, 28);
                integers = _mm256_and_si256(_mm256_srlv_epi32(_mm256_set1_epi32(packed), lanes),
                                             _mm256_set1_epi32(15));
                integers = _mm256_sub_epi32(_mm256_xor_si256(integers, _mm256_set1_epi32(8)),
                                             _mm256_set1_epi32(8));
            }
            values = _mm256_cvtepi32_ps(integers);
        }
        return values;
}
template <unsigned Bits>
__attribute__((always_inline)) LEAF_AVX_TARGET inline __m256 fixed_weight8(
        const Weight& w, std::size_t row, std::size_t col) {
    if constexpr (Bits == 32)
        return _mm256_loadu_ps(reinterpret_cast<const float*>(w.data) + row * w.cols + col);
    if constexpr (Bits == 8)
        return _mm256_cvtepi32_ps(_mm256_cvtepi8_epi32(
            _mm_loadl_epi64(reinterpret_cast<const __m128i*>(w.data + row * w.cols + col))));
    return weight8(w, row, col);
}
template <unsigned Bits>
LEAF_AVX_TARGET void dot_one_avx(const Weight& w, std::size_t row, const float* input, float* result) {
    *result = 0.0f;
    const auto group = Bits == 32 ? w.cols : w.group;
    const auto groups = w.cols / group;
    for (std::size_t first = 0; first < w.cols; first += group) {
        __m256 a = _mm256_setzero_ps(), b = a, c = a, d = a;
        std::size_t col = first;
        const auto end = first + group;
        for (; col + 32 <= end; col += 32) {
            a = _mm256_fmadd_ps(fixed_weight8<Bits>(w, row, col), _mm256_loadu_ps(input + col), a);
            b = _mm256_fmadd_ps(fixed_weight8<Bits>(w, row, col + 8), _mm256_loadu_ps(input + col + 8), b);
            c = _mm256_fmadd_ps(fixed_weight8<Bits>(w, row, col + 16), _mm256_loadu_ps(input + col + 16), c);
            d = _mm256_fmadd_ps(fixed_weight8<Bits>(w, row, col + 24), _mm256_loadu_ps(input + col + 24), d);
        }
        a = _mm256_add_ps(_mm256_add_ps(a, b), _mm256_add_ps(c, d));
        for (; col + 8 <= end; col += 8)
            a = _mm256_fmadd_ps(fixed_weight8<Bits>(w, row, col), _mm256_loadu_ps(input + col), a);
        float partial = reduce(a);
        const auto scale = Bits == 32 ? 1.0f : w.scales[row * groups + first / group];
        for (; col < end; ++col) partial += (w.value(row, col) / scale) * input[col];
        *result += partial * scale;
    }
}
LEAF_AVX_TARGET void dot_avx(const Weight& w, std::size_t row, const float* inputs,
                            std::size_t tokens, float* result) {
    std::fill_n(result, tokens, 0.0f);
    const std::size_t group = w.bits == 32 ? w.cols : w.group;
    const std::size_t groups = w.cols / group;
    for (std::size_t index = 0; index < groups; ++index) {
        __m256 a = _mm256_setzero_ps(), b = a, c = a, d = a;
        std::size_t col = index * group;
        const std::size_t end = col + group;
        if (tokens == 1) {
            // Four independent sums hide FMA dependency latency during GEMV.
            for (; col + 32 <= end; col += 32) {
                a = _mm256_fmadd_ps(weight8(w, row, col), _mm256_loadu_ps(inputs + col), a);
                b = _mm256_fmadd_ps(weight8(w, row, col + 8), _mm256_loadu_ps(inputs + col + 8), b);
                c = _mm256_fmadd_ps(weight8(w, row, col + 16), _mm256_loadu_ps(inputs + col + 16), c);
                d = _mm256_fmadd_ps(weight8(w, row, col + 24), _mm256_loadu_ps(inputs + col + 24), d);
            }
            a = _mm256_add_ps(_mm256_add_ps(a, b), _mm256_add_ps(c, d));
        }
        // Explicit registers avoid spills; scales are applied once per group,
        // removing per-vector integer division and dequantization multiplies.
        for (; col + 8 <= end; col += 8) {
            const auto values = weight8(w, row, col);
            a = _mm256_fmadd_ps(values, _mm256_loadu_ps(inputs + col), a);
            if (tokens > 1) b = _mm256_fmadd_ps(values, _mm256_loadu_ps(inputs + w.cols + col), b);
            if (tokens > 2) c = _mm256_fmadd_ps(values, _mm256_loadu_ps(inputs + 2 * w.cols + col), c);
            if (tokens > 3) d = _mm256_fmadd_ps(values, _mm256_loadu_ps(inputs + 3 * w.cols + col), d);
        }
        float partial[4] = {reduce(a), reduce(b), reduce(c), reduce(d)};
        const float scale = w.bits == 32 ? 1.0f : w.scales[row * groups + index];
        for (; col < end; ++col) {
            const float value = w.value(row, col) / scale;
            for (std::size_t t = 0; t < tokens; ++t) partial[t] += value * inputs[t * w.cols + col];
        }
        for (std::size_t t = 0; t < tokens; ++t) result[t] += partial[t] * scale;
    }
}
LEAF_AVX_TARGET void dot_source_bf16_avx(const Weight& w, std::size_t row, const float* inputs,
                                      std::size_t tokens, float* result) {
    std::fill_n(result, tokens, 0.0f);
    const auto* weights = reinterpret_cast<const std::uint16_t*>(w.data) + row * w.cols;
    auto a = _mm256_setzero_ps(), b = a, c = a, d = a;
    std::size_t col = 0;
    if (tokens == 1) {
        for (; col + 32 <= w.cols; col += 32) {
            a = _mm256_fmadd_ps(leaf::kernels::source_bf16_detail::load8(weights + col), _mm256_loadu_ps(inputs + col), a);
            b = _mm256_fmadd_ps(leaf::kernels::source_bf16_detail::load8(weights + col + 8), _mm256_loadu_ps(inputs + col + 8), b);
            c = _mm256_fmadd_ps(leaf::kernels::source_bf16_detail::load8(weights + col + 16), _mm256_loadu_ps(inputs + col + 16), c);
            d = _mm256_fmadd_ps(leaf::kernels::source_bf16_detail::load8(weights + col + 24), _mm256_loadu_ps(inputs + col + 24), d);
        }
        a = _mm256_add_ps(_mm256_add_ps(a, b), _mm256_add_ps(c, d));
    }
    for (; col + 8 <= w.cols; col += 8) {
        const auto values = leaf::kernels::source_bf16_detail::load8(weights + col);
        a = _mm256_fmadd_ps(values, _mm256_loadu_ps(inputs + col), a);
        if (tokens > 1) b = _mm256_fmadd_ps(values, _mm256_loadu_ps(inputs + w.cols + col), b);
        if (tokens > 2) c = _mm256_fmadd_ps(values, _mm256_loadu_ps(inputs + 2 * w.cols + col), c);
        if (tokens > 3) d = _mm256_fmadd_ps(values, _mm256_loadu_ps(inputs + 3 * w.cols + col), d);
    }
    float partial[4] = {reduce(a), reduce(b), reduce(c), reduce(d)};
    for (; col < w.cols; ++col) {
        const float value = w.value(row, col);
        for (std::size_t t = 0; t < tokens; ++t) partial[t] += value * inputs[t * w.cols + col];
    }
    for (std::size_t t = 0; t < tokens; ++t) result[t] += partial[t];
}
LEAF_AVX_TARGET void dot_specialized_avx(const Weight& w, std::size_t row, const float* inputs,
                                       std::size_t tokens, float* result) {
    if (tokens == 1 && w.bits == 32) { dot_one_avx<32>(w, row, inputs, result); return; }
    if (tokens == 1 && w.bits == 8) { dot_one_avx<8>(w, row, inputs, result); return; }
    dot_avx(w, row, inputs, tokens, result);
}
LEAF_AVX_TARGET void float_tile_avx(const Weight& w, std::size_t row,
        const float* inputs, std::size_t tokens, float* result) {
    // Two rows share four input vectors. Eight independent FMA chains avoid
    // the four-chain dependency bottleneck without packing or expanding weights.
    // Preserve the per-output accumulation/reduction order of dot_avx.
    std::fill_n(result, 8, 0.0f);
    if (tokens == 1) {
        // An odd-token prefill tail must keep dot_avx's four-chain GEMV order.
        dot_avx(w, row, inputs, 1, result);
        dot_avx(w, row + 1, inputs, 1, result + 4);
        return;
    }
    const auto group = w.bits == 32 ? w.cols : w.group;
    const auto groups = w.cols / group;
    for (std::size_t first = 0; first < w.cols; first += group) {
        __m256 a0 = _mm256_setzero_ps(), b0 = a0, c0 = a0, d0 = a0;
        __m256 a1 = a0, b1 = a0, c1 = a0, d1 = a0;
        std::size_t col = first;
        const auto end = first + group;
        for (; col + 8 <= end; col += 8) {
            const auto x0 = _mm256_loadu_ps(inputs + col);
            const auto x1 = tokens > 1 ? _mm256_loadu_ps(inputs + w.cols + col) : _mm256_setzero_ps();
            const auto x2 = tokens > 2 ? _mm256_loadu_ps(inputs + 2 * w.cols + col) : _mm256_setzero_ps();
            const auto x3 = tokens > 3 ? _mm256_loadu_ps(inputs + 3 * w.cols + col) : _mm256_setzero_ps();
            auto weight = weight8(w, row, col);
            a0 = _mm256_fmadd_ps(weight, x0, a0); b0 = _mm256_fmadd_ps(weight, x1, b0);
            c0 = _mm256_fmadd_ps(weight, x2, c0); d0 = _mm256_fmadd_ps(weight, x3, d0);
            weight = weight8(w, row + 1, col);
            a1 = _mm256_fmadd_ps(weight, x0, a1); b1 = _mm256_fmadd_ps(weight, x1, b1);
            c1 = _mm256_fmadd_ps(weight, x2, c1); d1 = _mm256_fmadd_ps(weight, x3, d1);
        }
        float partial[8] = {reduce(a0), reduce(b0), reduce(c0), reduce(d0),
                            reduce(a1), reduce(b1), reduce(c1), reduce(d1)};
        for (std::size_t r = 0; r < 2; ++r) {
            const auto scale = w.bits == 32 ? 1.0f : w.scales[(row + r) * groups + first / group];
            for (std::size_t k = col; k < end; ++k) {
                const auto value = w.value(row + r, k) / scale;
                for (std::size_t t = 0; t < tokens; ++t)
                    partial[r * 4 + t] += value * inputs[t * w.cols + k];
            }
            for (std::size_t t = 0; t < tokens; ++t) result[r * 4 + t] += partial[r * 4 + t] * scale;
        }
    }
}
template <unsigned Bits>
LEAF_AVX_TARGET void float_tile4_avx(const Weight& w, std::size_t row,
        const float* inputs, float* result) {
    static_assert(Bits == 32 || Bits == 8, "full-token float tile requires FP32 or INT8 weights");
    // A full four-token tile has no token-count/precision branches in its
    // column loop. Keep the same FMA chains, reductions and group scaling as
    // the generic tile; partial tiles and packed INT4 use that existing path.
    std::fill_n(result, 8, 0.0f);
    const auto group = Bits == 32 ? w.cols : w.group;
    const auto groups = w.cols / group;
    for (std::size_t first = 0; first < w.cols; first += group) {
        __m256 a0 = _mm256_setzero_ps(), b0 = a0, c0 = a0, d0 = a0;
        __m256 a1 = a0, b1 = a0, c1 = a0, d1 = a0;
        std::size_t col = first;
        const auto end = first + group;
        for (; col + 8 <= end; col += 8) {
            const auto x0 = _mm256_loadu_ps(inputs + col);
            const auto x1 = _mm256_loadu_ps(inputs + w.cols + col);
            const auto x2 = _mm256_loadu_ps(inputs + 2 * w.cols + col);
            const auto x3 = _mm256_loadu_ps(inputs + 3 * w.cols + col);
            __m256 weight;
            if constexpr (Bits == 32)
                weight = _mm256_loadu_ps(reinterpret_cast<const float*>(w.data) + row * w.cols + col);
            else
                weight = _mm256_cvtepi32_ps(_mm256_cvtepi8_epi32(
                    _mm_loadl_epi64(reinterpret_cast<const __m128i*>(w.data + row * w.cols + col))));
            a0 = _mm256_fmadd_ps(weight, x0, a0); b0 = _mm256_fmadd_ps(weight, x1, b0);
            c0 = _mm256_fmadd_ps(weight, x2, c0); d0 = _mm256_fmadd_ps(weight, x3, d0);
            if constexpr (Bits == 32)
                weight = _mm256_loadu_ps(reinterpret_cast<const float*>(w.data) + (row + 1) * w.cols + col);
            else
                weight = _mm256_cvtepi32_ps(_mm256_cvtepi8_epi32(
                    _mm_loadl_epi64(reinterpret_cast<const __m128i*>(w.data + (row + 1) * w.cols + col))));
            a1 = _mm256_fmadd_ps(weight, x0, a1); b1 = _mm256_fmadd_ps(weight, x1, b1);
            c1 = _mm256_fmadd_ps(weight, x2, c1); d1 = _mm256_fmadd_ps(weight, x3, d1);
        }
        float partial[8] = {reduce(a0), reduce(b0), reduce(c0), reduce(d0),
                            reduce(a1), reduce(b1), reduce(c1), reduce(d1)};
        for (std::size_t r = 0; r < 2; ++r) {
            const auto scale = Bits == 32 ? 1.0f : w.scales[(row + r) * groups + first / group];
            for (std::size_t k = col; k < end; ++k) {
                const auto value = w.value(row + r, k) / scale;
                for (std::size_t t = 0; t < 4; ++t)
                    partial[r * 4 + t] += value * inputs[t * w.cols + k];
            }
            for (std::size_t t = 0; t < 4; ++t) result[r * 4 + t] += partial[r * 4 + t] * scale;
        }
    }
}
__attribute__((always_inline)) LEAF_AVX_TARGET inline __m256i weight16(
        const Weight& w, std::size_t row, std::size_t col) {
    const auto index = row * w.cols + col;
    if (w.bits == 8) return _mm256_cvtepi8_epi16(_mm_loadu_si128(reinterpret_cast<const __m128i*>(w.data + index)));
    const auto packed = _mm_loadl_epi64(reinterpret_cast<const __m128i*>(w.data + index / 2));
    const auto nibble_mask = _mm_set1_epi8(15);
    const auto low = _mm_and_si128(packed, nibble_mask);
    const auto high = _mm_and_si128(_mm_srli_epi16(packed, 4), nibble_mask);
    const auto expanded = _mm256_cvtepu8_epi16(_mm_unpacklo_epi8(low, high));
    return _mm256_sub_epi16(_mm256_xor_si256(expanded, _mm256_set1_epi16(8)), _mm256_set1_epi16(8));
}
LEAF_AVX_TARGET std::int32_t reduce_integer(__m256i value) {
    auto half = _mm_add_epi32(_mm256_castsi256_si128(value), _mm256_extracti128_si256(value, 1));
    half = _mm_hadd_epi32(half, half); half = _mm_hadd_epi32(half, half);
    return _mm_cvtsi128_si32(half);
}
LEAF_AVX_TARGET void quant_dot_avx(const Weight& w, std::size_t row,
        const std::int16_t* inputs, std::size_t tokens, const float* input_scales, float* result) {
    std::fill_n(result, tokens, 0.0f);
    for (std::size_t first = 0; first < w.cols; first += w.group) {
        __m256i a = _mm256_setzero_si256(), b = a, c = a, d = a;
        std::size_t col = first;
        const auto end = first + w.group;
        if (tokens == 1) {
            for (; col + 64 <= end; col += 64) {
                a = _mm256_add_epi32(a, _mm256_madd_epi16(weight16(w, row, col), _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + col))));
                b = _mm256_add_epi32(b, _mm256_madd_epi16(weight16(w, row, col + 16), _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + col + 16))));
                c = _mm256_add_epi32(c, _mm256_madd_epi16(weight16(w, row, col + 32), _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + col + 32))));
                d = _mm256_add_epi32(d, _mm256_madd_epi16(weight16(w, row, col + 48), _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + col + 48))));
            }
            a = _mm256_add_epi32(_mm256_add_epi32(a, b), _mm256_add_epi32(c, d));
        }
        for (; col + 16 <= end; col += 16) {
            const auto weight = weight16(w, row, col);
            a = _mm256_add_epi32(a, _mm256_madd_epi16(weight, _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + col))));
            if (tokens > 1) b = _mm256_add_epi32(b, _mm256_madd_epi16(weight, _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + w.cols + col))));
            if (tokens > 2) c = _mm256_add_epi32(c, _mm256_madd_epi16(weight, _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + 2 * w.cols + col))));
            if (tokens > 3) d = _mm256_add_epi32(d, _mm256_madd_epi16(weight, _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + 3 * w.cols + col))));
        }
        std::int32_t accumulators[4] = {reduce_integer(a), reduce_integer(b), reduce_integer(c), reduce_integer(d)};
        for (; col < end; ++col) {
            const auto index = row * w.cols + col;
            int value = w.bits == 8 ? reinterpret_cast<const std::int8_t*>(w.data)[index] :
                                     (w.data[index / 2] >> ((index % 2) * 4)) & 15;
            if (w.bits == 4 && value >= 8) value -= 16;
            for (std::size_t t = 0; t < tokens; ++t) accumulators[t] += value * inputs[t * w.cols + col];
        }
        const float scale = w.scales[row * (w.cols / w.group) + first / w.group];
        for (std::size_t t = 0; t < tokens; ++t) result[t] += static_cast<float>(accumulators[t]) * input_scales[t] * scale;
    }
}
LEAF_AVX_TARGET void quant_tile_avx(const Weight& w, std::size_t row,
        const std::int16_t* inputs, std::size_t tokens, const float* input_scales, float* result) {
    // Four output rows share each pair of input vectors. Eight independent
    // sums fit in AVX2 registers without spilling the prefill micro-tile.
    std::fill_n(result, 8, 0.0f);
    const auto groups = w.cols / w.group;
    for (std::size_t first = 0; first < w.cols; first += w.group) {
        __m256i a0 = _mm256_setzero_si256(), a1 = a0, a2 = a0, a3 = a0;
        __m256i b0 = a0, b1 = a0, b2 = a0, b3 = a0;
        std::size_t col = first;
        const auto end = first + w.group;
        for (; col + 16 <= end; col += 16) {
            const auto x0 = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + col));
            const auto x1 = tokens > 1
                ? _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + w.cols + col)) : _mm256_setzero_si256();
            auto weight = weight16(w, row, col);
            a0 = _mm256_add_epi32(a0, _mm256_madd_epi16(weight, x0));
            b0 = _mm256_add_epi32(b0, _mm256_madd_epi16(weight, x1));
            weight = weight16(w, row + 1, col);
            a1 = _mm256_add_epi32(a1, _mm256_madd_epi16(weight, x0));
            b1 = _mm256_add_epi32(b1, _mm256_madd_epi16(weight, x1));
            weight = weight16(w, row + 2, col);
            a2 = _mm256_add_epi32(a2, _mm256_madd_epi16(weight, x0));
            b2 = _mm256_add_epi32(b2, _mm256_madd_epi16(weight, x1));
            weight = weight16(w, row + 3, col);
            a3 = _mm256_add_epi32(a3, _mm256_madd_epi16(weight, x0));
            b3 = _mm256_add_epi32(b3, _mm256_madd_epi16(weight, x1));
        }
        std::int32_t sums[8] = {reduce_integer(a0), reduce_integer(b0),
            reduce_integer(a1), reduce_integer(b1), reduce_integer(a2), reduce_integer(b2),
            reduce_integer(a3), reduce_integer(b3)};
        for (; col < end; ++col) {
            for (std::size_t r = 0; r < 4; ++r) {
                const auto index = (row + r) * w.cols + col;
                int value = w.bits == 8 ? reinterpret_cast<const std::int8_t*>(w.data)[index] :
                                         (w.data[index / 2] >> ((index % 2) * 4)) & 15;
                if (w.bits == 4 && value >= 8) value -= 16;
                for (std::size_t t = 0; t < tokens; ++t) sums[r * 2 + t] += value * inputs[t * w.cols + col];
            }
        }
        for (std::size_t r = 0; r < 4; ++r) {
            const float scale = w.scales[(row + r) * groups + first / w.group];
            for (std::size_t t = 0; t < tokens; ++t)
                result[r * 2 + t] += static_cast<float>(sums[r * 2 + t]) * input_scales[t] * scale;
        }
    }
}
LEAF_AVX_TARGET void quantize_input_avx(const float* input, std::int16_t* output, std::size_t count, float multiplier) {
    std::size_t i = 0;
    const auto factor = _mm256_set1_ps(multiplier);
    for (; i + 8 <= count; i += 8) {
        const auto integers = _mm256_cvtps_epi32(_mm256_mul_ps(_mm256_loadu_ps(input + i), factor));
        const auto halves = _mm_packs_epi32(_mm256_castsi256_si128(integers), _mm256_extracti128_si256(integers, 1));
        _mm_storeu_si128(reinterpret_cast<__m128i*>(output + i), halves);
    }
    for (; i < count; ++i) output[i] = static_cast<std::int16_t>(std::max(-127L, std::min(127L, std::lrint(input[i] * multiplier))));
}
#if LEAF_DECODER_VNNI
LEAF_VNNI_TARGET void prepare_signed_sums(Weight& weight) {
    const auto groups = weight.cols / weight.group;
    weight.signed_sums.resize(weight.rows * groups);
    const auto ones = _mm256_set1_epi8(1);
    for (std::size_t row = 0; row < weight.rows; ++row) {
        for (std::size_t group = 0; group < groups; ++group) {
            const auto first = group * weight.group, end = first + weight.group;
            auto accumulated = _mm256_setzero_si256();
            std::size_t col = first;
            for (; col + 32 <= end; col += 32) {
                const auto bytes = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(weight.data + row * weight.cols + col));
                accumulated = _mm256_dpbusd_avx_epi32(accumulated, ones, bytes);
            }
            auto total = reduce_integer(accumulated);
            for (; col < end; ++col) total += reinterpret_cast<const std::int8_t*>(weight.data)[row * weight.cols + col];
            weight.signed_sums[row * groups + group] = total;
        }
    }
}
LEAF_AVX_TARGET void quantize_input_bytes(const float* input, std::uint8_t* output, std::size_t count, float multiplier) {
    const auto factor = _mm256_set1_ps(multiplier);
    const auto offset = _mm_set1_epi16(128);
    std::size_t col = 0;
    for (; col + 8 <= count; col += 8) {
        const auto integers = _mm256_cvtps_epi32(_mm256_mul_ps(_mm256_loadu_ps(input + col), factor));
        const auto halves = _mm_packs_epi32(_mm256_castsi256_si128(integers), _mm256_extracti128_si256(integers, 1));
        const auto shifted = _mm_add_epi16(halves, offset);
        _mm_storel_epi64(reinterpret_cast<__m128i*>(output + col), _mm_packus_epi16(shifted, shifted));
    }
    for (; col < count; ++col)
        output[col] = static_cast<std::uint8_t>(128 + std::max(-127L, std::min(127L, std::lrint(input[col] * multiplier))));
}
LEAF_VNNI_TARGET void quant_vnni_tile(const Weight& w, std::size_t row, std::size_t rows,
        const std::uint8_t* inputs, std::size_t tokens, const float* input_scales, float* result) {
    std::fill_n(result, 8, 0.0f);
    const auto groups = w.cols / w.group;
    for (std::size_t first = 0; first < w.cols; first += w.group) {
        __m256i a0 = _mm256_setzero_si256(), b0 = a0, c0 = a0, d0 = a0;
        __m256i a1 = a0, b1 = a0, c1 = a0, d1 = a0;
        std::size_t col = first;
        const auto end = first + w.group;
        for (; col + 32 <= end; col += 32) {
            const auto x0 = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + col));
            const auto x1 = tokens > 1 ? _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + w.cols + col)) : _mm256_setzero_si256();
            const auto x2 = tokens > 2 ? _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + 2 * w.cols + col)) : _mm256_setzero_si256();
            const auto x3 = tokens > 3 ? _mm256_loadu_si256(reinterpret_cast<const __m256i*>(inputs + 3 * w.cols + col)) : _mm256_setzero_si256();
            auto weight = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(w.data + row * w.cols + col));
            a0 = _mm256_dpbusd_avx_epi32(a0, x0, weight);
            b0 = _mm256_dpbusd_avx_epi32(b0, x1, weight);
            c0 = _mm256_dpbusd_avx_epi32(c0, x2, weight);
            d0 = _mm256_dpbusd_avx_epi32(d0, x3, weight);
            if (rows > 1) {
                weight = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(w.data + (row + 1) * w.cols + col));
                a1 = _mm256_dpbusd_avx_epi32(a1, x0, weight);
                b1 = _mm256_dpbusd_avx_epi32(b1, x1, weight);
                c1 = _mm256_dpbusd_avx_epi32(c1, x2, weight);
                d1 = _mm256_dpbusd_avx_epi32(d1, x3, weight);
            }
        }
        std::int32_t sums[8] = {reduce_integer(a0), reduce_integer(b0), reduce_integer(c0), reduce_integer(d0),
            reduce_integer(a1), reduce_integer(b1), reduce_integer(c1), reduce_integer(d1)};
        for (; col < end; ++col)
            for (std::size_t r = 0; r < rows; ++r) {
                const auto value = reinterpret_cast<const std::int8_t*>(w.data)[(row + r) * w.cols + col];
                for (std::size_t t = 0; t < tokens; ++t) sums[r * 4 + t] += value * inputs[t * w.cols + col];
            }
        for (std::size_t r = 0; r < rows; ++r) {
            const auto group_index = (row + r) * groups + first / w.group;
            const auto correction = 128 * w.signed_sums[group_index];
            for (std::size_t t = 0; t < tokens; ++t)
                result[r * 4 + t] += static_cast<float>(sums[r * 4 + t] - correction) * input_scales[t] * w.scales[group_index];
        }
    }
}
#endif
#endif

void norm(const std::vector<float>& input, const Weight& weight, const Weight* bias,
          float epsilon, unsigned kind, std::vector<float>& output, std::size_t width, bool accurate) {
    output.resize(input.size());
    for (std::size_t row = 0; row < input.size() / width; ++row) {
        float mean = 0, square = 0;
        if (kind == 1) {
            for (std::size_t col = 0; col < width; ++col) mean += input[row * width + col];
            mean /= static_cast<float>(width);
        }
        if (kind == 0 && accurate) {
            square = leaf::kernels::accurate_rms_square_sum(input.data() + row * width, width);
        } else {
            for (std::size_t col = 0; col < width; ++col) {
                const float value = input[row * width + col] - mean; square += value * value;
            }
        }
        const float scale = 1.0f / std::sqrt(square / static_cast<float>(width) + epsilon);
        for (std::size_t col = 0; col < width; ++col)
            output[row * width + col] = (input[row * width + col] - mean) * scale * weight.value(0, col)
                                        + (bias ? bias->value(0, col) : 0.0f);
    }
}
}  // namespace

struct Decoder::Impl {
    Mapping mapping;
    Workers workers;
    DecoderProfile profile;
    std::unordered_map<std::string, Weight> weights;
    std::vector<KVCache> caches;
    std::size_t h, f, heads, kv_heads, layers, vocab, max_positions, eos, dim, sliding_window, qwidth;
    std::vector<std::uint32_t> eos_tokens;
    float theta, epsilon;
    unsigned norm_kind, activation, position_kind, gated, parallel, rotary_dim, position_offset, final_norm;
    float embedding_scale;
    bool avx = false;
    bool float_tiles = false, optimized_fp32 = false, fp32_artifact = false;
    bool accurate_fp32 = false;
    bool parallel_bf16 = false;
    bool parallel_fp32 = false, parallel_fp32_decode = false;
    bool qk_norm = false;
    std::size_t source_bf16_tensors = 0, source_bf16_linear_calls = 0;
    bool vector_gelu = false, vector_attention = false, paired_gemv = false;
    bool vector_silu_gate = false;
    std::size_t vector_silu_gate_calls = 0;
    bool vnni = false, used_vnni = false;
    Dot dot = dot_scalar;
    QuantDot quant_dot = quant_dot_scalar;
    unsigned activation_precision;
    std::vector<std::int16_t> quant_input;
    std::vector<std::uint8_t> quant_bytes;
    std::vector<float> quant_scales;
    std::vector<float> transformed_input;
    leaf::kernels::TokenPanelsF32 packed_float_input;
    std::vector<float> expanded_prefill_weights;
    const float* packed_source = nullptr;
    std::size_t packed_tokens = 0, packed_columns = 0;
    std::vector<float> rotary_frequencies, rotary_cosines, rotary_sines;
    std::vector<float> hidden, normalized, q, k, v, q_heads, k_heads, v_heads,
                       attention, projected, attn_projected, gate, up, mask;

    Impl(const std::string& path, unsigned threads, bool scalar, unsigned activation_bits,
         const std::vector<unsigned>& worker_cpus, FP32Math fp32_math)
        : mapping(path), workers(threads, worker_cpus), activation_precision(activation_bits) {
        check(activation_bits == 8 || activation_bits == 32, "activation bits must be 8 or 32");
        check(fp32_math == FP32Math::Fast || fp32_math == FP32Math::Accurate, "invalid FP32 math policy");
#if LEAF_DECODER_AVX
        avx = !scalar && __builtin_cpu_supports("avx2") && __builtin_cpu_supports("fma");
        if (avx) { dot = dot_avx; quant_dot = quant_dot_avx; }
        // Unqualified experiments are explicit opt-ins, never default kernels.
        const char* tiles = std::getenv("LEAF_EXPERIMENTAL_FLOAT_TILES");
        const char* gemv = std::getenv("LEAF_EXPERIMENTAL_FLOAT_GEMV");
        float_tiles = avx && tiles && tiles[0];
        if (avx && gemv && gemv[0]) dot = dot_specialized_avx;
#if LEAF_DECODER_VNNI
        const char* disabled = std::getenv("LEAF_DISABLE_VNNI");
        vnni = avx && activation_bits == 8 && (!disabled || !disabled[0]) && __builtin_cpu_supports("avxvnni");
#endif
#else
        (void)scalar;
#endif
        Reader reader{mapping}; reader.require(8);
        const bool window_format = std::memcmp(mapping.data, "LEAFDC03", 8) == 0;
        const bool multi_eos_format = std::memcmp(mapping.data, "LEAFDC04", 8) == 0;
        bool source_bf16_io_format = std::memcmp(mapping.data, "LEAFDC05", 8) == 0;
        bool source_bf16_matrix_format = std::memcmp(mapping.data, "LEAFDC06", 8) == 0;
        const bool operator_format = std::memcmp(mapping.data, "LEAFDC07", 8) == 0;
        check(operator_format || source_bf16_io_format || source_bf16_matrix_format || multi_eos_format || window_format ||
              std::memcmp(mapping.data, "LEAFDC02", 8) == 0, "unsupported artifact magic");
        reader.position = 8;
        check(reader.u32() == (operator_format ? 7u : source_bf16_matrix_format ? 6u : source_bf16_io_format ? 5u :
                              multi_eos_format ? 4u : window_format ? 3u : 2u), "unsupported decoder artifact version");
        const auto count = reader.u32(); const auto base = reader.u64();
        h = reader.u32(); f = reader.u32(); heads = reader.u32(); kv_heads = reader.u32();
        layers = reader.u32(); vocab = reader.u32(); max_positions = reader.u32(); eos = reader.u32();
        dim = reader.u32(); sliding_window = reader.u32();
        check(operator_format || source_bf16_io_format || source_bf16_matrix_format || multi_eos_format ||
              (window_format ? sliding_window > 0 : sliding_window == 0),
              "invalid sliding-window artifact configuration");
        theta = reader.f32(); epsilon = reader.f32();
        norm_kind = reader.u32(); activation = reader.u32(); position_kind = reader.u32();
        gated = reader.u32(); parallel = reader.u32(); rotary_dim = reader.u32();
        position_offset = reader.u32(); final_norm = reader.u32(); embedding_scale = reader.f32();
        check(h && f && heads && kv_heads && layers && vocab && dim && max_positions &&
              heads % kv_heads == 0 && std::uint64_t(heads) * dim <= std::numeric_limits<std::uint32_t>::max() &&
              norm_kind <= 1 && activation <= 3 && position_kind <= 2 && gated <= 1 && parallel <= 1 &&
              rotary_dim <= dim && rotary_dim % 2 == 0 && (position_kind != 0 || rotary_dim > 0) &&
              final_norm <= 1 && std::isfinite(embedding_scale) && embedding_scale > 0 &&
              std::isfinite(theta) && theta > 0 && std::isfinite(epsilon) && epsilon > 0,
              "invalid decoder configuration");
        qwidth = heads * dim;
        check(max_positions <= std::numeric_limits<std::size_t>::max() - position_offset &&
              max_positions <= std::numeric_limits<std::size_t>::max() / sizeof(float) / std::max({h, qwidth, f, vocab, max_positions}),
              "decoder workspace dimensions overflow address space");
        check(base % 64 == 0 && base <= mapping.size && count <= mapping.size / 56,
              "invalid tensor table");
        check(eos < vocab || eos == 0xffffffffu, "invalid EOS token");
        if (operator_format) {
            check(reader.position <= base && base - reader.position >= 12, "truncated decoder operator metadata");
            const auto storage = reader.u32(), qk = reader.u32(), frequencies = reader.u32();
            check(storage == 0 || storage == 5 || storage == 6, "invalid decoder storage policy");
            check((qk || frequencies) && qk <= 1 && position_kind == 0 && (!qk || norm_kind == 0) &&
                  (!frequencies || frequencies == rotary_dim / 2) && frequencies <= (base - reader.position) / 4,
                  "invalid decoder operator metadata");
            source_bf16_io_format = storage == 5;
            source_bf16_matrix_format = storage == 6;
            qk_norm = qk != 0;
            for (std::uint32_t i = 0; i < frequencies; ++i) {
                const float frequency = reader.f32();
                check(std::isfinite(frequency) && frequency > 0 && frequency <= 1, "invalid static RoPE frequency");
                rotary_frequencies.push_back(frequency);
            }
        }
        check(qk_norm || qwidth == h, "invalid decoder head geometry");
        const bool source_bf16_format = source_bf16_io_format || source_bf16_matrix_format;
        check(!source_bf16_format || activation_bits == 32, "source BF16 storage requires FP32 activations");
        if (multi_eos_format || source_bf16_format || operator_format) {
            check(reader.position <= base && base - reader.position >= 4, "truncated EOS metadata");
            const auto eos_count = reader.u32();
            check((source_bf16_format || operator_format || eos_count >= 2) && eos_count <= 1024 && eos_count <= vocab &&
                  reader.position <= base && eos_count <= (base - reader.position) / 4,
                  "invalid multi-EOS token count");
            for (std::uint32_t i = 0; i < eos_count; ++i) {
                const auto token = reader.u32();
                check(token < vocab && std::find(eos_tokens.begin(), eos_tokens.end(), token) == eos_tokens.end(),
                      "invalid or duplicate EOS token");
                eos_tokens.push_back(token);
            }
            check(eos_tokens.empty() ? eos == 0xffffffffu : eos == eos_tokens.front(), "multi-EOS primary token mismatch");
        } else if (eos < vocab) {
            eos_tokens.push_back(static_cast<std::uint32_t>(eos));
        }
        for (std::size_t i = 0; i < count; ++i) {
            const auto name = reader.string();
            const auto rank = reader.u32(); Weight weight;
            weight.rows = reader.u32(); weight.cols = reader.u32(); weight.bits = reader.u32();
            weight.group = reader.u32(); const auto offset = reader.u64(); const auto size = reader.u64();
            const auto scale_offset = reader.u64(); const auto scale_count = reader.u64();
            check(rank == 2 && weight.rows && weight.cols &&
                  (weight.bits == 32 || weight.bits == 8 || weight.bits == 4 ||
                   (source_bf16_format && weight.bits == 16 &&
                    (source_bf16_matrix_format ? source_bf16_matrix(name, weight.rows, layers) :
                     name == "lm_head.weight" || name == "model.embed_tokens.weight"))), "invalid tensor " + name);
            if (source_bf16_format)
                check(weight.bits == 32 || weight.bits == 16, "source BF16 storage cannot mix quantized weights");
            if (source_bf16_matrix_format)
                check(scale_count == 0 && weight.group == 0,
                      "source BF16 matrix storage cannot contain quantization metadata");
            if (weight.bits == 16) ++source_bf16_tensors;
            const std::uint64_t elements = std::uint64_t(weight.rows) * weight.cols;
            check(elements <= std::numeric_limits<std::size_t>::max() / 4 &&
                  (weight.bits != 4 || weight.cols % 2 == 0) && size == elements * weight.bits / 8 &&
                  offset % 64 == 0 && offset <= mapping.size - base && size <= mapping.size - base - offset,
                  "invalid tensor data range " + name);
            if (weight.bits == 8 || weight.bits == 4) {
                check(weight.group && weight.cols % weight.group == 0 &&
                      (weight.bits != 4 || weight.group % 2 == 0) &&
                      scale_count == weight.rows * (weight.cols / weight.group) && scale_offset % 64 == 0 &&
                      scale_offset <= mapping.size - base && scale_count <= (mapping.size - base - scale_offset) / 4,
                      "invalid quantization metadata " + name);
                weight.scales = reinterpret_cast<const float*>(mapping.data + base + scale_offset);
                for (std::size_t j = 0; j < scale_count; ++j)
                    check(std::isfinite(weight.scales[j]) && weight.scales[j] > 0, "invalid quantization scale");
            } else check(scale_count == 0 && weight.group == 0, "unexpected FP32 quantization metadata");
            weight.data = mapping.data + base + offset;
#if LEAF_DECODER_VNNI
            if (vnni && weight.bits == 8 && weight.group <= 65536 &&
                name != "model.embed_tokens.weight" && name != "model.position_embeddings.weight")
                prepare_signed_sums(weight);
#endif
            if (name.size() >= 12 && name.compare(name.size() - 12, 12, ".input_scale") == 0) {
                check(!source_bf16_matrix_format, "source BF16 matrix storage cannot contain calibrated input scales");
                check(weight.bits == 32 && weight.rows == 1, "invalid calibrated input scale tensor");
                const auto* factors = reinterpret_cast<const float*>(weight.data);
                for (std::size_t j = 0; j < weight.cols; ++j)
                    check(std::isfinite(factors[j]) && factors[j] > 0, "invalid calibrated input scale value");
            }
            check(weights.emplace(name, weight).second, "duplicate tensor " + name);
        }
        check(reader.position <= base, "metadata overlaps tensor payload");
        check(!source_bf16_format || source_bf16_tensors, "source BF16 artifact contains no BF16 tensors");
        require_weight("model.embed_tokens.weight", vocab, h);
        require_weight("lm_head.weight", vocab, h);
        if (final_norm) require_weight("model.norm.weight", 1, h);
        if (position_kind == 1) require_weight("model.position_embeddings.weight", max_positions + position_offset, h);
        for (std::size_t i = 0; i < layers; ++i) {
            const auto prefix = "model.layers." + std::to_string(i) + ".";
            require_weight(prefix + "input_layernorm.weight", 1, h);
            require_weight(prefix + "post_attention_layernorm.weight", 1, h);
            require_weight(prefix + "self_attn.q_proj.weight", qwidth, h);
            require_weight(prefix + "self_attn.k_proj.weight", kv_heads * dim, h);
            require_weight(prefix + "self_attn.v_proj.weight", kv_heads * dim, h);
            require_weight(prefix + "self_attn.o_proj.weight", h, qwidth);
            if (qk_norm) {
                check(require_weight(prefix + "self_attn.q_norm.weight", 1, dim).bits == 32 &&
                      require_weight(prefix + "self_attn.k_norm.weight", 1, dim).bits == 32,
                      "Q/K normalization weights must use FP32 storage");
            }
            if (gated) require_weight(prefix + "mlp.gate_proj.weight", f, h);
            require_weight(prefix + "mlp.up_proj.weight", f, h);
            require_weight(prefix + "mlp.down_proj.weight", h, f);
            caches.emplace_back(1, kv_heads, dim);
        }
        if (position_kind == 0 && rotary_frequencies.empty()) {
            rotary_frequencies.resize(rotary_dim / 2);
            for (std::size_t i = 0; i < rotary_dim / 2; ++i)
                rotary_frequencies[i] = 1.0f / std::pow(theta, static_cast<float>(2 * i) / rotary_dim);
        }
        // Qualification is scoped to FP32 computation, not architecture names.
        // v5 BF16 I/O retains exact source values; it does not quantize them.
        // Quantized/mixed artifacts keep their previously validated dispatch.
        fp32_artifact = activation_precision == 32 &&
            std::all_of(weights.begin(), weights.end(), [](const auto& item) { return item.second.bits == 32 || item.second.bits == 16; });
        accurate_fp32 = fp32_math == FP32Math::Accurate;
        check(!accurate_fp32 || fp32_artifact, "accurate FP32 math requires FP32 compute and unquantized weights");
        if (accurate_fp32 && !avx) dot = dot_scalar_precise;
        optimized_fp32 = LEAF_OPTIMIZED_FP32 && avx && fp32_artifact;
        parallel_bf16 = optimized_fp32 && !accurate_fp32 && source_bf16_matrix_format && threads >= 4;
        parallel_fp32 = optimized_fp32 && source_bf16_tensors == 0 && threads >= 2;
        parallel_fp32_decode = parallel_fp32 && threads >= 4;
        if (optimized_fp32) {
            float_tiles = true;
            vector_gelu = vector_attention = paired_gemv = true;
        }
        if (accurate_fp32 && avx) float_tiles = true;
#if LEAF_OPTIMIZED_SILU_W8A8
        // Permit FP32-protected tensors within W8A8, but not INT4 or all-FP32
        // artifacts. Activation buffers remain FP32 regardless of weight bits.
        vector_silu_gate = avx && gated && activation == 0 && activation_precision == 8 &&
            std::any_of(weights.begin(), weights.end(), [](const auto& item) { return item.second.bits == 8; }) &&
            std::none_of(weights.begin(), weights.end(), [](const auto& item) { return item.second.bits == 4; });
#endif
#if LEAF_OPTIMIZED_SILU_FP32
        vector_silu_gate = vector_silu_gate || (avx && gated && activation == 0 && fp32_artifact);
#endif
#ifdef LEAF_EXPERIMENTAL_SILU_GATE
        vector_silu_gate = avx && gated && activation == 0;
#endif
#ifdef LEAF_EXPERIMENTAL_VECTOR_GELU
        vector_gelu = avx;
#endif
#ifdef LEAF_EXPERIMENTAL_ATTENTION_AVX2
        vector_attention = avx;
#endif
#ifdef LEAF_EXPERIMENTAL_GEMV_PAIR
        paired_gemv = avx;
#endif
    }
    ~Impl() { profile.emit(); }
    void normalize(const std::vector<float>& input, const std::string& name, std::vector<float>& output) {
        DecoderProfile::Scope scope(profile, norm_kind ? DecoderProfile::Phase::LayerNorm : DecoderProfile::Phase::RMSNorm,
                                     input.size() / h);
        const auto found = weights.find(name + ".bias");
        const Weight* bias = found == weights.end() ? nullptr : &found->second;
        if (bias) check(bias->rows == 1 && bias->cols == h, "incompatible normalization bias");
        norm(input, weights.at(name + ".weight"), bias, epsilon, norm_kind, output, h, accurate_fp32);
    }
    float activate(float x) const {
        if (activation == 0) return x / (1.0f + std::exp(-x));
        if (activation == 1) return 0.5f * x * (1.0f + std::erf(x * 0.7071067811865475f));
        if (activation == 2) return 0.5f * x * (1.0f + std::tanh(0.7978845608028654f * (x + 0.044715f * x * x * x)));
        return std::max(x, 0.0f);
    }
    const Weight& require_weight(const std::string& name, std::size_t rows, std::size_t cols) const {
        const auto found = weights.find(name);
        check(found != weights.end() && found->second.rows == rows && found->second.cols == cols,
              "missing or incompatible tensor " + name);
        return found->second;
    }
    void linear(const float* input, std::size_t tokens, const std::string& name, std::vector<float>& output,
                bool mlp_projection = false, bool reuse_packed = false) {
        DecoderProfile::LinearScope role_scope(profile, mlp_projection, false, tokens);
#ifdef LEAF_DIAGNOSTIC_TIMING
        leaf::diagnostics::Scope linear_detail(tokens, mlp_projection ? leaf::diagnostics::MlpTotal : leaf::diagnostics::OtherTotal);
#endif
        const auto& weight = weights.at(name + ".weight");
        const auto phase = (weight.bits == 32 || weight.bits == 16) ? DecoderProfile::Phase::LinearFP32 :
            weight.bits == 8 ? (activation_precision == 8 ? DecoderProfile::Phase::LinearW8A8 : DecoderProfile::Phase::LinearW8A32) :
                               (activation_precision == 8 ? DecoderProfile::Phase::LinearW4A8 : DecoderProfile::Phase::LinearW4A32);
        DecoderProfile::Scope scope(profile, phase, tokens);
        const auto found = weights.find(name + ".bias");
        const Weight* bias = found == weights.end() ? nullptr : &found->second;
        if (bias) check(bias->rows == 1 && bias->cols == weight.rows, "incompatible linear bias");
        const auto scaling = weights.find(name + ".input_scale");
        if (scaling != weights.end()) {
            const auto& scale = scaling->second;
            check(scale.bits == 32 && scale.rows == 1 && scale.cols == weight.cols,
                  "incompatible calibrated input scale");
            transformed_input.resize(tokens * weight.cols);
            const auto* factors = reinterpret_cast<const float*>(scale.data);
            for (std::size_t t = 0; t < tokens; ++t)
                for (std::size_t col = 0; col < weight.cols; ++col)
                    transformed_input[t * weight.cols + col] = input[t * weight.cols + col] * factors[col];
            input = transformed_input.data();
        }
        const bool integer = (weight.bits == 4 || weight.bits == 8) && activation_precision == 8;
        if (weight.bits == 16) ++source_bf16_linear_calls;
        const bool vnni_integer = integer && vnni && tokens > 1 && weight.bits == 8 && weight.group <= 65536;
        if (integer) {
            check(weight.group <= 131000, "integer accumulation exceeds safe input width");
            if (vnni_integer) quant_bytes.resize(tokens * weight.cols);
            else quant_input.resize(tokens * weight.cols);
            quant_scales.resize(tokens);
            for (std::size_t t = 0; t < tokens; ++t) {
                const auto* values = input + t * weight.cols;
                float maximum = 0;
                for (std::size_t col = 0; col < weight.cols; ++col) maximum = std::max(maximum, std::abs(values[col]));
                quant_scales[t] = std::max(maximum / 127.0f, 1e-12f);
#if LEAF_DECODER_AVX
#if LEAF_DECODER_VNNI
                if (vnni_integer) quantize_input_bytes(values, quant_bytes.data() + t * weight.cols, weight.cols, 1.0f / quant_scales[t]);
                else
#endif
                if (avx) quantize_input_avx(values, quant_input.data() + t * weight.cols, weight.cols, 1.0f / quant_scales[t]);
                else
#endif
                    for (std::size_t col = 0; col < weight.cols; ++col)
                        quant_input[t * weight.cols + col] = static_cast<std::int16_t>(std::max(-127L, std::min(127L, std::lrint(values[col] / quant_scales[t]))));
            }
        }
        const bool packed_float = float_tiles && (weight.bits == 32 || weight.bits == 16) && tokens >= 8 &&
                                  (!bias || bias->bits == 32);
        bool vector_pack = optimized_fp32 && avx;
#ifdef LEAF_EXPERIMENTAL_MLP_PACK
        vector_pack = vector_pack || (mlp_projection && avx);
#else
        (void)mlp_projection;
#endif
        if (accurate_fp32) vector_pack = optimized_fp32 && avx;
        if (packed_float) {
            DecoderProfile::LinearScope packing_scope(profile, mlp_projection, true, tokens);
#ifdef LEAF_DIAGNOSTIC_TIMING
            leaf::diagnostics::Scope pack_detail(tokens, mlp_projection ? leaf::diagnostics::MlpPack : leaf::diagnostics::OtherPack);
#endif
            // Reuse requires an explicit unchanged-input promise within this
            // projection group; equal addresses alone are insufficient.
            const bool plain = (accurate_fp32 || optimized_fp32) && avx && scaling == weights.end();
            const bool reuse = plain && reuse_packed && packed_source == input &&
                               packed_tokens == tokens && packed_columns == weight.cols;
            if (!reuse) packed_float_input.pack(input, tokens, weight.cols, weight.cols, vector_pack);
            profile.packed_input(reuse);
            packed_source = plain ? input : nullptr;
            packed_tokens = tokens;
            packed_columns = weight.cols;
        } else {
            // An intervening nonpacked projection ends any reusable group.
            packed_source = nullptr;
        }
        output.resize(tokens * weight.rows);
        used_vnni = used_vnni || vnni_integer;
#if LEAF_OPTIMIZED_FP32 && defined(__x86_64__) && defined(__GNUC__)
        const bool expand = parallel_bf16 && weight.bits == 16 &&
                            weight.rows <= bf16_max_expanded_values / weight.cols;
        if (packed_float && tokens >= parallel_prefill_tokens &&
                (expand || (parallel_fp32 && weight.bits == 32))) {
            const auto* matrix = reinterpret_cast<const float*>(weight.data);
            if (expand) {
                const auto values = weight.rows * weight.cols;
                if (expanded_prefill_weights.size() < values)
                    std::vector<float>(values).swap(expanded_prefill_weights);
                const auto* stored = reinterpret_cast<const std::uint16_t*>(weight.data);
                workers.run(weight.rows, [&](std::size_t first, std::size_t last) {
                    const auto offset = first * weight.cols;
                    leaf::kernels::expand_source_bf16(stored + offset, expanded_prefill_weights.data() + offset,
                                                      (last - first) * weight.cols, avx);
                }, 32);
                matrix = expanded_prefill_weights.data();
            }
            // Each job owns a disjoint token span. Keep the selected tile's
            // accumulation order for each output, including the accurate tree.
            const auto* offset = bias ? reinterpret_cast<const float*>(bias->data) : nullptr;
            workers.run(packed_float_input.panels(), [&](std::size_t first, std::size_t last) {
                if (accurate_fp32)
                    leaf::kernels::accurate_fp32_detail::gemm(matrix, weight.rows, weight.cols, weight.cols,
                        packed_float_input, output.data(), weight.rows, offset, first, last);
                else
                    leaf::kernels::row_reuse_detail::gemm(matrix, weight.rows, weight.cols, weight.cols,
                        packed_float_input, output.data(), weight.rows, offset, first, last);
            }, 2);
            return;
        }
#endif
        workers.run(weight.rows, [&](std::size_t first, std::size_t last) {
            if (packed_float) {
                // Verification may request every vocabulary row for many tokens.
                // Expand a bounded row block and reuse exactly the same FP32
                // GEMM, including experimental reduction policies. Generation
                // uses the direct BF16 GEMV below, with no expansion buffer.
                // Match one six-row output tile so converted weights stay near the
                // active input panel instead of competing with it for L2 capacity.
                const auto block = weight.bits == 16 ? std::min<std::size_t>(6, last - first) : last - first;
                std::vector<float> expanded;
                if (weight.bits == 16) expanded.resize(block * weight.cols);
                for (std::size_t begin = first; begin < last; begin += block) {
                    const auto live = std::min(block, last - begin);
                    const float* panel_weights = nullptr;
                    if (weight.bits == 16) {
                        leaf::kernels::expand_source_bf16(reinterpret_cast<const std::uint16_t*>(weight.data) + begin * weight.cols,
                                                        expanded.data(), live * weight.cols, avx);
                        panel_weights = expanded.data();
                    } else panel_weights = reinterpret_cast<const float*>(weight.data) + begin * weight.cols;
                    if (accurate_fp32) {
                        leaf::kernels::gemm_token_panels_f32_accurate(
                            panel_weights, live, weight.cols, weight.cols, packed_float_input,
                            output.data() + begin, weight.rows,
                            bias ? reinterpret_cast<const float*>(bias->data) + begin : nullptr);
                    } else {
#if LEAF_OPTIMIZED_FP32 || defined(LEAF_EXPERIMENTAL_ROW_REUSE)
                        leaf::kernels::gemm_token_panels_f32_row_reuse(
#else
                        leaf::kernels::gemm_token_panels_f32(
#endif
                            panel_weights, live, weight.cols, weight.cols, packed_float_input,
                            output.data() + begin, weight.rows,
                            bias ? reinterpret_cast<const float*>(bias->data) + begin : nullptr);
                    }
                }
                return;
            }
            std::size_t row = first;
            if (weight.bits == 16) {
#if LEAF_DECODER_AVX
                if (paired_gemv && tokens == 1 && weight.cols >= 8 && weight.cols % 8 == 0) {
                    for (; last - row >= 2; row += 2) {
                        leaf::kernels::gemv_pair_source_bf16(reinterpret_cast<const std::uint16_t*>(weight.data) + row * weight.cols,
                                                           input, weight.cols, output.data() + row);
                        output[row] += bias ? bias->value(0, row) : 0.0f;
                        output[row + 1] += bias ? bias->value(0, row + 1) : 0.0f;
                    }
                }
#endif
                float result[4];
                for (; row < last; ++row) {
                    for (std::size_t token = 0; token < tokens; token += 4) {
                        const auto count = std::min<std::size_t>(4, tokens - token);
#if LEAF_DECODER_AVX
                        if (avx) dot_source_bf16_avx(weight, row, input + token * weight.cols, count, result);
                        else
#endif
                            dot(weight, row, input + token * weight.cols, count, result);
                        for (std::size_t t = 0; t < count; ++t)
                            output[(token + t) * weight.rows + row] = result[t] + (bias ? bias->value(0, row) : 0.0f);
                    }
                }
                return;
            }
#if LEAF_DECODER_AVX && (LEAF_OPTIMIZED_FP32 || defined(LEAF_EXPERIMENTAL_GEMV_PAIR))
            if (paired_gemv && weight.bits == 32 && tokens == 1 && weight.cols >= 8 && weight.cols % 8 == 0) {
                for (; last - row >= 2; row += 2) {
                    leaf::kernels::gemv_pair_f32(reinterpret_cast<const float*>(weight.data) + row * weight.cols,
                                                input, weight.cols, output.data() + row);
                    output[row] += bias ? bias->value(0, row) : 0.0f;
                    output[row + 1] += bias ? bias->value(0, row + 1) : 0.0f;
                }
            }
#endif
#if LEAF_DECODER_VNNI
            if (vnni_integer) {
                constexpr std::size_t tile_rows = 2, tile_tokens = 4;
                float result[tile_rows * tile_tokens];
                for (; row < last; row += tile_rows) {
                    const auto rows = std::min(tile_rows, last - row);
                    for (std::size_t token = 0; token < tokens; token += tile_tokens) {
                        const auto count = std::min(tile_tokens, tokens - token);
                        quant_vnni_tile(weight, row, rows, quant_bytes.data() + token * weight.cols,
                                        count, quant_scales.data() + token, result);
                        for (std::size_t r = 0; r < rows; ++r)
                            for (std::size_t t = 0; t < count; ++t)
                                output[(token + t) * weight.rows + row + r] = result[r * tile_tokens + t] +
                                    (bias ? bias->value(0, row + r) : 0);
                    }
                }
                return;
            }
#endif
#if LEAF_DECODER_AVX
            // The opt-in token-panel experiment only changes FP32 GEMM above.
            // Keep short inputs and weight-only INT8 on their default paths so
            // a scoped before/after run isolates this kernel's real cost.
            if (integer && avx && tokens > 1) {
                float result[8];
                for (; row + 4 <= last; row += 4) {
                    for (std::size_t token = 0; token < tokens; token += 2) {
                        const auto count = std::min<std::size_t>(2, tokens - token);
                        quant_tile_avx(weight, row, quant_input.data() + token * weight.cols,
                                       count, quant_scales.data() + token, result);
                        for (std::size_t r = 0; r < 4; ++r)
                            for (std::size_t t = 0; t < count; ++t)
                                output[(token + t) * weight.rows + row + r] = result[r * 2 + t] +
                                    (bias ? bias->value(0, row + r) : 0);
                    }
                }
            }
#endif
            float result[4];
            for (; row < last; ++row) {
                for (std::size_t token = 0; token < tokens; token += 4) {
                    const auto count = std::min<std::size_t>(4, tokens - token);
                    if (integer) quant_dot(weight, row, quant_input.data() + token * weight.cols,
                                           count, quant_scales.data() + token, result);
                    else dot(weight, row, input + token * weight.cols, count, result);
                    for (std::size_t t = 0; t < count; ++t)
                        output[(token + t) * weight.rows + row] = result[t] + (bias ? bias->value(0, row) : 0);
                }
            }
        });
    }
    void prepare_rotary_tables(std::size_t tokens, std::size_t position) {
        if (position_kind != 0) return;
        DecoderProfile::Scope scope(profile, DecoderProfile::Phase::RoPE, tokens);
        const std::size_t half = rotary_dim / 2;
        check(half && tokens <= std::numeric_limits<std::size_t>::max() / sizeof(float) / half,
              "rotary coefficient workspace dimensions overflow address space");
        const std::size_t count = tokens * half;
        check(count <= rotary_cosines.max_size() && count <= rotary_sines.max_size(),
              "rotary coefficient workspace exceeds vector limits");
        // Logical size follows the current chunk, not the accumulated KV cache
        // or max_positions. Reuse capacity like the other decoder workspaces.
        rotary_cosines.resize(count);
        rotary_sines.resize(count);
        for (std::size_t token = 0; token < tokens; ++token) {
            for (std::size_t i = 0; i < half; ++i) {
                // Keep the original float expressions and libm calls: changing
                // precision, angle order, or sin/cos implementation can affect
                // whole-model parity even if a local rotation looks close.
                const float angle = static_cast<float>(position + token) * rotary_frequencies[i];
                const float cosine = std::cos(angle), sine = std::sin(angle);
                rotary_cosines[token * half + i] = cosine;
                rotary_sines[token * half + i] = sine;
            }
        }
    }
    void rotary(std::vector<float>& values, std::vector<float>& reordered,
                std::size_t nheads, std::size_t tokens) {
        DecoderProfile::Scope scope(profile, position_kind == 0 ? DecoderProfile::Phase::RoPE : DecoderProfile::Phase::PositionReorder,
                                     tokens);
        reordered.resize(values.size());
        for (std::size_t token = 0; token < tokens; ++token) {
            for (std::size_t head = 0; head < nheads; ++head) {
                for (std::size_t i = 0; i < dim; ++i) {
                    reordered[(head * tokens + token) * dim + i] = values[(token * nheads + head) * dim + i];
                }
                if (position_kind != 0) continue;
                for (std::size_t i = 0; i < rotary_dim / 2; ++i) {
                    const auto coefficient = token * (rotary_dim / 2) + i;
                    const float cosine = rotary_cosines[coefficient], sine = rotary_sines[coefficient];
                    const auto from = (token * nheads + head) * dim + i;
                    const auto to = (head * tokens + token) * dim + i;
                    const float a = values[from], b = values[from + rotary_dim / 2];
                    reordered[to] = a * cosine - b * sine;
                    reordered[to + rotary_dim / 2] = b * cosine + a * sine;
                }
            }
        }
    }
    void forward_into(const std::vector<std::uint32_t>& ids, bool all_logits, std::vector<float>& logits) {
#ifdef LEAF_DIAGNOSTIC_TRACE
        DecoderTrace trace;
#endif
        check(!ids.empty(), "input tokens are empty");
        const std::size_t tokens = ids.size(), position = caches[0].length();
        check(position <= max_positions && tokens <= max_positions - position, "context length exceeds artifact limit");
        for (auto id : ids) check(id < vocab, "token id exceeds vocabulary");
        profile.forward_tokens(tokens);
        DecoderProfile::Scope forward_scope(profile, DecoderProfile::Phase::Forward, tokens);
        prepare_rotary_tables(tokens, position);
        {
            DecoderProfile::Scope scope(profile, DecoderProfile::Phase::Embedding, tokens);
            hidden.resize(tokens * h);
            const auto& embedding = weights.at("model.embed_tokens.weight");
            // Resolve once: a per-element map lookup dominated this phase.
            const Weight* positions = position_kind == 1 ? &weights.at("model.position_embeddings.weight") : nullptr;
            for (std::size_t t = 0; t < tokens; ++t)
                for (std::size_t col = 0; col < h; ++col) {
                    hidden[t * h + col] = embedding.value(ids[t], col) * embedding_scale;
                    if (positions) hidden[t * h + col] += positions->value(position + t + position_offset, col);
                }
        }
        LEAF_TRACE("embedding", hidden);
        const auto total = position + tokens;
        {
            DecoderProfile::Scope scope(profile, DecoderProfile::Phase::CausalMask, tokens);
            mask.assign(tokens * total, 0.0f);
            for (std::size_t t = 0; t < tokens; ++t) {
                const auto end = position + t + 1;
                const auto begin = sliding_window && end > sliding_window ? end - sliding_window : 0;
                std::fill_n(mask.data() + t * total + begin, end - begin, 1.0f);
            }
        }
        const std::size_t mask_shape[4] = {1, 1, tokens, total};
        for (std::size_t layer = 0; layer < layers; ++layer) {
            const auto prefix = "model.layers." + std::to_string(layer) + ".";
            normalize(hidden, prefix + "input_layernorm", normalized);
            LEAF_TRACE(prefix + "input_norm", normalized);
            linear(normalized.data(), tokens, prefix + "self_attn.q_proj", q);
            linear(normalized.data(), tokens, prefix + "self_attn.k_proj", k, false, true);
            linear(normalized.data(), tokens, prefix + "self_attn.v_proj", v, false, true);
            LEAF_TRACE(prefix + "q", q);
            LEAF_TRACE(prefix + "k", k);
            LEAF_TRACE(prefix + "v", v);
            if (qk_norm) {
                DecoderProfile::Scope scope(profile, DecoderProfile::Phase::RMSNorm, tokens);
                norm(q, weights.at(prefix + "self_attn.q_norm.weight"), nullptr, epsilon, 0, q, dim, accurate_fp32);
                norm(k, weights.at(prefix + "self_attn.k_norm.weight"), nullptr, epsilon, 0, k, dim, accurate_fp32);
            }
            rotary(q, q_heads, heads, tokens); rotary(k, k_heads, kv_heads, tokens);
            LEAF_TRACE(prefix + "q_rotary", q_heads);
            LEAF_TRACE(prefix + "k_rotary", k_heads);
            v_heads.resize(v.size());
            for (std::size_t head = 0; head < kv_heads; ++head)
                for (std::size_t t = 0; t < tokens; ++t)
                    std::copy_n(v.data() + (t * kv_heads + head) * dim, dim,
                                v_heads.data() + (head * tokens + t) * dim);
            {
                DecoderProfile::Scope scope(profile, DecoderProfile::Phase::KVAppend, tokens);
                caches[layer].append(k_heads.data(), v_heads.data(), tokens);
            }
            {
                DecoderProfile::Scope scope(profile, DecoderProfile::Phase::Attention, tokens);
                attention.resize(tokens * qwidth);
                // The shared fused graph kernel scales both Q and K.
                const float scale = 1.0f / std::sqrt(std::sqrt(static_cast<float>(dim)));
#if LEAF_OPTIMIZED_FP32 || defined(LEAF_EXPERIMENTAL_ATTENTION_AVX2)
                const auto& cache = caches[layer];
                const bool parallel_attention = (parallel_bf16 || parallel_fp32) && heads > 1;
                if (vector_attention && tokens > 1) {
                    auto attend_heads = [&](std::size_t first, std::size_t last) {
                        leaf::kernels::attention_f32_gqa_strided_vector(q_heads.data(), cache.keys_data(),
                            cache.values_data(), mask.data(), attention.data(), 1, heads, kv_heads, tokens,
                            total, cache.capacity(), dim, mask_shape, scale, true, true, first, last);
                    };
                    if (parallel_attention && tokens >= parallel_prefill_tokens)
                        workers.run(heads, attend_heads, 1);
                    else
                        attend_heads(0, heads);
                } else if ((parallel_bf16 || parallel_fp32_decode) && heads > 1 &&
                           tokens == 1 && total >= parallel_decode_context) {
                    workers.run(heads, [&](std::size_t first, std::size_t last) {
                        leaf::kernels::attention_f32_gqa_strided(q_heads.data(), cache.keys_data(),
                            cache.values_data(), mask.data(), attention.data(), 1, heads, kv_heads, tokens,
                            total, cache.capacity(), dim, mask_shape, scale, true, first, last);
                    }, 1);
                } else
#endif
                caches[layer].attend(q_heads.data(), mask.data(), attention.data(), heads, tokens, mask_shape, scale);
            }
            linear(attention.data(), tokens, prefix + "self_attn.o_proj", attn_projected);
            LEAF_TRACE(prefix + "attention", attention);
            LEAF_TRACE(prefix + "attn_projected", attn_projected);
            std::size_t mlp_tokens = tokens;
            if (layer + 1 == layers && !all_logits && fp32_artifact && tokens >= 32) {
                // K/V for every input token have already been appended. Only
                // the last output row is consumed, so earlier final-layer MLP
                // rows cannot affect this request or subsequent cached tokens.
                // Keep 16..31 trailing rows, aligned to the original panels.
                // This preserves packed-GEMM/activation dispatch and per-lane
                // arithmetic instead of switching the retained row to GEMV.
                const auto first = ((tokens - 16) / 16) * 16;
                hidden.erase(hidden.begin(), hidden.begin() + first * h);
                attn_projected.erase(attn_projected.begin(), attn_projected.begin() + first * h);
                mlp_tokens -= first;
            }
            if (!parallel) {
                DecoderProfile::Scope scope(profile, DecoderProfile::Phase::Residual, tokens);
                for (std::size_t j = 0; j < hidden.size(); ++j) hidden[j] += attn_projected[j];
            }
            normalize(hidden, prefix + "post_attention_layernorm", normalized);
            LEAF_TRACE(prefix + "post_norm", normalized);
            linear(normalized.data(), mlp_tokens, prefix + "mlp.up_proj", up, true);
            LEAF_TRACE(prefix + "up", up);
            if (gated) {
                linear(normalized.data(), mlp_tokens, prefix + "mlp.gate_proj", gate, true, true);
                DecoderProfile::Scope scope(profile, DecoderProfile::Phase::Activation, mlp_tokens);
#ifdef LEAF_EXPERIMENTAL_GELU_ERF
                if (fp32_artifact && avx && mlp_tokens >= 8 && activation == 1) {
                    leaf::kernels::gelu_erf_inplace(gate.data(), gate.size());
                    for (std::size_t j = 0; j < gate.size(); ++j) up[j] *= gate[j];
                } else
#endif
#if LEAF_OPTIMIZED_SILU_W8A8 || LEAF_OPTIMIZED_SILU_FP32 || defined(LEAF_EXPERIMENTAL_SILU_GATE)
                // FP32 qualifies prefill and single-token decode. Quantized
                // and historical research policies retain prefill-only use.
                if (vector_silu_gate && (mlp_tokens >= 8 ||
                    (LEAF_OPTIMIZED_SILU_FP32 && fp32_artifact && mlp_tokens == 1))) {
                    leaf::kernels::silu_gate_inplace(up.data(), gate.data(), gate.size());
                    ++vector_silu_gate_calls;
                } else
#endif
                for (std::size_t j = 0; j < gate.size(); ++j) up[j] *= activate(gate[j]);
            } else {
                DecoderProfile::Scope scope(profile, DecoderProfile::Phase::Activation, mlp_tokens);
#ifdef LEAF_EXPERIMENTAL_GELU_ERF
                if (fp32_artifact && avx && mlp_tokens >= 8 && activation == 1)
                    leaf::kernels::gelu_erf_inplace(up.data(), up.size());
                else
#endif
#if LEAF_OPTIMIZED_FP32 || defined(LEAF_EXPERIMENTAL_VECTOR_GELU)
                if (vector_gelu && mlp_tokens >= 8 && activation == 2)
                    leaf::kernels::gelu_new_inplace(up.data(), up.size());
                else
#endif
                for (auto& value : up) value = activate(value);
            }
            linear(up.data(), mlp_tokens, prefix + "mlp.down_proj", projected, true);
            LEAF_TRACE(prefix + "activation", up);
            LEAF_TRACE(prefix + "down", projected);
            {
                DecoderProfile::Scope scope(profile, DecoderProfile::Phase::Residual, tokens);
                for (std::size_t j = 0; j < hidden.size(); ++j) hidden[j] += projected[j] + (parallel ? attn_projected[j] : 0.0f);
            }
            LEAF_TRACE(prefix + "hidden", hidden);
        }
        if (final_norm) normalize(hidden, "model.norm", normalized);
        else normalized = hidden;
        LEAF_TRACE("final_norm", normalized);
        linear(normalized.data() + (all_logits ? 0 : normalized.size() - h), all_logits ? tokens : 1,
               "lm_head", logits);
        LEAF_TRACE("logits", logits);
    }
};

Decoder::Decoder(const std::string& path, unsigned threads, bool force_scalar, unsigned activation_bits,
                 const std::vector<unsigned>& worker_cpus, FP32Math fp32_math)
    : impl_(std::make_unique<Impl>(path, threads, force_scalar, activation_bits, worker_cpus, fp32_math)) {}
Decoder::~Decoder() = default;
void Decoder::reset() { for (auto& cache : impl_->caches) cache.reset(); }
std::vector<float> Decoder::forward(const std::vector<std::uint32_t>& tokens, bool all_logits) {
    std::vector<float> result;
    forward_into(tokens, result, all_logits);
    return result;
}
void Decoder::forward_into(const std::vector<std::uint32_t>& tokens, std::vector<float>& logits, bool all_logits) {
    // One caller binding per forward; nested pool operations keep that mask
    // rather than repeatedly setting/restoring it at every linear projection.
    auto caller = impl_->workers.bind_caller();
    impl_->forward_into(tokens, all_logits, logits);
    caller.restore();
}
std::uint32_t Decoder::vocabulary_size() const { return static_cast<std::uint32_t>(impl_->vocab); }
std::uint32_t Decoder::eos_token() const { return static_cast<std::uint32_t>(impl_->eos); }
bool Decoder::is_eos_token(std::uint32_t token) const {
    return std::find(impl_->eos_tokens.begin(), impl_->eos_tokens.end(), token) != impl_->eos_tokens.end();
}
std::size_t Decoder::cache_tokens() const { return impl_->caches[0].length(); }
std::uint64_t Decoder::weight_bytes() const { return impl_->mapping.size; }
bool Decoder::uses_avx2() const { return impl_->avx; }
bool Decoder::uses_optimized_fp32() const { return impl_->optimized_fp32; }
bool Decoder::uses_accurate_fp32() const { return impl_->accurate_fp32; }
bool Decoder::uses_vector_silu_gate() const { return impl_->vector_silu_gate; }
std::size_t Decoder::silu_gate_vector_calls() const { return impl_->vector_silu_gate_calls; }
std::size_t Decoder::source_bf16_tensors() const { return impl_->source_bf16_tensors; }
std::size_t Decoder::source_bf16_linear_calls() const { return impl_->source_bf16_linear_calls; }
bool Decoder::uses_vnni() const { return impl_->used_vnni; }
unsigned Decoder::activation_bits() const { return impl_->activation_precision; }
// Test-only access to the actual decoder dot kernels; absent from normal builds.
#ifdef LEAF_TEST_GEMV
namespace testing {
void gemv_f32(const float* weights, const float* input, float* output,
              std::size_t rows, std::size_t columns, unsigned variant) {
    Weight weight;
    weight.data = reinterpret_cast<const std::uint8_t*>(weights);
    weight.rows = rows; weight.cols = columns; weight.bits = 32;
    Dot kernel = dot_scalar;
#if LEAF_DECODER_AVX
    if (__builtin_cpu_supports("avx2") && __builtin_cpu_supports("fma"))
        kernel = variant == 1 ? dot_specialized_avx : dot_avx;
#endif
    std::size_t row = 0;
#if LEAF_DECODER_AVX
    if (variant == 2 && columns >= 8 && columns % 8 == 0 && __builtin_cpu_supports("avx2") && __builtin_cpu_supports("fma")) {
        for (; rows - row >= 2; row += 2)
            leaf::kernels::gemv_pair_f32(weights + row * columns, input, columns, output + row);
    }
#endif
    for (; row < rows; ++row) kernel(weight, row, input, 1, output + row);
}
} // namespace testing
#endif
}  // namespace leaf::runtime
