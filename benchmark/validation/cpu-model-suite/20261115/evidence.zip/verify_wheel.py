"""Check pinned OPT generation from the installed Windows wheel while offline."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


root = Path(__file__).resolve().parent
work = root/'wheel-smoke'
work.mkdir()
venv = root/'wheel-venv'
wheel, = (root/'wheel').glob('*.whl')
subprocess.run([sys.executable, '-m', 'venv', '--system-site-packages', str(venv)], check=True)
python, leaf = [venv/'Scripts'/name for name in ('python.exe','leaf.exe')]
subprocess.run([str(python),'-m','pip','install','--no-deps','--ignore-installed',str(wheel)], check=True)
env = {k:v for k,v in os.environ.items() if not k.startswith('LEAF_') and k not in ('PYTHONPATH','CXX','CC')}
env.update(PATH=os.pathsep.join((str(leaf.parent),str(Path(os.environ['SystemRoot'])/'System32'))),
           LEAF_CACHE_DIR=str(root/'cache'), HF_HUB_OFFLINE='1')
assert all(shutil.which(name,path=env['PATH']) is None for name in ('g++','clang++','cl'))
model, revision = 'facebook/opt-125m', 'e3bf7e1695cb08c7963df13dbf144e0d1812717c'


def leaf_command(*args):
    completed = subprocess.run([str(leaf),*args], cwd=work, env=env, capture_output=True, encoding='utf-8')
    if completed.returncode:
        raise RuntimeError(completed.stderr + completed.stdout)
    return completed.stdout


doctor = json.loads(leaf_command('doctor','--task','generation'))
assert doctor['runtimes']['generation']['selection'] == 'bundled'
info = json.loads(leaf_command('inspect',model,'--revision',revision,'--offline'))
assert info['configuration_supported'] and Path(info['snapshot']).name == revision
text = leaf_command('run',model,'--revision',revision,'--offline','--bits','32','--fp32-math','accurate',
                    '--prompt','Once upon a time, a small robot found','--max-tokens','16','--metrics','opt.json')
assert text.strip()
metrics = json.loads((work/'opt.json').read_bytes())
previous = json.loads((root/'opt125m-public-run.json').read_bytes())
assert metrics['generated_tokens'] == previous['generated_tokens']
assert metrics['artifact_bytes'] == previous['artifact_bytes'] and metrics['fp32_math'] == 'accurate'
record = dict(wheel=wheel.name, wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
              cached_pin_generation_matches=True, compiler_on_path=False,
              generated_tokens=len(metrics['generated_tokens']), revision=revision,
              artifact_bytes=metrics['artifact_bytes'])
(root/'wheel-opt-smoke.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record), flush=True)
