"""Compare installed Leaf builds on the same trained Qwen3 source-BF16 artifact."""

import hashlib
import json
from pathlib import Path
import tempfile

import numpy as np
from tokenizers import Tokenizer

from leaf.evaluation import write_record
from tools.benchmark_ollama_decoder import prefix_workloads
from tools.decoder_validation import run_native
from tools.validate_decoder import digest


work = Path(__file__).resolve().parent
scratch = work / 'qwen3-tmp'
scratch.mkdir(exist_ok=True)
tempfile.tempdir = str(scratch)
earlier = work.parent / 'trained-operator-validation-20261109-211516'
artifact = earlier / 'qwen3-artifacts/decoder-source-bf16.leaf'
prior_storage = json.loads((earlier/'qwen3-storage-parity.json').read_bytes())
assert prior_storage['complete'] and prior_storage['reference_strict_pass']
assert prior_storage['hashes'][str(artifact)] == digest(artifact)
tokenizer = Tokenizer.from_file(str(earlier/'qwen3/tokenizer.json'))
release = work.parent / 'presentation-20261115'
binaries = {
    'before': release/'venv/Lib/site-packages/leaf/bin/leaf_decoder.exe',
    'after': release/'optimized-venv/Lib/site-packages/leaf/bin/leaf_decoder.exe',
}
bound = [artifact, *binaries.values(), earlier/'qwen3/tokenizer.json', earlier/'qwen3-storage-parity.json']
record = dict(complete=False, passed=False, scope=__doc__, model='Qwen/Qwen3-0.6B',
              artifact_bytes=artifact.stat().st_size, hashes={str(p): digest(p) for p in bound}, workloads={})
common = dict(threads=4, worker_cpus=[0,2,4,6], fp32_math='fast', activation_bits=32)
output = work/'qwen3-quality.json'
for prefill in (64, 768):
    rows, _ = prefix_workloads(tokenizer, prefill+1)
    ids = rows[0]['ids']
    hashes = {}
    for name, binary in binaries.items():
        logits, metrics = run_native(binary, artifact, [ids], mode='chunked', chunk=prefill, **common)
        assert metrics['source_bf16_tensors'] > 0 and np.isfinite(logits).all()
        hashes[name] = hashlib.sha256(memoryview(logits).cast('B')).hexdigest()
        count = logits.size
        del logits
    exact = hashes['before'] == hashes['after']
    assert exact, prefill
    write_record(work/f'qwen3-{prefill}-tokens.json', dict(benchmark_ids=ids))
    generation_rows, _ = prefix_workloads(tokenizer, prefill)
    generated = [
        [run_native(binary, artifact, [row['ids']], mode='generate', generate=64, **common)[1]['generated_tokens']
         for row in generation_rows] for binary in binaries.values()
    ]
    assert generated[0] == generated[1]
    record['workloads'][prefill] = dict(exact_logits=count, logit_hashes=hashes, greedy_matches=True,
                                       generated_token_counts=list(map(len,generated[0])))
    print(prefill, count, list(map(len, generated[0])), 'bit-exact logits and equal greedy tokens', flush=True)
    write_record(output, record)
assert all(digest(p) == record['hashes'][str(p)] for p in bound)
record.update(complete=True, passed=True)
write_record(output, record)
