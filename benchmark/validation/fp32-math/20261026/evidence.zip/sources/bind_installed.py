"""Bind installed code/constants to the fully qualified native binary."""
import hashlib,json,struct
from pathlib import Path

base=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sections(path):
    data=path.read_bytes()
    assert data[:2]==b'MZ'
    pe=struct.unpack_from('<I',data,60)[0]
    assert data[pe:pe+4]==b'PE\0\0'
    count=struct.unpack_from('<H',data,pe+6)[0]
    optional=struct.unpack_from('<H',data,pe+20)[0]
    result={}
    for i in range(count):
        off=pe+24+optional+40*i
        name=data[off:off+8].rstrip(b'\0').decode()
        size,start=struct.unpack_from('<II',data,off+16)
        assert start+size<=len(data)
        result[name]=hashlib.sha256(data[start:start+size]).hexdigest()
    return result
qualified=Path((base/'runtime-final.txt').read_text().strip())
installed=base/'installed/leaf/bin/leaf_decoder.exe'
proof=json.loads((base/'trained/quality.json').read_text())
assert proof['complete'] and proof['passed'] and proof['hashes'][str(qualified)]==digest(qualified)
a,b=sections(qualified),sections(installed)
matching={k:dict(qualified=a[k],installed=b[k],exact=a[k]==b[k]) for k in ('.text','.rdata','.data')}
assert all(v['exact'] for v in matching.values())
record=dict(passed=True,scope='Executable code, read-only constants and initialized data match; PE timestamp is not a mathematical difference.',
 qualified_binary_sha256=digest(qualified),installed_binary_sha256=digest(installed),
 trained_proof_sha256=digest(base/'trained/quality.json'),sections=matching)
(base/'installed-code-binding.json').write_text(json.dumps(record,indent=2)+'\n')
print('PASS installed .text/.rdata/.data match the trained-qualified runtime')
