"""Curate native math-policy proof without models, logits or executables."""
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile
from pathlib import Path

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
OUT=ROOT/'benchmark/validation/fp32-math/20261026'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
OUT.mkdir(parents=True,exist_ok=False)
(OUT/'.gitattributes').write_text('* -text\n',encoding='utf-8',newline='\n')
quality=json.loads((BASE/'trained/quality.json').read_text())
architecture=json.loads((BASE/'architectures.json').read_text())
installed=json.loads((BASE/'installed-check.json').read_text())
binding=json.loads((BASE/'installed-code-binding.json').read_text())
build=json.loads((BASE/'build-final.json').read_text())
units=ET.parse(BASE/'all-units.xml').getroot()
assert quality['complete'] and quality['passed'] and not quality['timing_qualified']
assert architecture['paired_bit_exact_regression_passed'] and len(architecture['results'])==10
assert installed['passed'] and binding['passed']
assert sum(1 for _ in units.iter('testcase'))==1206
assert not list(units.iter('failure')) and not list(units.iter('error'))
for p,h in build['sources'].items():
 if Path(p).suffix in ('.cpp','.h'):assert digest(Path(p))==h
kernel=BASE/'test_accurate_fp32.exe'
result=subprocess.run([str(kernel)],capture_output=True,text=True,check=True)
assert '43456 outputs' in result.stdout and 'exact=1' in result.stdout
kernel_proof=dict(passed=True,stdout=result.stdout,executable_sha256=digest(kernel),
 source_sha256=digest(ROOT/'tests/native/test_accurate_fp32.cpp'))
write(BASE/'native-kernel.json',kernel_proof)
wheel=next((BASE/'wheels').glob('*.whl'))
original_failures=ET.parse(BASE/'unit-focused.xml').getroot()
failed=list(original_failures.iter('failure'))
failure_summary=dict(passed=False,failures=len(failed),raw_report_sha256=digest(BASE/'unit-focused.xml'),
 direct_permission_failures=sum('PermissionError' in f.text or 'WinError 5' in f.text for f in failed),
 other_failure='Missing metrics downstream of temporary-folder access denial',
 correction='Workspace TEMP/TMP, fresh --basetemp, no pytest cache; original failed XML retained locally.')
write(BASE/'initial-failure-summary.json',failure_summary)
summary=dict(complete=True,passed=True,timing_qualified=False,default_fp32_math='fast',
 available_math=['fast','accurate'],storage_format_unchanged=True,
 scope='Native opt-in accurate-policy migration to retained complete trained qualification. No fresh PyTorch oracle or timing promotion.',
 unit_tests=dict(passed=1204,skipped=2),native_kernel_outputs=43456,
 trained_blocks=sum(len(x['blocks']) for x in quality['models'].values()),
 trained_logit_values=sum(b['logits'] for x in quality['models'].values() for b in x['blocks']),
 continuations=sum(len(x['generations']) for x in quality['models'].values()),
 controls=sum(len(x['controls']) for x in quality['models'].values()),
 default_trained_regressions=len(quality['regressions'])+sum(len(x['fast_regression']) for x in quality['models'].values()),
 reduced_architectures=len(architecture['results']),installed_combined_path_passed=True,
 wheel=dict(name=wheel.name,bytes=wheel.stat().st_size,sha256=digest(wheel)),
 initial_failed_attempt=failure_summary,
 limitations=['Accurate remains opt-in; ordinary fast strict misses are not relabeled fixed.',
 'Performance qualification and default promotion remain open.',
 'BF16 storage remains output head/tied embeddings; interior projections stay FP32.'])
write(OUT/'summary.json',summary)
files={
 'summary.json':OUT/'summary.json','trained-quality.json':BASE/'trained/quality.json',
 'all-units.xml':BASE/'all-units.xml','focused-units.xml':BASE/'unit-focused-v2.xml',
 'policy-evaluation-units.xml':BASE/'unit-policy-evaluation.xml','architectures.json':BASE/'architectures.json',
 'native-kernel.json':BASE/'native-kernel.json','installed-check.json':BASE/'installed-check.json',
 'installed-code-binding.json':BASE/'installed-code-binding.json','native-build.json':BASE/'build-final.json',
 'initial-failure-summary.json':BASE/'initial-failure-summary.json',
 'historical-reconstruction.json':BASE/'historical-reconstruction/build.json',
 'sources/verify_installed.py':BASE/'verify_installed.py','sources/bind_installed.py':BASE/'bind_installed.py',
 'sources/collect_evidence.py':Path(__file__),
}
changed=['engine/include/leaf/kernels/accurate_fp32.h','engine/include/leaf/runtime/decoder.h',
 'engine/src/decoder.cpp','engine/src/main_decoder.cpp','engine/CMakeLists.txt',
 'leaf/cli.py','leaf/evaluation.py','pyproject.toml','tools/decoder_validation.py',
 'tools/validate_fp32_math.py','tests/native/test_accurate_fp32.cpp','tests/unit/test_fp32_math.py',
 'benchmark/experiments/linear-accumulation/build.py']
for relative in changed:files['sources/'+relative]=ROOT/relative
archive=OUT/'evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for n,p in files.items():z.writestr(n,p.read_bytes())
manifest=dict(complete=True,passed=True,timing_qualified=False,
 base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True,cwd=ROOT).strip(),
 archive=archive.name,archive_sha256=digest(archive),entries={n:digest(p) for n,p in files.items()},
 source_sha256={p:digest(ROOT/p) for p in changed},
 omitted='Model weights, logits, native binaries, wheels, installed packages and raw permission-failure XML.')
write(OUT/'manifest.json',manifest)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(manifest['entries'])
 for n,h in manifest['entries'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print(json.dumps(dict(entries=len(files),bytes=archive.stat().st_size,sha256=digest(archive),summary=summary)))
