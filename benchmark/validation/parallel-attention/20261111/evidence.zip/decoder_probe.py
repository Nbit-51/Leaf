"""Check the same head scheduling on trained SmolLM2 and Qwen3 FP32 decoders."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import numpy as np

from leaf.power import keep_awake
from tools.decoder_validation import run_native
from tools.verify_embeddinggemma_reference import digest


work = Path(__file__).resolve().parent
repo = work.parent.parent
baseline = work / 'decoder' / 'leaf_decoder.exe'
candidate = work / 'decoder-heads.exe'
trained = work.parent / 'trained-operator-validation-20261109-211516'
original = (repo / 'engine/src/decoder.cpp').read_text(encoding='utf-8')
start = '                    leaf::kernels::attention_f32_gqa_strided_vector(q_heads.data(), cache.keys_data(),'
end = '                        total, cache.capacity(), dim, mask_shape, 1.0f / std::sqrt(std::sqrt(static_cast<float>(dim))));'
assert original.count(start) == original.count(end) == 1
first, last = original.index(start), original.index(end) + len(end)
replacement = '''                    const float scale = 1.0f / std::sqrt(std::sqrt(static_cast<float>(dim)));
                    auto attend_heads = [&](std::size_t first, std::size_t end) {
                        leaf::kernels::attention_f32_gqa_strided_vector(q_heads.data(), cache.keys_data(),
                            cache.values_data(), mask.data(), attention.data(), 1, heads, kv_heads, tokens,
                            total, cache.capacity(), dim, mask_shape, scale, true, true, first, end);
                    };
                    if (tokens >= 128 && heads > 1)
                        workers.run(heads, attend_heads, 1);
                    else
                        attend_heads(0, heads);'''
source = work / 'decoder-heads.cpp'
source.write_text(original[:first] + replacement + original[last:], encoding='utf-8')
subprocess.run(['g++', '-std=c++17', '-O3', '-DNDEBUG', '-pthread', '-static', '-static-libgcc',
                '-static-libstdc++', '-I', 'engine/include', str(source), 'engine/src/kv_cache.cpp',
                'engine/src/kernels/transformer.cpp', 'engine/src/main_decoder.cpp', '-o', str(candidate),
                '-lpsapi'], check=True)


def stats(x, y):
    return dict(before_p50_ms=float(np.median(x)), after_p50_ms=float(np.median(y)),
                before_spread=float(np.percentile(x, 90)/np.percentile(x, 10)),
                after_spread=float(np.percentile(y, 90)/np.percentile(y, 10)),
                paired_ratio=float(np.median(np.asarray(y)/x)))


models = {
    'qwen3': trained/'qwen3-artifacts/decoder-32.leaf',
    'smol': next((trained/'smol-cli/cache').glob('models/*/decoder-32.leaf')),
}
repeat = len(sys.argv) > 1 and sys.argv[1] == 'repeat'
if repeat:
    models = {'smol': models['smol']}
cpus = [0, 2, 4, 6]
out = work / ('decoder-repeat.json' if repeat else 'decoder-probe.json')
record = dict(scope='Paired runs for 256-token prefill and one decode token. Trained FP32 decoder pilot.',
              cpu_affinity=cpus, before_sha256=digest(baseline), after_sha256=digest(candidate),
              source_sha256=digest(source), models={}, complete=False)
with keep_awake():
    for label, artifact in models.items():
        fixture = trained / f'{label}-quality/tokens.json'
        saved = json.loads(fixture.read_bytes())['sequences']
        source_ids = [token for row in saved for token in row][:257]
        assert len(source_ids) == 257
        assert source_ids != source_ids[:1]*257
        common = dict(threads=4, worker_cpus=cpus, activation_bits=32)
        old, _ = run_native(baseline, artifact, [source_ids], **common)
        new, _ = run_native(candidate, artifact, [source_ids], **common)
        assert np.isfinite(new).all() and old.tobytes() == new.tobytes()
        checks = dict(artifact_sha256=digest(artifact), fixture_sha256=digest(fixture),
                      tokens_sha256=hashlib.sha256(np.asarray(source_ids,dtype='<u4').tobytes()).hexdigest(),
                      logits_bit_identical=True, full_logits_shape=list(new.shape), pairs=[])
        del old, new
        record['models'][label] = checks
        for round_id in range(6 if repeat else 4):
            order = ['before', 'after'] if round_id % 2 == 0 else ['after', 'before']
            pair = dict(order=order)
            for version in order:
                _, metrics = run_native(baseline if version == 'before' else candidate, artifact,
                                        [source_ids], mode='bench', runs=5 if repeat else 3,
                                        warmup=2 if repeat else 1, **common)
                assert metrics['optimized_fp32_active'] and metrics['benchmark_ac_checked']
                pair[version] = {key: metrics[key] for key in
                                 ('prefill_samples_ms','decode_samples_ms','peak_rss_bytes')}
            checks['pairs'].append(pair)
            out.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
            print(label, round_id+1, flush=True)
        for phase in ('prefill','decode'):
            values = [[float(np.median(pair[version][f'{phase}_samples_ms'])) for pair in checks['pairs']]
                      for version in ('before','after')]
            checks[phase] = stats(*values)
        print(label, checks['prefill'], checks['decode'], flush=True)
record['complete'] = True
out.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
