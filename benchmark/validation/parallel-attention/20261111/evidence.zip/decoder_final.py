import hashlib
import json
from pathlib import Path
import sys

import numpy as np

from leaf.power import keep_awake
from tools.decoder_validation import run_native
from tools.verify_embeddinggemma_reference import digest


work = Path(__file__).resolve().parent
trained = work.parent/'trained-operator-validation-20261109-211516'
models = {
    'qwen3': trained/'qwen3-artifacts/decoder-32.leaf',
    'smol': next((trained/'smol-cli/cache').glob('models/*/decoder-32.leaf')),
}
binaries = dict(before=work/'decoder/leaf_decoder.exe', after=work/'final/leaf_decoder.exe')
priority = 'priority' in sys.argv[1:]
qwen_only = 'qwen-only' in sys.argv[1:]
if qwen_only:
    models = {'qwen3': models['qwen3']}
record = dict(scope='Final production binary. Trained FP32, four physical P-cores, 256-token prefill plus one decode token.',
              priority='above-normal' if priority else 'default',
              cpu_affinity=[0,2,4,6], hashes={key:digest(path) for key,path in binaries.items()},
              models={}, complete=False)
out = work/('decoder-qwen-repeat.json' if qwen_only else 'decoder-priority.json' if priority else 'decoder-final.json')
with keep_awake():
    for label, artifact in models.items():
        fixture = trained/f'{label}-quality/tokens.json'
        saved = json.loads(fixture.read_bytes())['sequences']
        ids = [token for row in saved for token in row][:257]
        assert len(ids) == 257
        model = dict(artifact_sha256=digest(artifact), fixture_sha256=digest(fixture),
                     ids_sha256=hashlib.sha256(np.asarray(ids,dtype='<u4').tobytes()).hexdigest(),
                     quality=[], pairs=[])
        record['models'][label] = model
        for threads, length in ((1,129),(2,129),(4,257)):
            cpus = [0,2,4,6][:threads]
            old, _ = run_native(binaries['before'],artifact,[ids[:length]],threads=threads,
                                worker_cpus=cpus,activation_bits=32)
            new, _ = run_native(binaries['after'],artifact,[ids[:length]],threads=threads,
                                worker_cpus=cpus,activation_bits=32)
            assert old.tobytes() == new.tobytes() and np.isfinite(new).all()
            model['quality'].append(dict(threads=threads,tokens=length,logits_bit_identical=True,
                                         shape=list(new.shape)))
            del old,new
        for index in range(6):
            order = ['before','after'] if index%2 == 0 else ['after','before']
            pair = dict(order=order)
            for version in order:
                _, metrics = run_native(binaries[version],artifact,[ids],mode='bench',threads=4,
                                        worker_cpus=[0,2,4,6],activation_bits=32,runs=5,warmup=2,
                                        windows_above_normal=priority)
                assert metrics['benchmark_ac_checked']
                pair[version] = {key:metrics[key] for key in
                                 ('prefill_samples_ms','decode_samples_ms','peak_rss_bytes')}
            model['pairs'].append(pair)
            out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
            print(label,index+1,flush=True)
        for phase in ('prefill','decode'):
            old,new = (np.asarray([np.median(pair[version][f'{phase}_samples_ms']) for pair in model['pairs']])
                       for version in ('before','after'))
            model[phase] = dict(before_p50_ms=float(np.median(old)),after_p50_ms=float(np.median(new)),
                                before_spread=float(np.percentile(old,90)/np.percentile(old,10)),
                                after_spread=float(np.percentile(new,90)/np.percentile(new,10)),
                                paired_ratio=float(np.median(new/old)))
        print(label,model['prefill'],model['decode'],flush=True)
record['complete'] = True
out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
