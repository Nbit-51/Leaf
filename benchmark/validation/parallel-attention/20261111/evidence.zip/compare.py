import json
import os
from pathlib import Path
import platform
import struct
import subprocess
import sys
import time

import numpy as np
import psutil
from tokenizers import Tokenizer

from leaf.embedding import format_text
from leaf.power import keep_awake
from tools.diagnose_windows_benchmark import cpu_sets
from tools.embedding_validation import parity
from tools.verify_embeddinggemma_reference import digest


work = Path(__file__).resolve().parent
build = work.parent
scifact = build / 'resumable-scifact-20261109'
model = build / 'models' / 'embeddinggemma-300m'
artifact, = (build / 'trained-operator-validation-20261109-211516' / 'embedding-cache').glob('embeddings/*/model.leaf')
model_hash = digest(artifact)
assert model_hash == json.loads((scifact / 'full-documents' / 'result.json').read_bytes())['artifact_sha256']
bins = {label: work / label / 'benchmark.exe' for label in ('baseline', 'candidate')}
llama_root = build / 'competitors' / 'llama-b11540'
bins['llama'] = llama_root / 'bin' / 'llama-embedding-benchmark.exe'
gguf = llama_root / 'embeddinggemma-f32-complete.gguf'
tokenizer = Tokenizer.from_file(str(model / 'tokenizer.json'))
tokenizer.no_truncation()
tokenizer.no_padding()
docs = [json.loads(row) for row in (scifact / 'documents.jsonl').read_bytes().splitlines()]
doc_ids = [row['_id'] for row in docs]
encoded = [row.ids for row in tokenizer.encode_batch([row['text'] for row in docs])]
corpus = np.load(scifact / 'full-documents' / 'embeddings.npy', mmap_mode='r')
queries = [json.loads(row) for row in (scifact / 'queries.jsonl').read_bytes().splitlines()]
query_ids = [row['_id'] for row in queries]
query_tokens = [row.ids for row in tokenizer.encode_batch([format_text(row['text'], 'query') for row in queries])]
query_vectors = np.load(scifact / 'full-queries' / 'embeddings.npy')


def request(path, rows):
    with path.open('wb') as output:
        output.write(b'LEAFER01' + struct.pack('<I', len(rows)))
        for row in rows:
            output.write(struct.pack('<I', len(row)))
            output.write(np.asarray(row, dtype='<u4').tobytes())


def output_vectors(path, count):
    values = np.fromfile(path, dtype='<f4')
    assert values.size == count * 768
    return values.reshape(count, 768)


def exact(actual, expected):
    if actual.tobytes() != expected.tobytes():
        raise ValueError(f'Embedding output changed: max abs {np.max(np.abs(actual - expected))}')


def native_check():
    ref = json.loads((work.parent.parent / 'benchmark/validation/scifact/20261110/reference-parity.json').read_bytes())
    selected = [doc_ids.index(row) for row in ref['documents']['ids']]
    records = []
    inputs = [
        (4, [encoded[i] for i in selected] + query_tokens, np.concatenate([corpus[selected], query_vectors])),
        (2, [encoded[i] for i in selected[::5]], corpus[selected[::5]]),
        (1, [encoded[i] for i in selected[::5]], corpus[selected[::5]]),
    ]
    for threads, rows, expected in inputs:
        req = work / f'native-{threads}.request'
        raw = work / f'native-{threads}.vectors'
        request(req, rows)
        proc = subprocess.run([str(work/'candidate/leaf_embed.exe'), str(artifact), str(req), str(raw),
                               str(threads)], check=True, capture_output=True, text=True)
        exact(output_vectors(raw, len(rows)), expected)
        result = json.loads(proc.stdout)
        assert result['sequences'] == len(rows) and result['avx2'] and result['threads'] == threads
        records.append(dict(threads=threads, exact_rows=len(rows), lengths=[len(row) for row in rows]))
        print(f'Candidate native CLI {threads} thread(s): {len(rows)} saved FP32 embeddings bit-identical', flush=True)
    (work/'quality.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')


def timed(label, threads, req, expected, cpus):
    raw = work / 'timed.vectors'
    model_file = gguf if label == 'llama' else artifact
    cmd = [str(bins[label]), str(model_file), str(req), str(raw), str(threads), '1', '2',
           str(llama_root/'bin')]
    parent = psutil.Process()
    original = parent.cpu_affinity()
    log = work / 'child-stderr.txt'
    with log.open('w', encoding='utf-8') as errors:
        try:
            parent.cpu_affinity(cpus)
            child = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=errors, text=True)
        finally:
            parent.cpu_affinity(original)
        process = psutil.Process(child.pid)
        peak = 0
        plugged = set()
        while child.poll() is None:
            try:
                peak = max(peak, process.memory_info().peak_wset)
            except psutil.NoSuchProcess:
                break
            battery = psutil.sensors_battery()
            plugged.add(battery.power_plugged if battery else None)
            time.sleep(.15)
        stdout, _ = child.communicate()
    if child.returncode:
        stderr = log.read_text(encoding='utf-8', errors='replace')
        raise RuntimeError(f'{label} exit {child.returncode}: {stderr[-1500:]}')
    samples = np.asarray(json.loads(stdout)['samples_ms'])
    assert samples.shape == (len(expected), 2) and (samples > 0).all()
    vectors = output_vectors(raw, len(expected))
    if label == 'llama':
        quality = parity(vectors, expected)
    else:
        exact(vectors, expected)
        quality = dict(bit_identical=True)
    return dict(samples_ms=samples.tolist(), sampled_peak_working_set_bytes=peak, plugged=list(plugged),
                quality=quality)


def spread(values):
    return float(np.percentile(values, 90) / np.percentile(values, 10))


def compare(other, rounds, threads, suffix=''):
    topology = {row['logical_cpu']:row for row in cpu_sets() if row['group'] == 0}
    cpus = [0, 2, 4, 6][:threads]
    assert len({topology[cpu]['core'] for cpu in cpus}) == threads
    is_query = suffix == '-query'
    pool = query_tokens if is_query else encoded
    vectors = query_vectors if is_query else corpus
    names = query_ids if is_query else doc_ids
    targets = [8, 16, 32, 59] if is_query else [48, 127, 128, 320, 515, 1024]
    selected = [min(range(len(pool)), key=lambda i:abs(len(pool[i])-target)) for target in targets]
    rows = [pool[i] for i in selected]
    expected = vectors[selected]
    lengths = [len(row) for row in rows]
    request_file = work / f'paired-{other}-{threads}{suffix}.request'
    request(request_file, rows)
    out = work / f'paired-{other}-{threads}{suffix}.json'
    if out.exists():
        raise FileExistsError(out)
    report = dict(scope='Warm token IDs to normalized FP32 vectors, including all encoder operations.',
                  platform=platform.platform(), threads=threads, cpus=[topology[cpu] for cpu in cpus],
                  input_kind='queries' if is_query else 'documents',
                  rows=[dict(document_id=names[i],tokens=len(pool[i])) for i in selected],
                  hashes=dict(artifact=model_hash, request=digest(request_file),
                              candidate=digest(bins['candidate']), reference=digest(bins[other])),
                  batches=[], complete=False, gate=dict(max_spread=1.25, max_paired_ratio=.98))
    if other == 'llama':
        report['hashes']['gguf'] = digest(gguf)
        assert report['hashes']['gguf'] == '1ec9c3fda09b363222c9998fc10988e6b28ed1bbed0c93c4d95c7e894fde235f'
    for index in range(rounds):
        order = [other, 'candidate'] if index % 2 == 0 else ['candidate', other]
        record = dict(order=order)
        for label in order:
            record[label] = timed(label, threads, request_file, expected, cpus)
        report['batches'].append(record)
        out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
        print(other, threads, index+1, [round(np.median(record[label]['samples_ms'],axis=1).sum(),2)
                                      for label in (other,'candidate')], flush=True)
    def medians(label):
        return np.asarray([np.median(record[label]['samples_ms'],axis=1) for record in report['batches']])
    old, new = medians(other), medians('candidate')
    def summary(left, right):
        return dict(before_p50=float(np.median(left)), after_p50=float(np.median(right)),
                    before_spread=spread(left), after_spread=spread(right),
                    paired_ratio=float(np.median(right/left)))
    report['per_length'] = [dict(tokens=length, **summary(old[:,i],new[:,i])) for i,length in enumerate(lengths)]
    report['mixed_workload'] = summary(old.sum(axis=1),new.sum(axis=1))
    report['complete'] = True
    out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'mixed': report['mixed_workload'], 'per_length':report['per_length']}), flush=True)


def cli_comparison(rounds):
    threads = 4
    cpus = [0, 2, 4, 6]
    ranked = sorted(range(len(encoded)), key=lambda index: len(encoded[index]))
    selected = [ranked[int((len(ranked)-1)*q)] for q in np.linspace(.05, .95, 16)]
    dataset = work / 'cli-documents.jsonl'
    dataset.write_text(''.join(json.dumps(docs[i])+'\n' for i in selected), encoding='utf-8')
    out = work / 'paired-cli-4.json'
    report = dict(scope='End-to-end offline leaf embed command, warmed model artifact cache.',
                  threads=threads, cpu_affinity=cpus, hashes=dict(dataset=digest(dataset), artifact=model_hash),
                  document_ids=[doc_ids[i] for i in selected], lengths=[len(encoded[i]) for i in selected],
                  pairs=[], complete=False)
    for index in range(rounds):
        order = ('baseline','candidate') if index % 2 == 0 else ('candidate','baseline')
        pair = dict(order=order)
        for label in order:
            result = work/f'cli-{index}-{label}.npy'
            metrics = work/f'cli-{index}-{label}.json'
            runtime = work/label/'leaf_embed.exe'
            report['hashes'][label] = digest(runtime)
            env = os.environ.copy()
            env['LEAF_EMBED_BIN'] = str(runtime)
            env['LEAF_CACHE_DIR'] = str(build/'trained-operator-validation-20261109-211516/embedding-cache')
            assert psutil.sensors_battery().power_plugged
            parent = psutil.Process()
            affinity = parent.cpu_affinity()
            try:
                parent.cpu_affinity(cpus)
                started = time.perf_counter()
                subprocess.run([sys.executable, '-m', 'leaf.cli', 'embed', str(model), '--offline',
                                '--dataset', str(dataset), '--task', 'raw', '--threads', str(threads),
                                '--output', str(result), '--metrics', str(metrics)], env=env,
                               check=True, capture_output=True, text=True)
                elapsed = time.perf_counter() - started
            finally:
                parent.cpu_affinity(affinity)
            assert psutil.sensors_battery().power_plugged
            exact(np.load(result, allow_pickle=False), corpus[selected])
            measured = json.loads(metrics.read_bytes())
            assert measured['documents'] == len(selected) and measured['artifact_sha256'] == model_hash
            pair[label] = dict(wall_ms=elapsed*1000, native_process_ms=measured['native_process_ms'],
                               preparation_ms=measured['preparation_ms'], bit_identical=True)
        report['pairs'].append(pair)
        out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
        print('CLI', index+1, [round(pair[label]['wall_ms'],1) for label in ('baseline','candidate')], flush=True)
    old, new = (np.asarray([row[label]['wall_ms'] for row in report['pairs']]) for label in ('baseline','candidate'))
    report['timing'] = dict(before_p50=float(np.median(old)), after_p50=float(np.median(new)),
                            before_spread=spread(old), after_spread=spread(new),
                            paired_ratio=float(np.median(new/old)))
    report['complete'] = True
    out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report['timing']), flush=True)


with keep_awake():
    if sys.argv[1] == 'quality':
        native_check()
    elif sys.argv[1] == 'cli':
        cli_comparison(int(sys.argv[2]))
    else:
        compare(sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), *sys.argv[4:])
