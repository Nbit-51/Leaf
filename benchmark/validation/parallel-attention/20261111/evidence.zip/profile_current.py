"""Profile caller-side embedding phases, including worker completion time."""
import json
from pathlib import Path
import subprocess

import numpy as np
import psutil


work = Path(__file__).resolve().parent
repo = work.parent.parent
model, = (work.parent/'trained-operator-validation-20261109-211516/embedding-cache').glob('embeddings/*/model.leaf')
source = (repo/'engine/src/embedding.cpp').read_text(encoding='utf-8')
header = work/'embedding-profile.h'
header.write_text(r'''
#include <chrono>
#include <iostream>
#include <map>
namespace profile {
inline std::map<std::string, double> times;
struct Timer {
    std::string label;
    std::chrono::steady_clock::time_point start;
    explicit Timer(std::string name): label(std::move(name)), start(std::chrono::steady_clock::now()) {}
    ~Timer() {
        times[label] += std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
    }
};
}
''', encoding='utf-8')
replacements = [
    ('float epsilon) {', 'float epsilon) { profile::Timer timer("norm");'),
    ('const auto &w = weights.at(name);',
     'const auto group = name.find("mlp.") != std::string::npos ? "mlp" : name.find("pool.") == 0 ? "output" : "projection";\n'
     'profile::Timer total(std::string(group)+"_total"); const auto &w = weights.at(name);'),
    ('panels.pack(x.data(), tokens, w.cols, w.cols);',
     '{ profile::Timer pack(std::string(group)+"_pack"); panels.pack(x.data(), tokens, w.cols, w.cols); }\n'
     'profile::Timer compute(std::string(group)+"_gemm");'),
    ('const auto tokens = ids.size();', 'profile::times.clear(); const auto begin = std::chrono::steady_clock::now(); const auto tokens = ids.size();'),
    ('attention.resize(tokens * heads * dim);', '{ profile::Timer timer("attention"); attention.resize(tokens * heads * dim);'),
    ('linear(attention, tokens, p + "self_attn.o_proj.weight", projected);', '} linear(attention, tokens, p + "self_attn.o_proj.weight", projected);'),
    ('kernels::gelu_new_inplace(gate.data(), gate.size(), avx);', '{ profile::Timer timer("gelu_gate"); kernels::gelu_new_inplace(gate.data(), gate.size(), avx);'),
    ('linear(gate, tokens, p + "mlp.down_proj.weight", projected);', '} linear(gate, tokens, p + "mlp.down_proj.weight", projected);'),
    ('return result;', r'''
        profile::times["total"] = std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
        std::cerr << "{\"tokens\":" << tokens;
        for (const auto& [name, value] : profile::times) std::cerr << ",\"" << name << "\":" << value;
        std::cerr << "}\n";
        return result;'''),
]
for old, new in replacements:
    assert source.count(old) == 1, old
    source = source.replace(old, new)
path = work/'profile-embedding.cpp'
path.write_text('#include "embedding-profile.h"\n'+source, encoding='utf-8')
exe = work/'profile.exe'
subprocess.run(['g++','-std=c++17','-O3','-DNDEBUG','-ffp-contract=off','-pthread','-static',
                '-I','engine/include','benchmark/embedding_runtime_benchmark.cpp',str(path),
                'engine/src/kernels/transformer.cpp','-o',str(exe)],check=True)
process = psutil.Process()
original = process.cpu_affinity()
try:
    process.cpu_affinity([0,2,4,6])
    result = subprocess.run([str(exe),str(model),str(work/'paired-baseline-4.request'),
                             str(work/'profile.vectors'),'4','1','2','unused'],
                            check=True,capture_output=True,text=True)
finally:
    process.cpu_affinity(original)
record = dict(scope='Instrumented phase diagnosis only. Projection/MLP pack and GEMM are subsets of their totals.',
              threads=4, cpu_affinity=[0,2,4,6], samples=json.loads(result.stdout),
              phases=[json.loads(row) for row in result.stderr.splitlines()])
paired = json.loads((work/'paired-baseline-4-repeat.json').read_bytes())
doc_ids = [json.loads(row)['_id'] for row in (work.parent/'resumable-scifact-20261109/documents.jsonl').read_bytes().splitlines()]
indices = [doc_ids.index(row['document_id']) for row in paired['rows']]
expected = np.load(work.parent/'resumable-scifact-20261109/full-documents/embeddings.npy')[indices]
actual = np.fromfile(work/'profile.vectors',dtype='<f4').reshape(len(indices),768)
assert expected.tobytes() == actual.tobytes()
record['bit_identical'] = True
record['medians'] = []
for i,row in enumerate(paired['rows']):
    phases = record['phases'][i*3+1:i*3+3]
    record['medians'].append(dict(tokens=row['tokens'], **{key:float(np.median([p[key] for p in phases])) for key in phases[0] if key != 'tokens'}))
(work/'operation-profile.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record['medians'],indent=2))
