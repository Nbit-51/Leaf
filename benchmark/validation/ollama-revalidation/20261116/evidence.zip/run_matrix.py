import json, subprocess, sys
from pathlib import Path

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake

work = Path(__file__).resolve().parent
build = work.parent
family = build / "ollama-family-20261019"
hub = build / "family-models-20261017/cache/hub"
smol = hub/"models--HuggingFaceTB--SmolLM2-360M-Instruct/snapshots/a10cc1512eabd3dde888204e902eca88bddb4951"
qwen, = (hub/"models--Qwen--Qwen2.5-0.5B-Instruct/snapshots").glob("*")
common = ["--ollama-executable", str(work/"latest/runtime/ollama.exe"),
          "--leaf-executable", str(work/"leaf-adapter.exe"),
          "--ollama-models", str(family/"models"), "--worker-cpus", "0", "2", "4", "6",
          "--diagnostic-timing"]
smol_args = ["--ollama-model", "leaf-smollm2-360m-f32", "--snapshot", str(smol),
             "--gguf-audit", str(family/"smol/gguf-audit.json"),
             "--leaf-artifact", str(build/"presentation-20261115/smol-source-bf16/decoder-32-source-bf16.leaf"),
             "--leaf-fp32-reference", str(family/"smol/decoder-32.leaf")]
qwen_args = ["--ollama-model", "leaf-qwen25-05b-f32", "--snapshot", str(qwen),
             "--gguf-audit", str(family/"qwen/gguf-audit.json"),
             "--leaf-artifact", str(family/"qwen/decoder-32.leaf")]
power = {}
report = dict(power_mode=power, completed_cases={})
output = work/"matrix.json"
try:
    with keep_awake(), benchmark_power_mode_guard(power, required_mode="better-battery"):
        for name, flags, prompt, generated in (
            ("smol-64-2-latest", smol_args, 64, 2),
            ("qwen-64-2-latest", qwen_args, 64, 2),
            ("smol-256-16-latest", smol_args, 256, 16),
        ):
            print(name, flush=True)
            run = subprocess.run([sys.executable, "-m", "tools.benchmark_ollama_decoder",
                                  *common, *flags, "--prompt-tokens", str(prompt),
                                  "--generated-tokens", str(generated), "--output", str(work/name)])
            report["completed_cases"][name] = run.returncode
            write_record(output, report)
finally:
    write_record(output, report)
sys.exit(any(report["completed_cases"].values()))
