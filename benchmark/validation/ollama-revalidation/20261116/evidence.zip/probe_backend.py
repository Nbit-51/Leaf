"""Check direct token-level output on the llama-server bundled with Ollama."""
import json
from pathlib import Path

from leaf.evaluation import write_record
from tools.benchmark_ollama_decoder import backend_port
from tools.ollama_validation import api, generation_request, local_server


work = Path(__file__).resolve().parent
build = work.parent
family = build / "ollama-family-20261019"
exe = work / "latest/runtime/ollama.exe"
rows = (
    ("smol-64-2-latest", "leaf-smollm2-360m-f32", "models--HuggingFaceTB--SmolLM2-360M-Instruct"),
    ("qwen-64-2-latest", "leaf-qwen25-05b-f32", "models--Qwen--Qwen2.5-0.5B-Instruct"),
)
output = work / "backend-quality.json"
report = dict(complete=False, cases={})
from tokenizers import Tokenizer

with local_server(exe, family/"models", work/"backend-quality-server", cpus=[0,2,4,6]) as (base, _, server):
    for scenario, model, snapshot_prefix in rows:
        folder = work/scenario
        original = json.loads((folder/"comparison.json").read_bytes())
        leaf = [json.loads(x) for x in (folder/"leaf-quality/results.jsonl").read_text().splitlines()]
        snapshot, = (build/"family-models-20261017/cache/hub"/snapshot_prefix/"snapshots").glob("*")
        tokenizer = Tokenizer.from_file(str(snapshot/"tokenizer.json"))
        api(base, "/api/generate", generation_request(model, "Z", tokens=1, threads=4))
        backend, _ = backend_port(server, [0,2,4,6], 256, configure=True)
        results = report["cases"][model] = []
        for i, check in enumerate(original["quality"]["checks"]):
            if check["passed"]:
                continue
            prefix = tokenizer.encode(check["prompt"]).ids
            assert api(backend, "/tokenize", dict(content=check["prompt"], add_special=True))["tokens"] == prefix
            backend_result = api(backend, "/completion", dict(prompt=prefix, n_predict=8, n_probs=1,
                return_tokens=True, stream=False, temperature=0, cache_prompt=False, seed=0,
                repeat_penalty=1.0, top_p=1.0, min_p=0.0, stop=[]))
            fields = ("content", "tokens", "completion_probabilities", "probs", "stop_type", "timings")
            results.append(dict(index=i, leaf_token_ids=leaf[i]["generated_tokens"], leaf_logprobs=leaf[i]["selected_logprobs"],
                                backend={key:backend_result[key] for key in fields if key in backend_result}))
            print(model, i, backend_result.get("tokens"), leaf[i]["generated_tokens"], flush=True)
            write_record(output, report)
report["complete"] = True
write_record(output, report)
