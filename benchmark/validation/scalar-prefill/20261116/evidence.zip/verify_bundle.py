"""Verify the portable kernel is present in the installed Windows wheel."""
import hashlib
import json
from pathlib import Path
import tempfile

import numpy as np

from tools.decoder_validation import run_native
from tools.validate_decoder import digest

work = Path(__file__).resolve().parent
tempfile.tempdir = str(work)
build = work.parent
proof = json.loads((work / "two-worker-quality.json").read_bytes())
timing = json.loads((work / "results.json").read_bytes())
bundle = work / "venv/Lib/site-packages/leaf/bin/leaf_decoder.exe"
artifact = build / "trained-operator-validation-20261109-211516/pythia-artifacts/decoder-32.leaf"
case = proof["cases"]["Pythia-70M"]
output, native = run_native(bundle, artifact, [case["tokens"]], mode="chunked", threads=2,
                            scalar=True, chunk=64, fp32_math="accurate")
checksum = hashlib.sha256(memoryview(output).cast("B")).hexdigest()
assert np.isfinite(output).all() and checksum == case["sha256"] and not native["avx2"]
_, generation = run_native(bundle, artifact, [case["tokens"][:-1]], mode="generate",
                           threads=2, scalar=True, generate=16, fp32_math="accurate")
assert generation["generated_tokens"] == timing["cases"]["Pythia-70M"]["generated_tokens"]
wheel, = (work / "wheel").glob("*.whl")
result = dict(wheel_sha256=digest(wheel), bundled_decoder_sha256=digest(bundle),
              artifact_sha256=digest(artifact), bit_exact_logits=int(output.size), continuation_exact=True)
(work / "wheel-check.json").write_text(json.dumps(result,indent=2)+"\n")
print(result)
