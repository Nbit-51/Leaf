"""Check bit-exact portable projections with two Windows workers."""
import hashlib
import json
from pathlib import Path
import tempfile

import numpy as np
import psutil

from tools.decoder_validation import run_native
from tools.validate_decoder import digest


work = Path(__file__).resolve().parent
build = work.parent
tempfile.tempdir = str(work)
cases = (
    ("Pythia-70M", build / "trained-operator-validation-20261109-211516/pythia-artifacts/decoder-32.leaf"),
    ("OPT-125M", Path(json.loads((build / "fp32-long-20261115/parallel-quality.json").read_bytes())["models"]["opt"]["artifact"])),
)
binaries = (build / "offline-startup-20261116/venv/Lib/site-packages/leaf/bin/leaf_decoder.exe", work / "candidate.exe")
proof = json.loads((work / "results.json").read_bytes())
assert proof["complete"]
process = psutil.Process()
original = process.cpu_affinity()
result = dict(allowed_cpus=[0, 2], threads=2, cases={}, exact=True)
try:
    process.cpu_affinity([0, 2])
    for name, artifact in cases:
        data = proof["cases"][name]
        ids = [*data["prompt"], data["generated_tokens"][0]]
        outputs = [run_native(exe, artifact, [ids], mode="chunked", threads=2,
                              scalar=True, chunk=64, fp32_math="accurate")[0] for exe in binaries]
        assert all(np.isfinite(values).all() for values in outputs)
        checksums = [hashlib.sha256(memoryview(values).cast("B")).hexdigest() for values in outputs]
        assert checksums[0] == checksums[1] and digest(artifact) == data["artifact_sha256"]
        count = int(outputs[0].size)
        result["cases"][name] = dict(tokens=ids, logits=count, sha256=checksums[0])
finally:
    process.cpu_affinity(original)
(work / "two-worker-quality.json").write_text(json.dumps(result,indent=2)+"\n")
print({model: data["logits"] for model, data in result["cases"].items()})
