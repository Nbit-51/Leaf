"""Compare the portable FP32 prefill kernel on two trained decoders."""
import hashlib
import json
import os
from pathlib import Path
from statistics import median
import tempfile

import numpy as np
import psutil

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest


work = Path(__file__).resolve().parent
build = work.parent
tempfile.tempdir = str(work)
binaries = {"before": build / "offline-startup-20261116/venv/Lib/site-packages/leaf/bin/leaf_decoder.exe",
            "after": work / "candidate.exe"}
pythia = build / "trained-operator-validation-20261109-211516"
fixture = build / "fp32-long-20261115"
opt = Path(json.loads((fixture / "parallel-quality.json").read_bytes())["models"]["opt"]["artifact"])
models = {
    "Pythia-70M": (pythia / "pythia-artifacts/decoder-32.leaf", pythia / "pythia-quality/tokens.json"),
    "OPT-125M": (opt, fixture / "parallel-opt-tokens.json"),
}
models = {"OPT-125M": models["OPT-125M"]}
report = dict(complete=False, scope=__doc__, processor_affinity=[2], threads=1, backend="forced scalar",
              power_mode={}, cases={}, fingerprints={side:digest(exe) for side,exe in binaries.items()})
output = work / "opt-repeat.json"
os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
process = psutil.Process()
original = process.cpu_affinity()
configuration = dict(threads=1, scalar=True, fp32_math="accurate")


def logits(exe, artifact, ids, **options):
    values, metrics = run_native(exe, artifact, [ids], mode="chunked", chunk=len(ids)-1, **options)
    assert np.isfinite(values).all() and metrics["avx2"] is not options["scalar"]
    return dict(count=int(values.size), sha256=hashlib.sha256(memoryview(values).cast("B")).hexdigest())


try:
    process.cpu_affinity([2])
    assert process.cpu_affinity() == [2]
    first_run = json.loads((work / "results.json").read_bytes())
    assert first_run["complete"] and first_run["fingerprints"] == report["fingerprints"]
    for label, (artifact, _) in models.items():
        first_case = first_run["cases"][label]
        assert first_case["artifact_sha256"] == digest(artifact)
        report["cases"][label] = dict(first_case, pairs=[], summary=None)
    with keep_awake(), benchmark_power_mode_guard(report["power_mode"], required_mode="better-battery"):
        for label, (artifact, _) in models.items():
            data = report["cases"][label]
            for index in range(6):
                order = ("before", "after") if index % 2 == 0 else ("after", "before")
                pair = dict(order=order)
                for side in order:
                    require_benchmark_ac()
                    _, native = run_native(binaries[side], artifact, [data["prompt"]], mode="bench-generate",
                                           runs=5, warmup=2, generate=16, **configuration)
                    require_benchmark_ac()
                    assert native["benchmark_ac_checked"] and not native["avx2"] and native["fp32_math"] == "accurate"
                    assert native["generated_tokens"] == data["generated_tokens"]
                    pair[side] = dict(prefill=native["prefill_samples_ms"],
                                      decode=[median(steps) for steps in native["decode_steps_by_generation_ms"]],
                                      peak_rss_bytes=native["peak_rss_bytes"])
                data["pairs"].append(pair)
                print(label, index+1, *(round(median(pair[s]["prefill"]),2) for s in binaries), flush=True)
                write_record(output, report)
            summary = {}
            for phase, limit in (("prefill", .98), ("decode", 1.02)):
                rows = {side: [p[side][phase] for p in data["pairs"]] for side in binaries}
                pooled = {side: sum(series, []) for side,series in rows.items()}
                tests = [latency_stability(s) for series in (*rows.values(),list(pooled.values())) for s in series]
                ratio = median(median(a)/median(b) for b,a in zip(rows["before"],rows["after"]))
                stable = all(t["passed"] for t in tests)
                summary[phase] = dict(medians_ms={s:median(v) for s,v in pooled.items()},
                                      stable=stable, paired_ratio=ratio, passed=stable and ratio <= limit)
            data["summary"] = summary
            assert data["artifact_sha256"] == digest(artifact)
            print(label, summary, flush=True)
            write_record(output, report)
    assert report["fingerprints"] == {side:digest(exe) for side,exe in binaries.items()}
    report["complete"] = True
finally:
    process.cpu_affinity(original)
    write_record(output, report)
