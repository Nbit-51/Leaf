import json
import os
from pathlib import Path
import statistics
import sys
import tempfile

import psutil

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest

run = Path(__file__).parent
proof_path = root / 'build/source-bf16-timing-20261108/trained/quality.json'
proof = json.loads(proof_path.read_text(encoding='utf-8'))
assert proof['complete'] and proof['passed']
model = sys.argv[1] if len(sys.argv) > 1 else 'qwen'
model_proof = proof['models'][model]
reference = next(row for row in model_proof['generations'] if row['index'] == 0 and row['fp32_math'] == 'accurate')
assert reference['exact']
artifacts = {key: Path(model_proof[key]) for key in ('before', 'after')}
labels = {'before': 'FP32 storage', 'after': 'source BF16 matrix storage'}
runtime, = (run / 'native').glob('*/leaf_decoder.exe')
paths = [runtime, proof_path, *artifacts.values()]
hashes = {str(path): digest(path) for path in paths}
assert all(hashes[str(path)] == proof['hashes'][str(path)] for path in artifacts.values())
assert not any(value for key, value in os.environ.items()
               if key.startswith('LEAF_EXPERIMENTAL_') or key in ('LEAF_DECODER_PROFILE', 'LEAF_DISABLE_VNNI'))
report = dict(complete=False, scope='Native greedy continuation only; artifact load, cache reset and token streaming are excluded',
              hashes=hashes, expected_tokens=reference['generated_tokens'], prompt_ids=reference['input_ids'],
              cases=labels, threads=1, worker_cpus=[2], fp32_math='accurate', pairs=4, runs=5, warmup=2,
              passes=[], power={})
output = run / f'{model}-storage-comparison.json'
scratch = run / f'{model}-timing-temp'
scratch.mkdir()
tempfile.tempdir = str(scratch)
process = psutil.Process()
original_affinity = process.cpu_affinity()
os.environ['LEAF_BENCHMARK_REQUIRE_AC'] = '1'
try:
    process.cpu_affinity([2])
    with keep_awake(display=True), benchmark_power_mode_guard(report['power'], required_mode='better-battery'):
        for pair in range(report['pairs']):
            for key in (('before', 'after') if pair % 2 == 0 else ('after', 'before')):
                ac_before = require_benchmark_ac()
                _, metrics = run_native(runtime, artifacts[key], [report['prompt_ids']], mode='bench-generate',
                                        runs=report['runs'], warmup=report['warmup'], generate=8, worker_cpus=[2],
                                        fp32_math='accurate', windows_above_normal=True)
                ac_after = require_benchmark_ac()
                assert metrics['benchmark_ac_checked'] and metrics['generated_tokens'] == report['expected_tokens']
                assert (metrics['source_bf16_tensors'] > 0) == (key == 'after')
                rows = metrics['decode_steps_by_generation_ms']
                assert len(rows) == report['runs'] and all(len(row) == 7 for row in rows)
                samples = dict(prefill=metrics['prefill_samples_ms'], decode_total=[sum(row) for row in rows],
                               generation=metrics['generation_samples_ms'])
                stability = {phase: latency_stability(values) for phase, values in samples.items()}
                report['passes'].append(dict(pair=pair+1, case=key, samples_ms=samples, stability=stability,
                                             native=metrics, ac_before=ac_before, ac_after=ac_after))
                write_record(output, report)
                print(pair+1, labels[key], {phase: round(statistics.median(values), 2) for phase, values in samples.items()},
                      'stable=', all(row['passed'] for row in stability.values()), flush=True)
    report['summary'] = {}
    for phase in ('prefill', 'decode_total', 'generation'):
        per_case = {key: [p for p in report['passes'] if p['case'] == key] for key in labels}
        pools = {key: [value for p in passes for value in p['samples_ms'][phase]] for key, passes in per_case.items()}
        medians = {key: statistics.median(values) for key, values in pools.items()}
        spreads = {key: latency_stability(values) for key, values in pools.items()}
        ratios = [statistics.median(a['samples_ms'][phase])/statistics.median(b['samples_ms'][phase])
                  for a, b in zip(per_case['after'], per_case['before'])]
        report['summary'][phase] = dict(p50_ms=medians, pooled_stability=spreads, pooled_ratio=medians['after']/medians['before'],
                                        median_paired_ratio=statistics.median(ratios), stable=all(row['passed'] for row in spreads.values())
                                        and all(p['stability'][phase]['passed'] for p in report['passes']))
    assert all(digest(path) == hashes[str(path)] for path in paths)
    report['complete'] = True
    print(json.dumps(report['summary'], indent=2))
except BaseException as error:
    report['error'] = repr(error)
    raise
finally:
    process.cpu_affinity(original_affinity)
    write_record(output, report)
