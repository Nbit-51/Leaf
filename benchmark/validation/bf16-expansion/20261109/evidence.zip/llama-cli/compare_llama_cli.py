import codecs
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import threading
import time

run = Path(__file__).resolve().parent
root = run.parents[1]
sys.path.insert(0, str(root))
from leaf.affinity import pin_cpu
from leaf.cli import encode_prompt, model_directory
from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.benchmark_cli import CHILD_PROGRAM
from tools.decoder_validation import latency_stability
from tools.verify_package_runtime import digest, isolated_environment, run_process

out = run / sys.argv[1]
out.mkdir()
cache = run / 'cli-baseline/cache'
scratch = out / 'tmp'
scratch.mkdir()
binary, = (run / 'native').glob('*/leaf_decoder.exe')
llama_dir = root / 'build/competitors/llama-b11540/bin'
llama = llama_dir / 'llama-completion.exe'
tokenize = llama_dir / 'llama-tokenize.exe'
gguf = root / 'build/ollama-family-20261019/qwen/model-f32.gguf'
audit_path = gguf.with_name('gguf-audit.json')
audit = json.loads(audit_path.read_text())
assert audit['complete'] and audit['passed']
reference = json.loads((run / 'cli-baseline/qwen.json').read_text())
snapshot = Path(reference['snapshot'])
artifact = model_directory(snapshot, cache) / 'decoder-32.leaf'
assert digest(artifact) == reference['artifact_hashes']['fp32']
assert digest(binary) == reference['runtime_sha256']
tokens = root / 'build/linear-accumulation-20261019-pipeline/full-quality-qwen/tokens.json'
row = json.loads(tokens.read_text())['sequences'][0]
tokenizer, _ = encode_prompt(snapshot, 'Leaf', raw=True)
env = isolated_environment(cache)
env.update(LEAF_DECODER_BIN=str(binary), TEMP=str(scratch), TMP=str(scratch))
env = {key: value for key, value in env.items() if not key.startswith(('LLAMA_ARG_', 'GGML_'))}
llama_env = env | {'PATH': str(llama_dir) + os.pathsep + env['PATH']}
report = dict(complete=False, model='Qwen2.5-0.5B-Instruct', generated_tokens_requested=8, pairs=6,
              pinned_cpu=2, threads=1, scope='Fresh CLI processes, warm OS cache, FP32 weight values and FP32 KV; matched raw prompts',
              hashes={str(path): digest(path) for path in (llama, tokenize, gguf, audit_path, artifact, binary, tokens,
                                                           *sorted(llama_dir.glob('*.dll')))}, power={}, workloads={})
path = out / 'comparison.json'


def observe_llama(command):
    start = time.perf_counter()
    process = subprocess.Popen(command, cwd=llama_dir, env=llama_env, stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
    error = []
    reader = threading.Thread(target=lambda: error.append(process.stderr.read()), daemon=True)
    reader.start()
    chunks = bytearray()
    decoder = codecs.getincrementaldecoder('utf-8')()
    first = None
    while chunk := process.stdout.read(1):
        chunks.extend(chunk)
        if first is None and any(not value.isspace() for value in decoder.decode(chunk)):
            first = (time.perf_counter() - start) * 1000
    status = process.wait()
    reader.join()
    elapsed = (time.perf_counter() - start) * 1000
    stderr = error[0].decode('utf-8', errors='replace')
    if status:
        raise RuntimeError(f'llama.cpp exited {status}: {stderr[-1500:]}')
    assert first is not None and first <= elapsed
    return dict(external_wall_ms=elapsed, external_first_visible_text_ms=first,
                stdout=chunks.decode('utf-8'), stderr=stderr)


def execute(engine, prompt, length, pair):
    if engine == 'leaf':
        metrics_file = out / f'leaf-{length}-{pair}.json'
        args = ['run', str(snapshot), '--offline', '--raw', '--prompt', prompt, '--max-tokens', '8',
                '--bits', '32', '--fp32-math', 'accurate', '--threads', '1', '--worker-cpus', '2',
                '--metrics', str(metrics_file)]
        payload = json.dumps(dict(source_root=str(root), arguments=args))
        sample = run_process([sys.executable, '-I', '-u', '-c', CHILD_PROGRAM, payload], env, out)
        sample['metrics'] = json.loads(metrics_file.read_text())
        assert not sample['preparation_message_seen'] and sample['metrics']['worker_cpus'] == [2]
        assert sample['metrics']['source_bf16_tensors'] == 0 and sample['metrics']['fp32_math'] == 'accurate'
        assert len(sample['metrics']['generated_tokens']) == 8
    else:
        sample = observe_llama([str(llama), '-m', str(gguf), '-p', prompt, '--no-escape', '-ngl', '0',
            '-n', '8', '-t', '1', '-tb', '1', '-c', '256', '-b', '256', '-ub', '256', '-ctk', 'f32', '-ctv', 'f32',
            '-fa', 'off', '--temp', '0', '--repeat-penalty', '1', '--no-conversation', '--no-display-prompt',
            '--no-warmup', '--no-context-shift', '--simple-io', '--color', 'off'])
    sample.update(engine=engine, pair=pair)
    return sample


def text(sample):
    return sample['stdout'].replace('\r\n', '\n').rstrip('\n')


try:
    pin_cpu(2)
    with keep_awake(display=True), benchmark_power_mode_guard(report['power'], required_mode='better-battery'):
        for length in (63, 127):
            ids = row[:length]
            prompt = tokenizer.decode(ids, skip_special_tokens=False)
            assert encode_prompt(snapshot, prompt, raw=True)[1] == ids
            result = subprocess.run([str(tokenize), '-m', str(gguf), '-p', prompt, '--no-escape', '-ngl', '0',
                                     '--ids', '--no-bos', '--log-disable'], env=llama_env, cwd=llama_dir,
                                    capture_output=True, check=True)
            assert json.loads(result.stdout) == ids
            workload = dict(prompt_ids=ids, preflight={}, samples=[])
            report['workloads'][str(length)] = workload
            for engine in ('leaf', 'llama'):
                workload['preflight'][engine] = execute(engine, prompt, length, 0)
            expected = text(workload['preflight']['leaf'])
            workload['preflight_text_exact'] = expected == text(workload['preflight']['llama'])
            write_record(path, report)
            print(length, 'preflight exact text:', workload['preflight_text_exact'],
                  repr(expected), repr(text(workload['preflight']['llama'])), flush=True)
            for pair in range(1, report['pairs'] + 1):
                for engine in (('leaf', 'llama') if pair % 2 else ('llama', 'leaf')):
                    require_benchmark_ac()
                    sample = execute(engine, prompt, length, pair)
                    require_benchmark_ac()
                    sample['text_matches_leaf_reference'] = text(sample) == expected
                    assert text(sample) == text(workload['preflight'][engine])
                    if engine == 'leaf':
                        assert sample['metrics']['generated_tokens'] == workload['preflight']['leaf']['metrics']['generated_tokens']
                    workload['samples'].append(sample)
                    print(length, pair, engine, round(sample['external_first_visible_text_ms'], 2),
                          round(sample['external_wall_ms'], 2), flush=True)
                    write_record(path, report)
            workload['summary'] = {}
            for field in ('external_first_visible_text_ms', 'external_wall_ms'):
                values = {engine: [sample[field] for sample in workload['samples'] if sample['engine'] == engine]
                          for engine in ('leaf', 'llama')}
                medians = {engine: statistics.median(series) for engine, series in values.items()}
                spread = {engine: latency_stability(series) for engine, series in values.items()}
                workload['summary'][field] = dict(p50_ms=medians, stability=spread, stable=all(x['passed'] for x in spread.values()),
                    median_paired_leaf_over_llama=statistics.median(a/b for a,b in zip(values['leaf'], values['llama'])))
    assert all(digest(Path(name)) == checksum for name, checksum in report['hashes'].items())
    report['complete'] = True
except BaseException as error:
    report['error'] = repr(error)
    raise
finally:
    write_record(path, report)
