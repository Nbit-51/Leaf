import json
import os
from pathlib import Path
import sys
import tempfile

run = Path(__file__).resolve().parent
sys.path.insert(0, str(run.parents[1]))
from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.decoder_validation import run_native
from tools.validate_decoder import digest

runtime, = (run / 'native').glob('*/leaf_decoder.exe')
reference = json.loads((run / 'qwen-storage-comparison.json').read_text())
assert digest(runtime) == reference['hashes'][str(runtime)]
ids = reference['prompt_ids'] + reference['expected_tokens'][:1]
artifacts = {case: next(Path(path) for path in reference['hashes'] if Path(path).name == filename)
             for case, filename in [('fp32', 'decoder-32.leaf'), ('bf16', 'decoder-32-source-bf16.leaf')]}
assert all(digest(path) == reference['hashes'][str(path)] for path in artifacts.values())
scratch = run / 'first-prefill-tmp'
scratch.mkdir()
tempfile.tempdir = str(scratch)
os.environ['LEAF_BENCHMARK_REQUIRE_AC'] = '1'
record = dict(complete=False, scope='Instrumented fresh processes, warm OS file cache, four forwards with no warmup',
              power={}, prompt_ids=ids[:-1], fixed_decode_id=ids[-1], hashes=reference['hashes'], passes=[])
out = run / 'first-prefill.json'
try:
    with keep_awake(display=True), benchmark_power_mode_guard(record['power'], required_mode='better-battery'):
        for case in ('fp32', 'bf16', 'bf16', 'fp32'):
            require_benchmark_ac()
            _, metrics = run_native(runtime, artifacts[case], [ids], mode='bench', runs=4, warmup=0,
                                    threads=1, worker_cpus=[2], fp32_math='accurate', benchmark_counters=True)
            require_benchmark_ac()
            assert metrics['benchmark_ac_checked']
            record['passes'].append(dict(case=case, metrics=metrics))
            counters = metrics['benchmark_counters']['prefill']
            print(case, json.dumps({key: values for key, values in counters.items()
                                    if key in ('process_page_faults', 'process_cpu_ms', 'process_cycles')}
                                    | {'wall_ms': metrics['prefill_samples_ms']}), flush=True)
            write_record(out, record)
    record['complete'] = True
except BaseException as error:
    record['error'] = repr(error)
    raise
finally:
    write_record(out, record)
