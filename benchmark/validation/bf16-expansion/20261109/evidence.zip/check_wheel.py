import json
from pathlib import Path
import struct
import sys

run = Path(__file__).resolve().parent
root = run.parents[1]
sys.path.insert(0, str(root))
from leaf.cli import encode_prompt, model_directory
from leaf.evaluation import write_record
from tools.benchmark_cli import CHILD_PROGRAM
from tools.verify_package_runtime import digest, isolated_environment, run_process

installed = run / 'installed'
cache = run / 'cli-lazy-export/cache'
environment = isolated_environment(cache)
environment.update(TEMP=str(run / 'tmp'), TMP=str(run / 'tmp'))
runtime = installed / 'leaf/bin/leaf_decoder.exe'
source, = (run / 'native').glob('*/leaf_decoder.exe')


def pe_payloads(path):
    binary = path.read_bytes()
    pe, = struct.unpack_from('<I', binary, 60)
    assert binary[pe:pe+4] == b'PE\0\0'
    count, = struct.unpack_from('<H', binary, pe+6)
    optional, = struct.unpack_from('<H', binary, pe+20)
    sections = {}
    for i in range(count):
        offset = pe+24+optional+i*40
        name = binary[offset:offset+8].rstrip(b'\0')
        size, start = struct.unpack_from('<II', binary, offset+16)
        sections[name] = binary[start:start+size]
    return tuple(sections[name] for name in (b'.text', b'.rdata', b'.data'))


assert pe_payloads(runtime) == pe_payloads(source)
reference = json.loads((run / 'qwen-storage-comparison.json').read_text())
snapshot = Path(json.loads((run / 'cli-baseline/qwen.json').read_text())['snapshot'])
tokenizer, _ = encode_prompt(snapshot, 'Leaf', raw=True)
prompt = tokenizer.decode(reference['prompt_ids'], skip_special_tokens=False)
assert encode_prompt(snapshot, prompt, raw=True)[1] == reference['prompt_ids']
artifact, = (Path(path) for path in reference['hashes'] if path.endswith('decoder-32-source-bf16.leaf'))
directory = model_directory(snapshot, cache)
assert digest(directory / 'decoder-32-source-bf16-matrices.leaf') == reference['hashes'][str(artifact)]
def installed_command(arguments):
    program = CHILD_PROGRAM
    if arguments[0] == 'run':
        program = program.replace('("torch",', '("numpy", "torch",')
    payload = json.dumps(dict(source_root=str(installed), arguments=arguments))
    return run_process([sys.executable, '-I', '-u', '-c', program, payload], environment, run)


doctor = installed_command(['doctor', '--task', 'generation'])
info = json.loads(doctor['stdout'])['runtimes']['generation']
assert info['selection'] == 'bundled' and info['generation_benchmark_supported']
metrics_path = run / 'installed-qwen.json'
generation = installed_command(['run', str(snapshot), '--offline', '--raw', '--bits', '32', '--source-bf16',
                                '--fp32-math', 'accurate', '--prompt', prompt, '--max-tokens', '8',
                                '--metrics', str(metrics_path)])
metrics = json.loads(metrics_path.read_text())
assert metrics['generated_tokens'] == reference['expected_tokens']
assert metrics['source_bf16_tensors'] and metrics['fp32_math'] == 'accurate'
assert not generation['preparation_message_seen']
assert generation['stdout'].replace('\r\n', '\n') == tokenizer.decode(metrics['generated_tokens'], skip_special_tokens=True) + '\n'
write_record(run / 'wheel-check.json', dict(passed=True, bundled_runtime_sha256=digest(runtime), code_sections_match=True,
                                            runtime_info=info, generation=metrics, package_check=generation['package_check']))
print('PASS installed wheel: bundled runtime, cached Qwen BF16, eight matching tokens, no NumPy imported')
