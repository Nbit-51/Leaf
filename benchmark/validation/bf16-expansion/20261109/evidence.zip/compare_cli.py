import json
import os
from pathlib import Path
import statistics
import sys

run = Path(__file__).resolve().parent
root = run.parents[1]
sys.path.insert(0, str(root))
from leaf.cli import encode_prompt, model_directory
from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.benchmark_cli import CHILD_PROGRAM
from tools.decoder_validation import latency_stability
from tools.verify_package_runtime import digest, isolated_environment, run_process

tag = sys.argv[1]
startup_comparison = len(sys.argv) > 2 and sys.argv[2] == 'startup'
session = run / tag
session.mkdir()
cache = session / 'cache'
scratch = session / 'tmp'
scratch.mkdir()
runtime, = (run / 'native').glob('*/leaf_decoder.exe')
environment = isolated_environment(cache)
environment.update(LEAF_DECODER_BIN=str(runtime), TEMP=str(scratch), TMP=str(scratch))
models = json.loads((root / 'build/source-bf16-matrices-20261030/models.json').read_text())['models']
cases = {'fp32': 'decoder-32.leaf', 'bf16': 'decoder-32-source-bf16-matrices.leaf'}
if startup_comparison:
    cases = dict.fromkeys(('before', 'after'), cases['bf16'])
first, second = cases
fields = ('external_wall_ms', 'external_first_visible_text_ms', 'time_to_first_token_ms', 'load_ms', 'prefill_p50_ms', 'decode_p50_ms')
for name in ('qwen', 'smol'):
    reference = json.loads((run / f'{name}-storage-comparison.json').read_text())
    assert reference['complete'] and reference['power']['passed']
    snapshot = Path(models[name]['snapshot'])
    tokenizer, _ = encode_prompt(snapshot, 'Leaf', raw=True)
    prompt = tokenizer.decode(reference['prompt_ids'], skip_special_tokens=False)
    assert encode_prompt(snapshot, prompt, raw=True)[1] == reference['prompt_ids']
    expected_text = tokenizer.decode(reference['expected_tokens'], skip_special_tokens=True) + '\n'
    directory = model_directory(snapshot, cache)
    directory.mkdir(parents=True)
    artifact_hashes = {}
    for case, target in cases.items():
        suffix = 'decoder-32.leaf' if case == 'fp32' else 'decoder-32-source-bf16.leaf'
        source, = (Path(path) for path in reference['hashes'] if Path(path).name == suffix)
        artifact_hashes[case] = digest(source)
        assert artifact_hashes[case] == reference['hashes'][str(source)]
        if not (directory / target).exists():
            os.link(source, directory / target)
    out = session / f'{name}.json'
    report = dict(complete=False, snapshot=str(snapshot), runtime_sha256=digest(runtime),
                  artifact_hashes=artifact_hashes, prompt_ids=reference['prompt_ids'],
                  expected_tokens=reference['expected_tokens'], power={}, passes=[], pairs=6,
                  scope='Fresh source CLI processes, cached artifacts, raw prompts, one worker on CPU2 and accurate math',
                  exporter_sha256={case: digest((run / 'source-before' if case == 'before' else root) / 'tools/export_decoder.py')
                                   for case in cases})

    def execute(case, pair):
        metrics_path = session / f'{name}-{case}-{pair}.json'
        args = ['run', str(snapshot), '--offline', '--raw', '--prompt', prompt, '--max-tokens', '8',
                '--threads', '1', '--worker-cpus', '2', '--bits', '32', '--fp32-math', 'accurate',
                '--metrics', str(metrics_path)]
        if case != 'fp32':
            args.append('--source-bf16')
        source_root = run / 'source-before' if case == 'before' else root
        command = [sys.executable, '-I', '-u', '-c', CHILD_PROGRAM,
                   json.dumps(dict(source_root=str(source_root), arguments=args))]
        before = require_benchmark_ac()
        measured = run_process(command, environment, session)
        after = require_benchmark_ac()
        metrics = json.loads(metrics_path.read_text())
        assert measured['stdout'].replace('\r\n', '\n') == expected_text.replace('\r\n', '\n'), repr(measured['stdout'])
        assert measured['package_check']['source_cli'] and not measured['preparation_message_seen']
        assert metrics['generated_tokens'] == report['expected_tokens']
        assert metrics['weight_bits'] == metrics['activation_bits'] == 32 and metrics['fp32_math'] == 'accurate'
        assert metrics['threads'] == 1 and metrics['worker_cpus'] == [2]
        assert (metrics['source_bf16_tensors'] > 0) == (case != 'fp32')
        assert measured['external_first_visible_text_ms'] <= measured['external_wall_ms']
        return dict(pair=pair, case=case, ac_before=before, ac_after=after, metrics=metrics, **measured)

    try:
        with keep_awake(display=True), benchmark_power_mode_guard(report['power'], required_mode='better-battery'):
            for case in cases:
                execute(case, 0)
            for pair in range(1, report['pairs'] + 1):
                for case in ((first, second) if pair % 2 else (second, first)):
                    sample = execute(case, pair)
                    report['passes'].append(sample)
                    write_record(out, report)
                    print(name, pair, case, round(sample['external_first_visible_text_ms'], 2),
                          round(sample['external_wall_ms'], 2), flush=True)
        report['summary'] = {}
        for field in fields:
            values = {case: [sample[field] if field in sample else sample['metrics'][field]
                             for sample in report['passes'] if sample['case'] == case] for case in cases}
            medians = {case: statistics.median(series) for case, series in values.items()}
            stability = {case: latency_stability(series) for case, series in values.items()}
            report['summary'][field] = dict(p50_ms=medians, pooled_ratio=medians[second] / medians[first],
                                            median_paired_ratio=statistics.median(b / a for a, b in zip(values[first], values[second])),
                                            stability=stability, stable=all(row['passed'] for row in stability.values()))
        assert all(digest(directory / filename) == artifact_hashes[case] for case, filename in cases.items())
        report['complete'] = True
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        write_record(out, report)
