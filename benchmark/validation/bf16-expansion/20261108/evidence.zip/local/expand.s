	.file	"bf16_expand_benchmark.cpp"
	.intel_syntax noprefix
	.text
	.section	.text$_ZNKSt5ctypeIcE8do_widenEc,"x"
	.linkonce discard
	.align 2
	.p2align 4
	.globl	_ZNKSt5ctypeIcE8do_widenEc
	.def	_ZNKSt5ctypeIcE8do_widenEc;	.scl	2;	.type	32;	.endef
	.seh_proc	_ZNKSt5ctypeIcE8do_widenEc
_ZNKSt5ctypeIcE8do_widenEc:
.LFB9728:
	.seh_endprologue
	mov	eax, edx
	ret
	.seh_endproc
	.text
	.p2align 4
	.def	_ZL8baselinePKtPfy;	.scl	3;	.type	32;	.endef
	.seh_proc	_ZL8baselinePKtPfy
_ZL8baselinePKtPfy:
.LFB10729:
	.seh_endprologue
	test	r8, r8
	je	.L3
	lea	rax, -1[r8]
	cmp	rax, 6
	jbe	.L10
	mov	r9, r8
	xor	eax, eax
	pxor	xmm2, xmm2
	shr	r9, 3
	sal	r9, 4
	.p2align 6
	.p2align 4
	.p2align 3
.L6:
	movdqu	xmm0, XMMWORD PTR [rcx+rax]
	movdqa	xmm1, xmm0
	punpckhwd	xmm0, xmm2
	punpcklwd	xmm1, xmm2
	pslld	xmm0, 16
	pslld	xmm1, 16
	movups	XMMWORD PTR 16[rdx+rax*2], xmm0
	movups	XMMWORD PTR [rdx+rax*2], xmm1
	add	rax, 16
	cmp	r9, rax
	jne	.L6
	test	r8b, 7
	je	.L3
	mov	rax, r8
	and	rax, -8
.L5:
	mov	r9, r8
	sub	r9, rax
	lea	r10, -1[r9]
	cmp	r10, 2
	jbe	.L8
	movq	xmm0, QWORD PTR [rcx+rax*2]
	pxor	xmm2, xmm2
	movdqa	xmm1, xmm0
	punpcklwd	xmm0, xmm2
	punpcklwd	xmm1, xmm2
	pshufd	xmm0, xmm0, 78
	pslld	xmm1, 16
	pslld	xmm0, 16
	movlps	QWORD PTR [rdx+rax*4], xmm1
	movlps	QWORD PTR 8[rdx+rax*4], xmm0
	test	r9b, 3
	je	.L3
	and	r9, -4
	add	rax, r9
.L8:
	movzx	r9d, WORD PTR [rcx+rax*2]
	sal	r9d, 16
	mov	DWORD PTR [rdx+rax*4], r9d
	lea	r9, 1[rax]
	cmp	r9, r8
	jnb	.L3
	movzx	r9d, WORD PTR 2[rcx+rax*2]
	sal	r9d, 16
	mov	DWORD PTR 4[rdx+rax*4], r9d
	lea	r9, 2[rax]
	cmp	r9, r8
	jnb	.L3
	movzx	ecx, WORD PTR 4[rcx+rax*2]
	sal	ecx, 16
	mov	DWORD PTR 8[rdx+rax*4], ecx
.L3:
	ret
.L10:
	xor	eax, eax
	jmp	.L5
	.seh_endproc
	.p2align 4
	.def	_ZL13vector_expandPKtPfy;	.scl	3;	.type	32;	.endef
	.seh_proc	_ZL13vector_expandPKtPfy
_ZL13vector_expandPKtPfy:
.LFB10730:
	push	rsi
	.seh_pushreg	rsi
	push	rbx
	.seh_pushreg	rbx
	.seh_endprologue
	cmp	r8, 7
	jbe	.L46
	lea	r10, -8[r8]
	mov	rax, r10
	shr	rax, 3
	lea	r9, 8[0+rax*8]
	xor	eax, eax
	.p2align 5
	.p2align 4
	.p2align 3
.L25:
	vpmovzxwd	ymm0, XMMWORD PTR [rcx+rax*2]
	vpslld	ymm0, ymm0, 16
	vmovups	YMMWORD PTR [rdx+rax*4], ymm0
	add	rax, 8
	cmp	rax, r9
	jne	.L25
	and	r10, -8
	add	r10, 8
	cmp	r10, r8
	jnb	.L43
	mov	rbx, r8
	sub	rbx, r10
	lea	rax, -1[rbx]
	cmp	rax, 14
	jbe	.L31
	mov	r11, rbx
	lea	rsi, [rcx+r10*2]
	lea	r9, [rdx+r10*4]
	xor	eax, eax
	shr	r11, 4
	sal	r11, 5
	.p2align 6
	.p2align 4
	.p2align 3
.L27:
	vmovdqu	ymm0, YMMWORD PTR [rsi+rax]
	vpmovzxwd	ymm1, xmm0
	vextracti128	xmm0, ymm0, 0x1
	vpmovzxwd	ymm0, xmm0
	vpslld	ymm1, ymm1, 16
	vpslld	ymm0, ymm0, 16
	vmovups	YMMWORD PTR [r9+rax*2], ymm1
	vmovups	YMMWORD PTR 32[r9+rax*2], ymm0
	add	rax, 32
	cmp	r11, rax
	jne	.L27
	test	bl, 15
	je	.L43
	mov	r9, rbx
	and	r9, -16
	lea	rax, [r9+r10]
.L26:
	sub	rbx, r9
	lea	r11, -1[rbx]
	cmp	r11, 6
	jbe	.L42
	add	r9, r10
	vmovdqu	xmm0, XMMWORD PTR [rcx+r9*2]
	vpmovzxwd	xmm1, xmm0
	vpsrldq	xmm0, xmm0, 8
	vpmovzxwd	xmm0, xmm0
	vpslld	xmm1, xmm1, 16
	vpslld	xmm0, xmm0, 16
	vmovups	XMMWORD PTR [rdx+r9*4], xmm1
	vmovups	XMMWORD PTR 16[rdx+r9*4], xmm0
	test	bl, 7
	je	.L43
	and	rbx, -8
	add	rax, rbx
	vzeroupper
.L23:
	movzx	r9d, WORD PTR [rcx+rax*2]
	sal	r9d, 16
	mov	DWORD PTR [rdx+rax*4], r9d
	lea	r9, 1[rax]
	cmp	r9, r8
	jnb	.L44
	movzx	r9d, WORD PTR 2[rcx+rax*2]
	sal	r9d, 16
	mov	DWORD PTR 4[rdx+rax*4], r9d
	lea	r9, 2[rax]
	cmp	r9, r8
	jnb	.L44
	movzx	r9d, WORD PTR 4[rcx+rax*2]
	sal	r9d, 16
	mov	DWORD PTR 8[rdx+rax*4], r9d
	lea	r9, 3[rax]
	cmp	r9, r8
	jnb	.L44
	movzx	r9d, WORD PTR 6[rcx+rax*2]
	sal	r9d, 16
	mov	DWORD PTR 12[rdx+rax*4], r9d
	lea	r9, 4[rax]
	cmp	r9, r8
	jnb	.L44
	movzx	r9d, WORD PTR 8[rcx+rax*2]
	sal	r9d, 16
	mov	DWORD PTR 16[rdx+rax*4], r9d
	lea	r9, 5[rax]
	cmp	r9, r8
	jnb	.L44
	movzx	r9d, WORD PTR 10[rcx+rax*2]
	sal	r9d, 16
	mov	DWORD PTR 20[rdx+rax*4], r9d
	lea	r9, 6[rax]
	cmp	r9, r8
	jnb	.L44
	movzx	ecx, WORD PTR 12[rcx+rax*2]
	sal	ecx, 16
	mov	DWORD PTR 24[rdx+rax*4], ecx
.L44:
	pop	rbx
	pop	rsi
	ret
	.p2align 4,,10
	.p2align 3
.L43:
	vzeroupper
	pop	rbx
	pop	rsi
	ret
	.p2align 4,,10
	.p2align 3
.L46:
	xor	eax, eax
	test	r8, r8
	jne	.L23
	jmp	.L44
.L31:
	mov	rax, r10
	xor	r9d, r9d
	jmp	.L26
.L42:
	vzeroupper
	jmp	.L23
	.seh_endproc
	.section .rdata,"dr"
	.align 8
.LC0:
	.ascii "basic_string: construction from null is not valid\0"
	.text
	.align 2
	.p2align 4
	.def	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1IS3_EEPKcRKS3_.isra.0;	.scl	3;	.type	32;	.endef
	.seh_proc	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1IS3_EEPKcRKS3_.isra.0
_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1IS3_EEPKcRKS3_.isra.0:
.LFB11793:
	push	rdi
	.seh_pushreg	rdi
	push	rsi
	.seh_pushreg	rsi
	push	rbx
	.seh_pushreg	rbx
	sub	rsp, 64
	.seh_stackalloc	64
	.seh_endprologue
	lea	rdi, 16[rcx]
	mov	rbx, rcx
	mov	rsi, rdx
	mov	QWORD PTR [rcx], rdi
	test	rdx, rdx
	je	.L56
	mov	rcx, rdx
	call	strlen
	mov	QWORD PTR 56[rsp], rax
	mov	r9, rax
	cmp	rax, 15
	ja	.L57
	cmp	rax, 1
	jne	.L51
	movzx	eax, BYTE PTR [rsi]
	mov	BYTE PTR 16[rbx], al
.L52:
	mov	rax, QWORD PTR 56[rsp]
	mov	rdx, QWORD PTR [rbx]
	mov	QWORD PTR 8[rbx], rax
	mov	BYTE PTR [rdx+rax], 0
	add	rsp, 64
	pop	rbx
	pop	rsi
	pop	rdi
	ret
.L51:
	test	rax, rax
	je	.L52
	jmp	.L50
.L57:
	lea	rdx, 56[rsp]
	xor	r8d, r8d
	mov	rcx, rbx
	mov	QWORD PTR 40[rsp], rax
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERyy
	mov	r9, QWORD PTR 40[rsp]
	mov	QWORD PTR [rbx], rax
	mov	rdi, rax
	mov	rax, QWORD PTR 56[rsp]
	mov	QWORD PTR 16[rbx], rax
.L50:
	mov	r8, r9
	mov	rdx, rsi
	mov	rcx, rdi
	call	memcpy
	jmp	.L52
.L56:
	lea	rcx, .LC0[rip]
	call	_ZSt19__throw_logic_errorPKc
	nop
	.seh_endproc
	.p2align 4
	.def	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_.isra.0;	.scl	3;	.type	32;	.endef
	.seh_proc	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_.isra.0
_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_.isra.0:
.LFB11795:
	push	rbx
	.seh_pushreg	rbx
	sub	rsp, 48
	.seh_stackalloc	48
	.seh_endprologue
	mov	rax, QWORD PTR [rcx]
	mov	rax, QWORD PTR -24[rax]
	mov	rbx, rcx
	mov	rcx, QWORD PTR 240[rcx+rax]
	test	rcx, rcx
	je	.L63
	cmp	BYTE PTR 56[rcx], 0
	je	.L60
	movsx	edx, BYTE PTR 67[rcx]
.L61:
	mov	rcx, rbx
	call	_ZNSo3putEc
	mov	rcx, rax
	add	rsp, 48
	pop	rbx
	jmp	_ZNSo5flushEv
.L60:
	mov	QWORD PTR 40[rsp], rcx
	call	_ZNKSt5ctypeIcE13_M_widen_initEv
	mov	rcx, QWORD PTR 40[rsp]
	mov	edx, 10
	lea	r8, _ZNKSt5ctypeIcE8do_widenEc[rip]
	mov	rax, QWORD PTR [rcx]
	mov	rax, QWORD PTR 48[rax]
	cmp	rax, r8
	je	.L61
	mov	edx, 10
	call	rax
	movsx	edx, al
	jmp	.L61
.L63:
	call	_ZSt16__throw_bad_castv
	nop
	.seh_endproc
	.section .rdata,"dr"
.LC1:
	.ascii "\0"
.LC2:
	.ascii ",\0"
	.text
	.p2align 4
	.def	_ZL5arrayRSoRKSt6vectorIdSaIdEE;	.scl	3;	.type	32;	.endef
	.seh_proc	_ZL5arrayRSoRKSt6vectorIdSaIdEE
_ZL5arrayRSoRKSt6vectorIdSaIdEE:
.LFB10741:
	push	rbp
	.seh_pushreg	rbp
	push	rdi
	.seh_pushreg	rdi
	push	rsi
	.seh_pushreg	rsi
	push	rbx
	.seh_pushreg	rbx
	sub	rsp, 56
	.seh_stackalloc	56
	.seh_endprologue
	mov	rax, QWORD PTR [rcx]
	mov	BYTE PTR 47[rsp], 91
	mov	rax, QWORD PTR -24[rax]
	mov	rdi, rcx
	mov	rsi, rdx
	cmp	QWORD PTR 16[rcx+rax], 0
	je	.L65
	lea	rdx, 47[rsp]
	mov	r8d, 1
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
.L66:
	mov	rax, QWORD PTR 8[rsi]
	cmp	QWORD PTR [rsi], rax
	je	.L67
	xor	ebx, ebx
	xor	r8d, r8d
	lea	rdx, .LC1[rip]
	lea	rbp, .LC2[rip]
	.p2align 4
	.p2align 3
.L68:
	mov	rcx, rdi
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rax, QWORD PTR [rsi]
	mov	rcx, rdi
	movsd	xmm1, QWORD PTR [rax+rbx*8]
	add	rbx, 1
	call	_ZNSo9_M_insertIdEERSoT_
	mov	rax, QWORD PTR 8[rsi]
	sub	rax, QWORD PTR [rsi]
	mov	rdx, rbp
	sar	rax, 3
	mov	r8d, 1
	cmp	rbx, rax
	jb	.L68
.L67:
	mov	rax, QWORD PTR [rdi]
	mov	BYTE PTR 47[rsp], 93
	mov	rax, QWORD PTR -24[rax]
	cmp	QWORD PTR 16[rdi+rax], 0
	je	.L69
	lea	rdx, 47[rsp]
	mov	r8d, 1
	mov	rcx, rdi
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	nop
	add	rsp, 56
	pop	rbx
	pop	rsi
	pop	rdi
	pop	rbp
	ret
	.p2align 4,,10
	.p2align 3
.L65:
	mov	edx, 91
	call	_ZNSo3putEc
	jmp	.L66
	.p2align 4,,10
	.p2align 3
.L69:
	mov	edx, 93
	mov	rcx, rdi
	call	_ZNSo3putEc
	nop
	add	rsp, 56
	pop	rbx
	pop	rsi
	pop	rdi
	pop	rbp
	ret
	.seh_endproc
	.section .rdata,"dr"
	.align 8
.LC10:
	.ascii "Expansion changed source words\0"
	.align 8
.LC11:
	.ascii "Expansion changed bits, tail or output guard\0"
	.text
	.p2align 4
	.def	_ZL11verify_caseyyy;	.scl	3;	.type	32;	.endef
	.seh_proc	_ZL11verify_caseyyy
_ZL11verify_caseyyy:
.LFB10739:
	push	r15
	.seh_pushreg	r15
	push	r14
	.seh_pushreg	r14
	push	r13
	.seh_pushreg	r13
	push	r12
	.seh_pushreg	r12
	push	rbp
	.seh_pushreg	rbp
	push	rdi
	.seh_pushreg	rdi
	push	rsi
	.seh_pushreg	rsi
	push	rbx
	.seh_pushreg	rbx
	sub	rsp, 168
	.seh_stackalloc	168
	movups	XMMWORD PTR 128[rsp], xmm6
	.seh_savexmm	xmm6, 128
	movups	XMMWORD PTR 144[rsp], xmm7
	.seh_savexmm	xmm7, 144
	.seh_endprologue
	lea	rax, 24[rdx+rcx]
	mov	rbp, rcx
	lea	rdi, 8[rdx]
	mov	QWORD PTR 248[rsp], rdx
	lea	rsi, [rax+rax]
	mov	QWORD PTR 256[rsp], r8
	mov	rcx, rsi
	mov	QWORD PTR 112[rsp], rsi
.LEHB0:
	call	_Znwy
.LEHE0:
	mov	r8, rsi
	mov	edx, 90
	mov	r12, rax
	mov	rcx, rax
	call	memset
	lea	r14, [r12+rsi]
	test	rbp, rbp
	je	.L79
	lea	rax, -1[rbp]
	cmp	rax, 6
	jbe	.L97
	mov	esi, 2
	mov	rdx, rbp
	lea	rax, [r12+rdi*2]
	mov	ebx, 6
	movq	xmm7, rsi
	mov	esi, 4
	shr	rdx, 3
	movq	xmm5, rbx
	movq	xmm6, rsi
	sal	rdx, 4
	punpcklqdq	xmm7, xmm7
	punpcklqdq	xmm5, xmm5
	mov	esi, 8
	movdqu	xmm1, XMMWORD PTR .LC3[rip]
	add	rdx, rax
	punpcklqdq	xmm6, xmm6
	movq	xmm4, rsi
	punpcklqdq	xmm4, xmm4
	.p2align 4
	.p2align 3
.L77:
	movdqa	xmm2, xmm1
	movdqa	xmm0, xmm1
	movdqa	xmm3, xmm1
	add	rax, 16
	paddq	xmm2, xmm7
	paddq	xmm3, xmm5
	shufps	xmm0, xmm2, 136
	movdqa	xmm2, xmm1
	paddq	xmm1, xmm4
	paddq	xmm2, xmm6
	shufps	xmm2, xmm3, 136
	movdqa	xmm3, xmm0
	punpcklwd	xmm0, xmm2
	punpckhwd	xmm3, xmm2
	movdqa	xmm2, xmm0
	punpckhwd	xmm2, xmm3
	punpcklwd	xmm0, xmm3
	punpcklwd	xmm0, xmm2
	movups	XMMWORD PTR -16[rax], xmm0
	cmp	rdx, rax
	jne	.L77
	test	bpl, 7
	je	.L79
	mov	rax, rbp
	and	rax, -8
.L76:
	lea	rdx, [rdi+rax]
	mov	WORD PTR [r12+rdx*2], ax
	lea	rdx, 1[rax]
	cmp	rdx, rbp
	jnb	.L79
	lea	rcx, [rdi+rdx]
	mov	WORD PTR [r12+rcx*2], dx
	lea	rdx, 2[rax]
	cmp	rdx, rbp
	jnb	.L79
	lea	rcx, [rdi+rdx]
	mov	WORD PTR [r12+rcx*2], dx
	lea	rdx, 3[rax]
	cmp	rdx, rbp
	jnb	.L79
	lea	rcx, [rdi+rdx]
	mov	WORD PTR [r12+rcx*2], dx
	lea	rdx, 4[rax]
	cmp	rdx, rbp
	jnb	.L79
	lea	rcx, [rdi+rdx]
	mov	WORD PTR [r12+rcx*2], dx
	lea	rdx, 5[rax]
	cmp	rdx, rbp
	jnb	.L79
	lea	rcx, [rdi+rdx]
	add	rax, 6
	mov	WORD PTR [r12+rcx*2], dx
	cmp	rax, rbp
	jnb	.L79
	lea	rdx, [rdi+rax]
	mov	WORD PTR [r12+rdx*2], ax
.L79:
	sub	r14, r12
	je	.L137
	mov	rcx, r14
	mov	QWORD PTR 120[rsp], r14
.LEHB1:
	call	_Znwy
.LEHE1:
	mov	r8, r14
	mov	rdx, r12
	mov	rcx, rax
	mov	QWORD PTR 104[rsp], rax
	call	memcpy
	mov	QWORD PTR 64[rsp], r14
.L75:
	mov	rax, QWORD PTR 256[rsp]
	lea	rsi, 8[rax]
	lea	r15, [rsi+rbp]
	lea	r13, 64[0+r15*4]
	mov	rcx, r13
.LEHB2:
	call	_Znwy
.LEHE2:
	mov	rbx, rax
	lea	r8, -4[r13]
	lea	rax, [rax+r13]
	xor	edx, edx
	mov	DWORD PTR [rbx], 0x00000000
	lea	rcx, 4[rbx]
	mov	QWORD PTR 88[rsp], rax
	call	memset
	mov	rcx, r13
	lea	rax, [rbx+rsi*4]
	lea	r10, C.25.3[rip]
	shr	rcx, 4
	mov	QWORD PTR 48[rsp], rax
	lea	rax, [r12+rdi*2]
	mov	rdi, r13
	mov	QWORD PTR 72[rsp], rcx
	mov	rcx, r13
	sar	rdi, 2
	and	rcx, -16
	mov	QWORD PTR 56[rsp], rax
	mov	rax, r13
	shr	rax, 2
	mov	QWORD PTR 96[rsp], rcx
	lea	r11, [rbx+rcx]
	mov	ecx, 2143363909
	mov	QWORD PTR 80[rsp], rax
	movd	xmm6, ecx
	lea	rax, _ZL8baselinePKtPfy[rip]
	pshufd	xmm6, xmm6, 0
.L81:
	mov	rcx, r11
	mov	rdx, rbx
	sub	rcx, rbx
	and	ecx, 16
	je	.L82
	lea	rdx, 16[rbx]
	movups	XMMWORD PTR [rbx], xmm6
	cmp	r11, rdx
	je	.L134
	.p2align 4
	.p2align 4
	.p2align 3
.L82:
	movups	XMMWORD PTR [rdx], xmm6
	add	rdx, 32
	movups	XMMWORD PTR -16[rdx], xmm6
	cmp	r11, rdx
	jne	.L82
.L134:
	mov	rcx, QWORD PTR 72[rsp]
	lea	rdx, 0[0+rcx*4]
	cmp	rdx, QWORD PTR 80[rsp]
	je	.L83
	mov	rcx, QWORD PTR 96[rsp]
	mov	r9, QWORD PTR 88[rsp]
	lea	rdx, [rbx+rcx]
	lea	rcx, 4[rdx]
	mov	DWORD PTR [rdx], 2143363909
	cmp	r9, rcx
	je	.L83
	lea	rcx, 8[rdx]
	mov	DWORD PTR 4[rdx], 2143363909
	cmp	r9, rcx
	je	.L83
	mov	DWORD PTR 8[rdx], 2143363909
.L83:
	mov	QWORD PTR 40[rsp], r10
	mov	rdx, QWORD PTR 48[rsp]
	mov	r8, rbp
	mov	QWORD PTR 32[rsp], r11
	mov	rcx, QWORD PTR 56[rsp]
.LEHB3:
	call	rax
.LEHE3:
	cmp	r14, QWORD PTR 64[rsp]
	mov	r11, QWORD PTR 32[rsp]
	mov	r10, QWORD PTR 40[rsp]
	je	.L138
.L84:
	mov	ecx, 16
	call	__cxa_allocate_exception
	lea	rdx, .LC10[rip]
	mov	rcx, rax
	mov	rdi, rax
.LEHB4:
	call	_ZNSt13runtime_errorC1EPKc
.LEHE4:
	lea	r8, _ZNSt13runtime_errorD1Ev[rip]
	lea	rdx, _ZTISt13runtime_error[rip]
	mov	rcx, rdi
.LEHB5:
	call	__cxa_throw
.LEHE5:
	.p2align 4,,10
	.p2align 3
.L138:
	test	r14, r14
	jne	.L139
.L85:
	mov	rax, QWORD PTR 248[rsp]
	sub	rax, QWORD PTR 256[rsp]
	lea	rcx, [r12+rax*2]
	xor	eax, eax
	jmp	.L88
	.p2align 4,,10
	.p2align 3
.L98:
	mov	edx, 2143363909
.L86:
	cmp	edx, DWORD PTR [rbx+rax*4]
	jne	.L140
	add	rax, 1
	cmp	rax, rdi
	jnb	.L141
.L88:
	cmp	rax, rsi
	jb	.L98
	cmp	rax, r15
	jnb	.L98
	movzx	edx, WORD PTR [rcx+rax*2]
	sal	edx, 16
	jmp	.L86
	.p2align 4,,10
	.p2align 3
.L141:
	add	r10, 8
	lea	rax, C.25.3[rip+16]
	cmp	rax, r10
	je	.L142
	mov	rax, QWORD PTR [r10]
	jmp	.L81
	.p2align 4,,10
	.p2align 3
.L142:
	mov	rdx, r13
	mov	rcx, rbx
	add	rbp, rbp
	call	_ZdlPvy
	mov	rax, QWORD PTR 104[rsp]
	test	rax, rax
	je	.L90
	mov	rdx, QWORD PTR 120[rsp]
	mov	rcx, rax
	call	_ZdlPvy
.L90:
	mov	rdx, QWORD PTR 112[rsp]
	mov	rcx, r12
	call	_ZdlPvy
	nop
	movups	xmm6, XMMWORD PTR 128[rsp]
	movups	xmm7, XMMWORD PTR 144[rsp]
	mov	rax, rbp
	add	rsp, 168
	pop	rbx
	pop	rsi
	pop	rdi
	pop	rbp
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	ret
	.p2align 4,,10
	.p2align 3
.L139:
	mov	r8, QWORD PTR 120[rsp]
	mov	rdx, QWORD PTR 104[rsp]
	mov	rcx, r12
	call	memcmp
	mov	r11, QWORD PTR 32[rsp]
	mov	r10, QWORD PTR 40[rsp]
	test	eax, eax
	je	.L85
	jmp	.L84
	.p2align 4,,10
	.p2align 3
.L137:
	mov	QWORD PTR 64[rsp], 0
	mov	QWORD PTR 120[rsp], 0
	mov	QWORD PTR 104[rsp], 0
	jmp	.L75
.L97:
	xor	eax, eax
	jmp	.L76
.L100:
	mov	rbx, rax
.L94:
	cmp	QWORD PTR 104[rsp], 0
	je	.L96
	mov	rdx, QWORD PTR 120[rsp]
	mov	rcx, QWORD PTR 104[rsp]
	call	_ZdlPvy
.L96:
	mov	rdx, QWORD PTR 112[rsp]
	mov	rcx, r12
	call	_ZdlPvy
	mov	rcx, rbx
.LEHB6:
	call	_Unwind_Resume
.LEHE6:
.L140:
	mov	ecx, 16
	call	__cxa_allocate_exception
	lea	rdx, .LC11[rip]
	mov	rcx, rax
	mov	rdi, rax
.LEHB7:
	call	_ZNSt13runtime_errorC1EPKc
.LEHE7:
	lea	r8, _ZNSt13runtime_errorD1Ev[rip]
	lea	rdx, _ZTISt13runtime_error[rip]
	mov	rcx, rdi
.LEHB8:
	call	__cxa_throw
.LEHE8:
.L99:
	mov	rbx, rax
	jmp	.L96
.L102:
.L136:
	mov	rcx, rdi
	mov	rsi, rax
	call	__cxa_free_exception
.L92:
	mov	rcx, rbx
	mov	rdx, r13
	mov	rbx, rsi
	call	_ZdlPvy
	jmp	.L94
.L101:
	mov	rsi, rax
	jmp	.L92
.L103:
	jmp	.L136
	.seh_handler	__gxx_personality_seh0, @unwind, @except
	.seh_handlerdata
.LLSDA10739:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10739-.LLSDACSB10739
.LLSDACSB10739:
	.uleb128 .LEHB0-.LFB10739
	.uleb128 .LEHE0-.LEHB0
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB1-.LFB10739
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L99-.LFB10739
	.uleb128 0
	.uleb128 .LEHB2-.LFB10739
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L100-.LFB10739
	.uleb128 0
	.uleb128 .LEHB3-.LFB10739
	.uleb128 .LEHE3-.LEHB3
	.uleb128 .L101-.LFB10739
	.uleb128 0
	.uleb128 .LEHB4-.LFB10739
	.uleb128 .LEHE4-.LEHB4
	.uleb128 .L102-.LFB10739
	.uleb128 0
	.uleb128 .LEHB5-.LFB10739
	.uleb128 .LEHE5-.LEHB5
	.uleb128 .L101-.LFB10739
	.uleb128 0
	.uleb128 .LEHB6-.LFB10739
	.uleb128 .LEHE6-.LEHB6
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB7-.LFB10739
	.uleb128 .LEHE7-.LEHB7
	.uleb128 .L103-.LFB10739
	.uleb128 0
	.uleb128 .LEHB8-.LFB10739
	.uleb128 .LEHE8-.LEHB8
	.uleb128 .L101-.LFB10739
	.uleb128 0
.LLSDACSE10739:
	.text
	.seh_endproc
	.section .rdata,"dr"
	.align 8
.LC12:
	.ascii "cannot create std::vector larger than max_size()\0"
.LC14:
	.ascii "vector::_M_realloc_append\0"
.LC15:
	.ascii "Timed source changed\0"
.LC16:
	.ascii "Timed output/guard mismatch\0"
	.align 8
.LC17:
	.ascii "{\"type\":\"case\",\"complete\":true,\"rows\":\0"
.LC18:
	.ascii ",\"columns\":\0"
.LC19:
	.ascii ",\"values\":\0"
.LC20:
	.ascii ",\"source_bytes\":\0"
.LC21:
	.ascii ",\"output_bytes\":\0"
.LC22:
	.ascii ",\"rounds\":\0"
.LC23:
	.ascii ",\"warmup_pairs\":\0"
.LC24:
	.ascii ",\"repeats_per_sample\":\0"
	.align 8
.LC25:
	.ascii ",\"cache_policy\":\"same_reused_buffers\",\"source_mod64\":\0"
.LC26:
	.ascii ",\"output_mod64\":\0"
	.align 8
.LC27:
	.ascii ",\"baseline\":\"current_expand_source_bf16_baseline_ISA\",\"candidate\":\"local_AVX2_load8_storeu\"\0"
	.align 8
.LC28:
	.ascii ",\"source_immutable\":true,\"bits_and_guards_exact\":true,\"sample_order\":[\0"
.LC29:
	.ascii "],\"before_total_ns\":\0"
.LC30:
	.ascii ",\"after_total_ns\":\0"
.LC31:
	.ascii ",\"before_ms_per_expansion\":\0"
.LC33:
	.ascii ",\"after_ms_per_expansion\":\0"
.LC34:
	.ascii "}\0"
.LC35:
	.ascii " values complete\12\0"
	.text
	.p2align 4
	.def	_ZL8run_caseRSoyyjj;	.scl	3;	.type	32;	.endef
	.seh_proc	_ZL8run_caseRSoyyjj
_ZL8run_caseRSoyyjj:
.LFB10742:
	push	r15
	.seh_pushreg	r15
	push	r14
	.seh_pushreg	r14
	push	r13
	.seh_pushreg	r13
	push	r12
	.seh_pushreg	r12
	push	rbp
	.seh_pushreg	rbp
	push	rdi
	.seh_pushreg	rdi
	push	rsi
	.seh_pushreg	rsi
	push	rbx
	.seh_pushreg	rbx
	sub	rsp, 328
	.seh_stackalloc	328
	movups	XMMWORD PTR 272[rsp], xmm6
	.seh_savexmm	xmm6, 272
	movups	XMMWORD PTR 288[rsp], xmm7
	.seh_savexmm	xmm7, 288
	movups	XMMWORD PTR 304[rsp], xmm8
	.seh_savexmm	xmm8, 304
	.seh_endprologue
	mov	eax, DWORD PTR 432[rsp]
	mov	r14, rdx
	mov	DWORD PTR 144[rsp], eax
	imul	r14, r8
	mov	QWORD PTR 112[rsp], rcx
	mov	QWORD PTR 176[rsp], rdx
	mov	QWORD PTR 184[rsp], r8
	lea	rbx, 16[r14]
	mov	DWORD PTR 148[rsp], r9d
	mov	rax, rbx
	shr	rax, 62
	jne	.L290
	lea	rsi, [rbx+rbx]
	mov	rcx, rsi
	mov	QWORD PTR 160[rsp], rsi
.LEHB9:
	call	_Znwy
.LEHE9:
	xor	r8d, r8d
	xor	edx, edx
	mov	WORD PTR [rax], r8w
	lea	rdi, 2[rax]
	lea	r8, -2[rsi]
	mov	r15, rax
	mov	rcx, rdi
	mov	QWORD PTR 152[rsp], rax
	call	memset
	mov	rcx, rsi
	and	rsi, -16
	pcmpeqd	xmm5, xmm5
	lea	rdx, [r15+rsi]
	mov	esi, 2
	mov	rax, r15
	sar	rcx
	movq	xmm8, rsi
	psrlw	xmm5, 13
	mov	esi, 4
	movdqu	xmm2, XMMWORD PTR .LC3[rip]
	movq	xmm7, rsi
	mov	esi, 6
	punpcklqdq	xmm8, xmm8
	movq	xmm6, rsi
	mov	esi, 8
	punpcklqdq	xmm7, xmm7
	movq	xmm4, rsi
	punpcklqdq	xmm6, xmm6
	punpcklqdq	xmm4, xmm4
	.p2align 4
	.p2align 3
.L145:
	movdqa	xmm1, xmm2
	movdqa	xmm0, xmm2
	movdqa	xmm3, xmm2
	add	rax, 16
	paddq	xmm1, xmm8
	paddq	xmm3, xmm6
	shufps	xmm0, xmm1, 136
	movdqa	xmm1, xmm2
	paddq	xmm2, xmm4
	paddq	xmm1, xmm7
	shufps	xmm1, xmm3, 136
	movdqa	xmm3, xmm0
	punpcklwd	xmm0, xmm1
	punpckhwd	xmm3, xmm1
	movdqa	xmm1, xmm0
	punpckhwd	xmm1, xmm3
	punpcklwd	xmm0, xmm3
	punpcklwd	xmm0, xmm1
	movdqa	xmm1, xmm0
	psllw	xmm1, 3
	psubw	xmm1, xmm0
	psllw	xmm1, 4
	paddw	xmm0, xmm1
	paddw	xmm0, xmm5
	movups	XMMWORD PTR -16[rax], xmm0
	cmp	rdx, rax
	jne	.L145
	mov	rax, rcx
	and	rax, -8
	test	cl, 7
	je	.L147
	imul	edx, eax, 113
	mov	rsi, QWORD PTR 152[rsp]
	add	edx, 7
	mov	WORD PTR [rsi+rax*2], dx
	lea	rdx, 1[rax]
	cmp	rdx, rcx
	jnb	.L147
	imul	edx, edx, 113
	add	edx, 7
	mov	WORD PTR 2[rsi+rax*2], dx
	lea	rdx, 2[rax]
	cmp	rdx, rcx
	jnb	.L147
	imul	edx, edx, 113
	add	edx, 7
	mov	WORD PTR 4[rsi+rax*2], dx
	lea	rdx, 3[rax]
	cmp	rdx, rcx
	jnb	.L147
	imul	edx, edx, 113
	add	edx, 7
	mov	WORD PTR 6[rsi+rax*2], dx
	lea	rdx, 4[rax]
	cmp	rdx, rcx
	jnb	.L147
	imul	edx, edx, 113
	add	edx, 7
	mov	WORD PTR 8[rsi+rax*2], dx
	lea	rdx, 5[rax]
	cmp	rdx, rcx
	jnb	.L147
	imul	edx, edx, 113
	add	edx, 7
	mov	WORD PTR 10[rsi+rax*2], dx
	lea	rdx, 6[rax]
	cmp	rdx, rcx
	jnb	.L147
	imul	edx, edx, 113
	add	edx, 7
	mov	WORD PTR 12[rsi+rax*2], dx
.L147:
	mov	rsi, QWORD PTR 160[rsp]
	mov	rcx, rsi
.LEHB10:
	call	_Znwy
.LEHE10:
	mov	rdx, QWORD PTR 152[rsp]
	mov	r8, rsi
	mov	rcx, rax
	lea	rsi, [rax+rsi]
	mov	QWORD PTR 192[rsp], rax
	mov	QWORD PTR 208[rsp], rsi
	call	memcpy
	mov	rax, rbx
	mov	QWORD PTR 200[rsp], rsi
	shr	rax, 61
	jne	.L291
	lea	rsi, 0[0+rbx*4]
	mov	rcx, rsi
	mov	QWORD PTR 168[rsp], rsi
.LEHB11:
	call	_Znwy
.LEHE11:
	mov	DWORD PTR [rax], 0x00000000
	xor	edx, edx
	lea	rcx, 4[rax]
	lea	r8, -4[rsi]
	mov	rbx, rax
	mov	QWORD PTR 64[rsp], rax
	call	memset
	mov	r9, rsi
	mov	rcx, rsi
	and	rsi, -16
	shr	r9, 2
	shr	rcx, 4
	lea	rdx, [rbx+rsi]
	and	esi, 16
	mov	esi, 2143363909
	mov	rax, rbx
	movd	xmm0, esi
	pshufd	xmm0, xmm0, 0
	je	.L150
	mov	rax, QWORD PTR 64[rsp]
	movups	XMMWORD PTR [rax], xmm0
	add	rax, 16
	cmp	rdx, rax
	je	.L287
	.p2align 4
	.p2align 4
	.p2align 3
.L150:
	movups	XMMWORD PTR [rax], xmm0
	add	rax, 32
	movups	XMMWORD PTR -16[rax], xmm0
	cmp	rdx, rax
	jne	.L150
.L287:
	lea	rax, 0[0+rcx*4]
	cmp	r9, rax
	je	.L151
	mov	rsi, QWORD PTR 64[rsp]
	mov	rax, QWORD PTR 168[rsp]
	lea	rdx, [rsi+rax]
	mov	rax, rcx
	sal	rax, 4
	lea	rcx, 4[rsi+rax]
	mov	DWORD PTR [rsi+rax], 2143363909
	cmp	rdx, rcx
	jne	.L292
.L151:
	xor	edx, edx
	mov	eax, 4194304
	mov	rcx, QWORD PTR 64[rsp]
	mov	esi, 1
	div	r14
	lea	rbx, 12[rcx]
	test	rax, rax
	cmovne	rsi, rax
	lea	rax, 8[rcx+r14*4]
	mov	ecx, DWORD PTR 144[rsp]
	mov	QWORD PTR 80[rsp], rax
	test	ecx, ecx
	je	.L157
	mov	r15, rax
	mov	rax, r14
	xor	ebp, ebp
	shr	rax
	lea	r12, [rbx+rax*4]
	mov	rax, rdi
	mov	rdi, rbx
	mov	rbx, rax
	.p2align 4
	.p2align 3
.L156:
	call	_ZNSt6chrono3_V212steady_clock3nowEv
	xor	r13d, r13d
	mov	r8, r14
	.p2align 4
	.p2align 3
.L154:
	mov	rdx, rdi
	mov	rcx, rbx
	call	_ZL8baselinePKtPfy
	add	r13, 1
	cmp	rsi, r13
	jne	.L154
	mov	r14, r8
	xor	r13d, r13d
	call	_ZNSt6chrono3_V212steady_clock3nowEv
	mov	ecx, DWORD PTR [r15]
	mov	eax, DWORD PTR [r12]
	add	rax, rcx
	mov	rcx, QWORD PTR 64[rsp]
	mov	ecx, DWORD PTR 12[rcx]
	add	rax, rcx
	mov	QWORD PTR expand_sink[rip], rax
	call	_ZNSt6chrono3_V212steady_clock3nowEv
	mov	r8, r14
	.p2align 4
	.p2align 3
.L155:
	mov	rdx, rdi
	mov	rcx, rbx
	call	_ZL13vector_expandPKtPfy
	add	r13, 1
	cmp	rsi, r13
	jne	.L155
	mov	r14, r8
	add	ebp, 1
	call	_ZNSt6chrono3_V212steady_clock3nowEv
	mov	ecx, DWORD PTR [r15]
	mov	eax, DWORD PTR [r12]
	add	rax, rcx
	mov	rcx, QWORD PTR 64[rsp]
	mov	ecx, DWORD PTR 12[rcx]
	add	rax, rcx
	mov	QWORD PTR expand_sink[rip], rax
	cmp	DWORD PTR 144[rsp], ebp
	jne	.L156
	mov	rax, rbx
	mov	rbx, rdi
	mov	rdi, rax
.L157:
	mov	rax, r14
	pxor	xmm0, xmm0
	mov	QWORD PTR 72[rsp], 0
	shr	rax
	mov	DWORD PTR 92[rsp], 0
	mov	QWORD PTR 48[rsp], 0
	mov	QWORD PTR 104[rsp], 0
	mov	QWORD PTR 96[rsp], rax
	movups	XMMWORD PTR 224[rsp], xmm0
	movups	XMMWORD PTR 240[rsp], xmm0
	movups	XMMWORD PTR 256[rsp], xmm0
	.p2align 4
	.p2align 3
.L153:
	mov	eax, DWORD PTR 92[rsp]
	and	eax, 1
	mov	DWORD PTR 88[rsp], eax
	lea	rax, C.48.4[rip]
	mov	QWORD PTR 40[rsp], rax
.L171:
	mov	rax, QWORD PTR 40[rsp]
	mov	edx, DWORD PTR 88[rsp]
	lea	rbp, _ZL8baselinePKtPfy[rip]
	mov	r13d, DWORD PTR [rax]
	mov	eax, 1
	sub	eax, r13d
	test	edx, edx
	cmovne	r13d, eax
	lea	rax, _ZL13vector_expandPKtPfy[rip]
	test	r13d, r13d
	cmovne	rbp, rax
	xor	r15d, r15d
	call	_ZNSt6chrono3_V212steady_clock3nowEv
	mov	QWORD PTR 56[rsp], rax
	.p2align 4
	.p2align 3
.L160:
	lea	r12, 224[rsp]
	mov	r8, r14
	mov	rdx, rbx
	mov	rcx, rdi
.LEHB12:
	call	rbp
.LEHE12:
	add	r15, 1
	cmp	rsi, r15
	jne	.L160
	call	_ZNSt6chrono3_V212steady_clock3nowEv
	pxor	xmm6, xmm6
	sub	rax, QWORD PTR 56[rsp]
	mov	ebp, r13d
	mov	rcx, QWORD PTR 80[rsp]
	cvtsi2sd	xmm6, rax
	mov	rax, QWORD PTR 96[rsp]
	lea	r15, [rbp+rbp]
	mov	edx, DWORD PTR [rcx]
	mov	eax, DWORD PTR [rbx+rax*4]
	mov	rcx, QWORD PTR 64[rsp]
	add	rax, rdx
	mov	edx, DWORD PTR 12[rcx]
	add	rax, rdx
	lea	rdx, [r15+rbp]
	mov	QWORD PTR expand_sink[rip], rax
	mov	r9, QWORD PTR 240[rsp+rdx*8]
	mov	rax, QWORD PTR 232[rsp+rdx*8]
	cmp	rax, r9
	je	.L161
	movsd	QWORD PTR [rax], xmm6
	add	rax, 8
	mov	QWORD PTR 232[rsp+rdx*8], rax
.L162:
	mov	rax, QWORD PTR 48[rsp]
	cmp	rax, QWORD PTR 72[rsp]
	je	.L166
	mov	DWORD PTR [rax], r13d
	add	rax, 4
	mov	QWORD PTR 48[rsp], rax
.L167:
	add	QWORD PTR 40[rsp], 4
	lea	rdx, C.48.4[rip+16]
	cmp	QWORD PTR 40[rsp], rdx
	jne	.L171
	add	DWORD PTR 92[rsp], 1
	mov	eax, DWORD PTR 92[rsp]
	cmp	DWORD PTR 148[rsp], eax
	jne	.L153
	mov	rbp, QWORD PTR 192[rsp]
	mov	rax, QWORD PTR 200[rsp]
	sub	rax, rbp
	cmp	QWORD PTR 160[rsp], rax
	je	.L293
.L174:
	mov	ecx, 16
	call	__cxa_allocate_exception
	lea	rdx, .LC15[rip]
	mov	rcx, rax
	mov	rsi, rax
.LEHB13:
	call	_ZNSt13runtime_errorC1EPKc
.LEHE13:
	lea	r8, _ZNSt13runtime_errorD1Ev[rip]
	lea	rdx, _ZTISt13runtime_error[rip]
	mov	rcx, rsi
	lea	r12, 224[rsp]
.LEHB14:
	call	__cxa_throw
	.p2align 4,,10
	.p2align 3
.L166:
	movabs	rdx, 2305843009213693951
	mov	r15, QWORD PTR 72[rsp]
	sub	r15, QWORD PTR 104[rsp]
	mov	rax, r15
	sar	rax, 2
	cmp	rax, rdx
	je	.L294
	test	rax, rax
	mov	ebp, 1
	lea	r12, 224[rsp]
	cmovne	rbp, rax
	add	rbp, rax
	movabs	rax, 2305843009213693951
	cmp	rbp, rax
	cmova	rbp, rax
	sal	rbp, 2
	mov	rcx, rbp
	call	_Znwy
	mov	DWORD PTR [rax+r15], r13d
	mov	r12, rax
	test	r15, r15
	je	.L169
	mov	rdx, QWORD PTR 104[rsp]
	mov	r8, r15
	mov	rcx, rax
	call	memcpy
.L169:
	mov	rcx, QWORD PTR 104[rsp]
	lea	rax, 4[r12+r15]
	mov	QWORD PTR 48[rsp], rax
	test	rcx, rcx
	je	.L170
	mov	rdx, QWORD PTR 72[rsp]
	sub	rdx, rcx
	call	_ZdlPvy
.L170:
	lea	rax, [r12+rbp]
	mov	QWORD PTR 104[rsp], r12
	mov	QWORD PTR 72[rsp], rax
	jmp	.L167
	.p2align 4,,10
	.p2align 3
.L161:
	mov	r10, QWORD PTR 224[rsp+rdx*8]
	sub	rax, r10
	mov	rdx, rax
	mov	r8, rax
	movabs	rax, 1152921504606846975
	sar	rdx, 3
	cmp	rdx, rax
	je	.L295
	test	rdx, rdx
	mov	eax, 1
	mov	QWORD PTR 136[rsp], r8
	lea	r12, 224[rsp]
	cmovne	rax, rdx
	mov	QWORD PTR 128[rsp], r10
	mov	QWORD PTR 120[rsp], r9
	add	rax, rdx
	movabs	rdx, 1152921504606846975
	cmp	rax, rdx
	cmova	rax, rdx
	sal	rax, 3
	mov	rcx, rax
	mov	QWORD PTR 56[rsp], rax
	call	_Znwy
	mov	r8, QWORD PTR 136[rsp]
	mov	r9, QWORD PTR 120[rsp]
	mov	r12, rax
	mov	r10, QWORD PTR 128[rsp]
	test	r8, r8
	movsd	QWORD PTR [rax+r8], xmm6
	je	.L164
	mov	rdx, r10
	mov	rcx, rax
	mov	QWORD PTR 136[rsp], r9
	mov	QWORD PTR 128[rsp], r8
	mov	QWORD PTR 120[rsp], r10
	call	memcpy
	mov	r9, QWORD PTR 136[rsp]
	mov	r10, QWORD PTR 120[rsp]
	mov	r8, QWORD PTR 128[rsp]
.L164:
	lea	rax, 8[r12+r8]
	test	r10, r10
	je	.L165
	mov	rdx, r9
	mov	rcx, r10
	mov	QWORD PTR 120[rsp], rax
	sub	rdx, r10
	call	_ZdlPvy
	mov	rax, QWORD PTR 120[rsp]
.L165:
	add	r15, rbp
	mov	QWORD PTR 224[rsp+r15*8], r12
	add	r12, QWORD PTR 56[rsp]
	mov	QWORD PTR 232[rsp+r15*8], rax
	mov	QWORD PTR 240[rsp+r15*8], r12
	jmp	.L162
.L292:
	lea	rcx, 8[rsi+rax]
	mov	DWORD PTR 4[rsi+rax], 2143363909
	cmp	rdx, rcx
	je	.L151
	mov	DWORD PTR 8[rsi+rax], 2143363909
	jmp	.L151
.L293:
	mov	r8, QWORD PTR 160[rsp]
	mov	rcx, QWORD PTR 152[rsp]
	mov	rdx, rbp
	call	memcmp
	test	eax, eax
	jne	.L174
	mov	rcx, QWORD PTR 168[rsp]
	xor	eax, eax
	lea	r8, 3[r14]
	sar	rcx, 2
	.p2align 4
	.p2align 3
.L175:
	cmp	rax, 2
	jbe	.L177
	mov	edx, 2143363909
	cmp	rax, r8
	jnb	.L178
	mov	rdx, QWORD PTR 152[rsp]
	movzx	edx, WORD PTR -4[rdx+rax*2]
	sal	edx, 16
.L178:
	mov	r11, QWORD PTR 64[rsp]
	cmp	edx, DWORD PTR [r11+rax*4]
	jne	.L217
	add	rax, 1
	cmp	rax, rcx
	jne	.L175
	mov	r15, QWORD PTR 112[rsp]
	mov	r8d, 38
	lea	rdx, .LC17[rip]
	lea	r12, 224[rsp]
	mov	rcx, r15
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rdx, QWORD PTR 176[rsp]
	mov	rcx, r15
	call	_ZNSo9_M_insertIyEERSoT_
	mov	r8d, 11
	lea	rdx, .LC18[rip]
	mov	rcx, rax
	mov	r13, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rdx, QWORD PTR 184[rsp]
	mov	rcx, r13
	call	_ZNSo9_M_insertIyEERSoT_
	mov	r8d, 10
	lea	rdx, .LC19[rip]
	mov	rcx, rax
	mov	r13, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rdx, r14
	mov	rcx, r13
	call	_ZNSo9_M_insertIyEERSoT_
	mov	r8d, 16
	lea	rdx, .LC20[rip]
	mov	rcx, rax
	mov	r13, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	lea	rdx, [r14+r14]
	mov	rcx, r13
	call	_ZNSo9_M_insertIyEERSoT_
	mov	r8d, 16
	lea	rdx, .LC21[rip]
	mov	rcx, rax
	mov	r13, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	lea	rdx, 0[0+r14*4]
	mov	rcx, r13
	call	_ZNSo9_M_insertIyEERSoT_
	mov	r8d, 10
	lea	rdx, .LC22[rip]
	mov	rcx, rax
	mov	r13, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	edx, DWORD PTR 92[rsp]
	mov	rcx, r13
	call	_ZNSo9_M_insertImEERSoT_
	mov	r8d, 16
	lea	rdx, .LC23[rip]
	mov	rcx, rax
	mov	r13, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	edx, DWORD PTR 144[rsp]
	mov	rcx, r13
	call	_ZNSo9_M_insertImEERSoT_
	mov	r8d, 22
	lea	rdx, .LC24[rip]
	mov	rcx, rax
	mov	r13, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rdx, rsi
	mov	rcx, r13
	call	_ZNSo9_M_insertIyEERSoT_
	mov	r8d, 53
	lea	rdx, .LC25[rip]
	mov	rcx, rax
	mov	r13, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	and	edi, 63
	mov	rcx, r13
	mov	rdx, rdi
	call	_ZNSo9_M_insertIyEERSoT_
	mov	r8d, 16
	lea	rdx, .LC26[rip]
	mov	rcx, rax
	mov	rdi, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	and	ebx, 63
	mov	rcx, rdi
	mov	rdx, rbx
	call	_ZNSo9_M_insertIyEERSoT_
	mov	r8d, 91
	lea	rdx, .LC27[rip]
	mov	rcx, rax
	mov	rbx, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	r8d, 70
	lea	rdx, .LC28[rip]
	mov	rcx, rbx
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rbx, QWORD PTR 48[rsp]
	sub	rbx, QWORD PTR 104[rsp]
	xor	edi, edi
	sar	rbx, 2
	jmp	.L181
	.p2align 4,,10
	.p2align 3
.L297:
	mov	r8d, 1
	lea	rdx, .LC2[rip]
.L182:
	mov	r15, QWORD PTR 112[rsp]
	lea	r12, 224[rsp]
	mov	rcx, r15
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rax, QWORD PTR 104[rsp]
	mov	rcx, r15
	mov	edx, DWORD PTR [rax+rdi*4]
	call	_ZNSo9_M_insertImEERSoT_
	add	rdi, 1
.L181:
	cmp	rdi, rbx
	je	.L296
	test	rdi, rdi
	jne	.L297
	xor	r8d, r8d
	lea	rdx, .LC1[rip]
	jmp	.L182
	.p2align 4,,10
	.p2align 3
.L177:
	mov	rdx, QWORD PTR 64[rsp]
	cmp	DWORD PTR [rdx+rax*4], 2143363909
	jne	.L217
	add	rax, 1
	jmp	.L175
.L296:
	mov	rdi, QWORD PTR 112[rsp]
	mov	r8d, 20
	lea	rdx, .LC29[rip]
	lea	r12, 224[rsp]
	mov	rcx, rdi
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rdx, r12
	mov	rcx, rdi
	call	_ZL5arrayRSoRKSt6vectorIdSaIdEE
	mov	r8d, 18
	lea	rdx, .LC30[rip]
	mov	rcx, rdi
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	lea	rdx, 248[rsp]
	mov	rcx, rdi
	call	_ZL5arrayRSoRKSt6vectorIdSaIdEE
	mov	r8d, 27
	lea	rdx, .LC31[rip]
	mov	rcx, rdi
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rcx, QWORD PTR 224[rsp]
	mov	rdx, QWORD PTR 232[rsp]
	cmp	rdx, rcx
	je	.L189
	pxor	xmm2, xmm2
	sub	rdx, rcx
	mov	rax, rcx
	cvtsi2sd	xmm2, rsi
	mulsd	xmm2, QWORD PTR .LC32[rip]
	cmp	rdx, 8
	je	.L186
	sub	rdx, 8
	movddup	xmm1, xmm2
	shr	rdx, 3
	add	rdx, 1
	mov	r8, rdx
	shr	r8
	sal	r8, 4
	add	r8, rcx
	.p2align 5
	.p2align 4
	.p2align 3
.L187:
	movupd	xmm0, XMMWORD PTR [rax]
	add	rax, 16
	divpd	xmm0, xmm1
	movups	XMMWORD PTR -16[rax], xmm0
	cmp	rax, r8
	jne	.L187
	test	dl, 1
	je	.L189
	and	rdx, -2
	lea	rcx, [rcx+rdx*8]
.L186:
	movsd	xmm0, QWORD PTR [rcx]
	divsd	xmm0, xmm2
	movsd	QWORD PTR [rcx], xmm0
.L189:
	mov	rcx, QWORD PTR 112[rsp]
	mov	rdx, r12
	call	_ZL5arrayRSoRKSt6vectorIdSaIdEE
	mov	rcx, QWORD PTR 112[rsp]
	mov	r8d, 26
	lea	rdx, .LC33[rip]
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rcx, QWORD PTR 248[rsp]
	mov	rdx, QWORD PTR 256[rsp]
	cmp	rdx, rcx
	je	.L196
	pxor	xmm2, xmm2
	sub	rdx, rcx
	mov	rax, rcx
	cvtsi2sd	xmm2, rsi
	mulsd	xmm2, QWORD PTR .LC32[rip]
	cmp	rdx, 8
	je	.L193
	sub	rdx, 8
	movddup	xmm1, xmm2
	shr	rdx, 3
	add	rdx, 1
	mov	r8, rdx
	shr	r8
	sal	r8, 4
	add	r8, rcx
	.p2align 5
	.p2align 4
	.p2align 3
.L194:
	movupd	xmm0, XMMWORD PTR [rax]
	add	rax, 16
	divpd	xmm0, xmm1
	movups	XMMWORD PTR -16[rax], xmm0
	cmp	rax, r8
	jne	.L194
	test	dl, 1
	je	.L196
	and	rdx, -2
	lea	rcx, [rcx+rdx*8]
.L193:
	movsd	xmm0, QWORD PTR [rcx]
	divsd	xmm0, xmm2
	movsd	QWORD PTR [rcx], xmm0
.L196:
	mov	rcx, QWORD PTR 112[rsp]
	lea	rdx, 248[rsp]
	call	_ZL5arrayRSoRKSt6vectorIdSaIdEE
	mov	rdi, QWORD PTR 112[rsp]
	mov	r8d, 1
	lea	rdx, .LC34[rip]
	mov	rcx, rdi
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rax, QWORD PTR [rdi]
	mov	rax, QWORD PTR -24[rax]
	mov	rbx, QWORD PTR 240[rdi+rax]
	test	rbx, rbx
	je	.L298
	cmp	BYTE PTR 56[rbx], 0
	je	.L199
	movsx	edx, BYTE PTR 67[rbx]
.L200:
	mov	rcx, QWORD PTR 112[rsp]
	call	_ZNSo3putEc
	mov	rcx, rax
	call	_ZNSo5flushEv
	mov	rcx, QWORD PTR .refptr._ZSt4cout[rip]
	mov	rdx, r14
	call	_ZNSo9_M_insertIyEERSoT_
	mov	r8d, 17
	lea	rdx, .LC35[rip]
	mov	rcx, rax
	mov	rbx, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rcx, rbx
	call	_ZNSo5flushEv
.LEHE14:
	mov	rcx, QWORD PTR 104[rsp]
	test	rcx, rcx
	je	.L201
	mov	rdx, QWORD PTR 72[rsp]
	sub	rdx, rcx
	call	_ZdlPvy
.L201:
	lea	rbx, 272[rsp]
.L205:
	mov	rcx, QWORD PTR -24[rbx]
	sub	rbx, 24
	test	rcx, rcx
	je	.L202
	mov	rdx, QWORD PTR 16[rbx]
	sub	rdx, rcx
	call	_ZdlPvy
	cmp	rbx, r12
	jne	.L205
.L203:
	mov	rdx, QWORD PTR 168[rsp]
	mov	rcx, QWORD PTR 64[rsp]
	call	_ZdlPvy
	test	rbp, rbp
	je	.L206
	mov	rdx, QWORD PTR 208[rsp]
	mov	rcx, rbp
	sub	rdx, rbp
	call	_ZdlPvy
.L206:
	mov	rdx, QWORD PTR 160[rsp]
	mov	rcx, QWORD PTR 152[rsp]
	movups	xmm6, XMMWORD PTR 272[rsp]
	movups	xmm7, XMMWORD PTR 288[rsp]
	movups	xmm8, XMMWORD PTR 304[rsp]
	add	rsp, 328
	pop	rbx
	pop	rsi
	pop	rdi
	pop	rbp
	pop	r12
	pop	r13
	pop	r14
	pop	r15
.LEHB15:
	jmp	_ZdlPvy
.LEHE15:
.L202:
	cmp	rbx, r12
	jne	.L205
	jmp	.L203
.L199:
	mov	rcx, rbx
.LEHB16:
	call	_ZNKSt5ctypeIcE13_M_widen_initEv
	mov	rax, QWORD PTR [rbx]
	lea	rcx, _ZNKSt5ctypeIcE8do_widenEc[rip]
	mov	edx, 10
	mov	rax, QWORD PTR 48[rax]
	cmp	rax, rcx
	je	.L200
	mov	rcx, rbx
	call	rax
.LEHE16:
	movsx	edx, al
	jmp	.L200
.L217:
	mov	ecx, 16
	call	__cxa_allocate_exception
	lea	rdx, .LC16[rip]
	mov	rcx, rax
	mov	rsi, rax
.LEHB17:
	call	_ZNSt13runtime_errorC1EPKc
.LEHE17:
	lea	r8, _ZNSt13runtime_errorD1Ev[rip]
	lea	rdx, _ZTISt13runtime_error[rip]
	mov	rcx, rsi
	lea	r12, 224[rsp]
.LEHB18:
	call	__cxa_throw
.LEHE18:
.L224:
.L289:
	mov	rcx, rsi
	mov	rbx, rax
	lea	r12, 224[rsp]
	call	__cxa_free_exception
.L208:
	cmp	QWORD PTR 104[rsp], 0
	je	.L210
	mov	rdx, QWORD PTR 72[rsp]
	mov	rcx, QWORD PTR 104[rsp]
	sub	rdx, rcx
	call	_ZdlPvy
.L210:
	lea	rsi, 272[rsp]
.L212:
	mov	rcx, QWORD PTR -24[rsi]
	sub	rsi, 24
	test	rcx, rcx
	je	.L211
	mov	rdx, QWORD PTR 16[rsi]
	sub	rdx, rcx
	call	_ZdlPvy
.L211:
	cmp	rsi, r12
	jne	.L212
	mov	rcx, QWORD PTR 64[rsp]
	mov	rdx, QWORD PTR 168[rsp]
	call	_ZdlPvy
	mov	rcx, QWORD PTR 192[rsp]
	test	rcx, rcx
	je	.L214
.L216:
	mov	rdx, QWORD PTR 208[rsp]
	sub	rdx, rcx
	call	_ZdlPvy
.L214:
	mov	rcx, QWORD PTR 152[rsp]
	mov	rdx, QWORD PTR 160[rsp]
	call	_ZdlPvy
	mov	rcx, rbx
.LEHB19:
	call	_Unwind_Resume
.L225:
	jmp	.L289
.L290:
	lea	rcx, .LC12[rip]
	call	_ZSt20__throw_length_errorPKc
.LEHE19:
.L294:
	lea	rcx, .LC14[rip]
	lea	r12, 224[rsp]
.LEHB20:
	call	_ZSt20__throw_length_errorPKc
.L226:
	mov	rcx, QWORD PTR 192[rsp]
	mov	rbx, rax
	jmp	.L216
.L223:
	mov	rbx, rax
	jmp	.L214
.L298:
	call	_ZSt16__throw_bad_castv
.LEHE20:
.L291:
	lea	rcx, .LC12[rip]
.LEHB21:
	call	_ZSt20__throw_length_errorPKc
.LEHE21:
.L227:
	mov	rbx, rax
	jmp	.L208
.L295:
	lea	rcx, .LC14[rip]
	lea	r12, 224[rsp]
.LEHB22:
	call	_ZSt20__throw_length_errorPKc
	nop
.LEHE22:
	.seh_handler	__gxx_personality_seh0, @unwind, @except
	.seh_handlerdata
.LLSDA10742:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10742-.LLSDACSB10742
.LLSDACSB10742:
	.uleb128 .LEHB9-.LFB10742
	.uleb128 .LEHE9-.LEHB9
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB10-.LFB10742
	.uleb128 .LEHE10-.LEHB10
	.uleb128 .L223-.LFB10742
	.uleb128 0
	.uleb128 .LEHB11-.LFB10742
	.uleb128 .LEHE11-.LEHB11
	.uleb128 .L226-.LFB10742
	.uleb128 0
	.uleb128 .LEHB12-.LFB10742
	.uleb128 .LEHE12-.LEHB12
	.uleb128 .L227-.LFB10742
	.uleb128 0
	.uleb128 .LEHB13-.LFB10742
	.uleb128 .LEHE13-.LEHB13
	.uleb128 .L224-.LFB10742
	.uleb128 0
	.uleb128 .LEHB14-.LFB10742
	.uleb128 .LEHE14-.LEHB14
	.uleb128 .L227-.LFB10742
	.uleb128 0
	.uleb128 .LEHB15-.LFB10742
	.uleb128 .LEHE15-.LEHB15
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB16-.LFB10742
	.uleb128 .LEHE16-.LEHB16
	.uleb128 .L227-.LFB10742
	.uleb128 0
	.uleb128 .LEHB17-.LFB10742
	.uleb128 .LEHE17-.LEHB17
	.uleb128 .L225-.LFB10742
	.uleb128 0
	.uleb128 .LEHB18-.LFB10742
	.uleb128 .LEHE18-.LEHB18
	.uleb128 .L227-.LFB10742
	.uleb128 0
	.uleb128 .LEHB19-.LFB10742
	.uleb128 .LEHE19-.LEHB19
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB20-.LFB10742
	.uleb128 .LEHE20-.LEHB20
	.uleb128 .L227-.LFB10742
	.uleb128 0
	.uleb128 .LEHB21-.LFB10742
	.uleb128 .LEHE21-.LEHB21
	.uleb128 .L226-.LFB10742
	.uleb128 0
	.uleb128 .LEHB22-.LFB10742
	.uleb128 .LEHE22-.LEHB22
	.uleb128 .L227-.LFB10742
	.uleb128 0
.LLSDACSE10742:
	.text
	.seh_endproc
	.section	.text$_ZN9__gnu_cxx6__stoaImmcJiEEET0_PFT_PKT1_PPS3_DpT2_EPKcS5_PyS9_,"x"
	.linkonce discard
	.p2align 4
	.globl	_ZN9__gnu_cxx6__stoaImmcJiEEET0_PFT_PKT1_PPS3_DpT2_EPKcS5_PyS9_
	.def	_ZN9__gnu_cxx6__stoaImmcJiEEET0_PFT_PKT1_PPS3_DpT2_EPKcS5_PyS9_;	.scl	2;	.type	32;	.endef
	.seh_proc	_ZN9__gnu_cxx6__stoaImmcJiEEET0_PFT_PKT1_PPS3_DpT2_EPKcS5_PyS9_
_ZN9__gnu_cxx6__stoaImmcJiEEET0_PFT_PKT1_PPS3_DpT2_EPKcS5_PyS9_:
.LFB10833:
	push	r12
	.seh_pushreg	r12
	push	rbp
	.seh_pushreg	rbp
	push	rdi
	.seh_pushreg	rdi
	push	rsi
	.seh_pushreg	rsi
	push	rbx
	.seh_pushreg	rbx
	sub	rsp, 48
	.seh_stackalloc	48
	.seh_endprologue
	mov	rsi, QWORD PTR __imp__errno[rip]
	mov	rbx, r8
	mov	QWORD PTR 104[rsp], rdx
	mov	rbp, rcx
	mov	rdi, r9
.LEHB23:
	call	rsi
	mov	r12d, DWORD PTR [rax]
	call	rsi
.LEHE23:
	mov	r8d, DWORD PTR 128[rsp]
	lea	rdx, 40[rsp]
	mov	rcx, rbx
	mov	DWORD PTR [rax], 0
.LEHB24:
	call	rbp
	mov	ebp, eax
	cmp	QWORD PTR 40[rsp], rbx
	je	.L310
	call	rsi
.LEHE24:
	cmp	DWORD PTR [rax], 34
	je	.L311
	test	rdi, rdi
	je	.L302
	mov	rax, QWORD PTR 40[rsp]
	sub	rax, rbx
	mov	QWORD PTR [rdi], rax
.L302:
	call	rsi
	mov	eax, DWORD PTR [rax]
	test	eax, eax
	je	.L312
	mov	eax, ebp
	add	rsp, 48
	pop	rbx
	pop	rsi
	pop	rdi
	pop	rbp
	pop	r12
	ret
	.p2align 4,,10
	.p2align 3
.L312:
	call	rsi
	mov	DWORD PTR [rax], r12d
	mov	eax, ebp
	add	rsp, 48
	pop	rbx
	pop	rsi
	pop	rdi
	pop	rbp
	pop	r12
	ret
.L311:
	mov	rcx, QWORD PTR 104[rsp]
.LEHB25:
	call	_ZSt20__throw_out_of_rangePKc
.L310:
	mov	rcx, QWORD PTR 104[rsp]
	call	_ZSt24__throw_invalid_argumentPKc
.LEHE25:
.L306:
	mov	rbx, rax
	call	rsi
	cmp	DWORD PTR [rax], 0
	je	.L313
.L305:
	mov	rcx, rbx
.LEHB26:
	call	_Unwind_Resume
.LEHE26:
.L313:
	call	rsi
	mov	DWORD PTR [rax], r12d
	jmp	.L305
	.seh_handler	__gxx_personality_seh0, @unwind, @except
	.seh_handlerdata
.LLSDA10833:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10833-.LLSDACSB10833
.LLSDACSB10833:
	.uleb128 .LEHB23-.LFB10833
	.uleb128 .LEHE23-.LEHB23
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB24-.LFB10833
	.uleb128 .LEHE24-.LEHB24
	.uleb128 .L306-.LFB10833
	.uleb128 0
	.uleb128 .LEHB25-.LFB10833
	.uleb128 .LEHE25-.LEHB25
	.uleb128 .L306-.LFB10833
	.uleb128 0
	.uleb128 .LEHB26-.LFB10833
	.uleb128 .LEHE26-.LEHB26
	.uleb128 0
	.uleb128 0
.LLSDACSE10833:
	.section	.text$_ZN9__gnu_cxx6__stoaImmcJiEEET0_PFT_PKT1_PPS3_DpT2_EPKcS5_PyS9_,"x"
	.linkonce discard
	.seh_endproc
	.section .rdata,"dr"
.LC38:
	.ascii "Requires AVX2/FMA\0"
	.align 8
.LC39:
	.ascii "OUTPUT.jsonl [ROUNDS=15] [WARMUP_PAIRS=3]\0"
.LC40:
	.ascii "stoul\0"
.LC41:
	.ascii "Invalid rounds/warmup\0"
.LC42:
	.ascii "Use a fresh output file\0"
.LC43:
	.ascii "Cannot create output\0"
	.align 8
.LC44:
	.ascii "{\"type\":\"correctness\",\"passed\":true,\"values_checked\":\0"
	.align 8
.LC45:
	.ascii ",\"all_bf16_patterns\":true,\"offsets_tails_guards\":true,\"floating_arithmetic_on_values\":false}\0"
	.align 8
.LC46:
	.ascii "{\"type\":\"summary\",\"complete\":true,\"cases\":\0"
	.align 8
.LC47:
	.ascii ",\"timing_qualified\":false,\"whole_model_speed_claim\":false}\0"
	.section	.text.startup,"x"
	.p2align 4
	.globl	main
	.def	main;	.scl	2;	.type	32;	.endef
	.seh_proc	main
main:
.LFB10777:
	push	r15
	.seh_pushreg	r15
	push	r14
	.seh_pushreg	r14
	push	r13
	.seh_pushreg	r13
	push	r12
	.seh_pushreg	r12
	push	rbp
	.seh_pushreg	rbp
	push	rdi
	.seh_pushreg	rdi
	push	rsi
	.seh_pushreg	rsi
	push	rbx
	.seh_pushreg	rbx
	sub	rsp, 1032
	.seh_stackalloc	1032
	.seh_endprologue
	mov	edi, ecx
	mov	rbx, rdx
	call	__main
	mov	rax, QWORD PTR .refptr.__cpu_model[rip]
	mov	eax, DWORD PTR 12[rax]
	not	eax
	test	ah, 68
	jne	.L365
	lea	eax, -2[rdi]
	cmp	eax, 2
	ja	.L366
	cmp	edi, 2
	jne	.L317
	lea	rax, 544[rsp]
	mov	esi, 15
	mov	edi, 3
	mov	QWORD PTR 56[rsp], rax
.L318:
	mov	rdx, QWORD PTR 8[rbx]
	mov	rcx, QWORD PTR 56[rsp]
	mov	r8d, 8
.LEHB27:
	call	_ZNSt14basic_ifstreamIcSt11char_traitsIcEEC1EPKcSt13_Ios_Openmode
.LEHE27:
	mov	eax, DWORD PTR 784[rsp]
	test	eax, eax
	je	.L367
	mov	rdx, QWORD PTR 8[rbx]
	lea	rbx, 80[rsp]
	mov	r8d, 16
	mov	rcx, rbx
.LEHB28:
	call	_ZNSt14basic_ofstreamIcSt11char_traitsIcEEC1EPKcSt13_Ios_Openmode
.LEHE28:
	mov	edx, DWORD PTR 312[rsp]
	mov	eax, edx
	and	eax, 5
	mov	DWORD PTR 76[rsp], eax
	jne	.L368
	lea	rcx, 280[rsp]
	mov	DWORD PTR 308[rsp], 5
.LEHB29:
	call	_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate
	mov	rax, QWORD PTR 80[rsp]
	xor	r8d, r8d
	xor	edx, edx
	mov	ecx, 65536
	mov	rax, QWORD PTR -24[rax]
	mov	QWORD PTR 88[rsp+rax], 12
	call	_ZL11verify_caseyyy
	mov	r8d, 7
	mov	edx, 7
	mov	ecx, 65536
	mov	r12, rax
	call	_ZL11verify_caseyyy
	add	r12, rax
	xor	r14d, r14d
	lea	r15, C.24.2[rip+64]
.L324:
	xor	r13d, r13d
	.p2align 4
	.p2align 3
.L328:
	lea	rbp, C.24.2[rip]
	.p2align 4
	.p2align 3
.L325:
	mov	ecx, DWORD PTR 0[rbp]
	mov	r8, r13
	mov	rdx, r14
	call	_ZL11verify_caseyyy
	add	rbp, 4
	add	r12, rax
	cmp	rbp, r15
	jne	.L325
	add	r13, 1
	cmp	r13, 8
	jne	.L328
	add	r14, 1
	cmp	r14, 8
	jne	.L324
	mov	r8d, 53
	lea	rdx, .LC44[rip]
	mov	rcx, rbx
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rdx, r12
	mov	rcx, rbx
	call	_ZNSo9_M_insertIyEERSoT_
	mov	r8d, 92
	lea	rdx, .LC45[rip]
	mov	rcx, rax
	mov	r12, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rcx, r12
	call	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_.isra.0
	lea	rax, C.7.0[rip]
	xor	r15d, r15d
	lea	r13, C.8.1[rip+16]
	mov	QWORD PTR 64[rsp], rax
	lea	rbp, 8[rax]
.L330:
	mov	rax, QWORD PTR 64[rsp]
	mov	r12d, r15d
	lea	r14, C.8.1[rip]
	mov	eax, DWORD PTR [rax]
	mov	QWORD PTR 48[rsp], rax
.L329:
	mov	DWORD PTR 32[rsp], edi
	mov	rdx, QWORD PTR 48[rsp]
	mov	r9d, esi
	mov	rcx, rbx
	mov	r8d, DWORD PTR [r14]
	call	_ZL8run_caseRSoyyjj
	add	r14, 4
	add	r15d, 1
	cmp	r14, r13
	je	.L369
	mov	r12d, r15d
	jmp	.L329
.L369:
	add	QWORD PTR 64[rsp], 4
	cmp	QWORD PTR 64[rsp], rbp
	jne	.L330
	mov	DWORD PTR 32[rsp], edi
	mov	r9d, esi
	mov	r8d, 1048576
	mov	rcx, rbx
	mov	edx, 1
	call	_ZL8run_caseRSoyyjj
	mov	r8d, 42
	lea	rdx, .LC46[rip]
	mov	rcx, rbx
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	lea	edx, 2[r12]
	mov	rcx, rbx
	call	_ZNSo9_M_insertImEERSoT_
	mov	r8d, 58
	lea	rdx, .LC47[rip]
	mov	rcx, rax
	mov	rsi, rax
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
	mov	rcx, rsi
	call	_ZSt4endlIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_.isra.0
.LEHE29:
	mov	rcx, rbx
	call	_ZNSt14basic_ofstreamIcSt11char_traitsIcEED1Ev
	mov	rcx, QWORD PTR 56[rsp]
	call	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
.L314:
	mov	eax, DWORD PTR 76[rsp]
	add	rsp, 1032
	pop	rbx
	pop	rsi
	pop	rdi
	pop	rbp
	pop	r12
	pop	r13
	pop	r14
	pop	r15
	ret
.L317:
	lea	r15, 544[rsp]
	mov	rdx, QWORD PTR 16[rbx]
	mov	rcx, r15
	mov	QWORD PTR 56[rsp], r15
.LEHB30:
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1IS3_EEPKcRKS3_.isra.0
.LEHE30:
	mov	DWORD PTR 32[rsp], 10
	mov	r8, QWORD PTR 544[rsp]
	xor	r9d, r9d
	lea	rdx, .LC40[rip]
	lea	rcx, strtoul[rip]
.LEHB31:
	call	_ZN9__gnu_cxx6__stoaImmcJiEEET0_PFT_PKT1_PPS3_DpT2_EPKcS5_PyS9_
.LEHE31:
	mov	rcx, r15
	mov	esi, eax
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_disposeEv
	cmp	edi, 4
	je	.L319
	lea	eax, -1[rsi]
	mov	edi, 3
	cmp	eax, 999
	jbe	.L318
.L321:
	mov	ecx, 16
	call	__cxa_allocate_exception
	lea	rdx, .LC41[rip]
	mov	rcx, rax
	mov	rdi, rax
.LEHB32:
	call	_ZNSt13runtime_errorC1EPKc
.LEHE32:
	lea	r8, _ZNSt13runtime_errorD1Ev[rip]
	lea	rdx, _ZTISt13runtime_error[rip]
	mov	rcx, rdi
.LEHB33:
	call	__cxa_throw
.L319:
	mov	r15, QWORD PTR 56[rsp]
	mov	rdx, QWORD PTR 24[rbx]
	mov	rcx, r15
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEC1IS3_EEPKcRKS3_.isra.0
.LEHE33:
	mov	DWORD PTR 32[rsp], 10
	mov	r8, QWORD PTR 544[rsp]
	xor	r9d, r9d
	lea	rdx, .LC40[rip]
	lea	rcx, strtoul[rip]
.LEHB34:
	call	_ZN9__gnu_cxx6__stoaImmcJiEEET0_PFT_PKT1_PPS3_DpT2_EPKcS5_PyS9_
.LEHE34:
	mov	rcx, r15
	mov	edi, eax
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_disposeEv
	lea	eax, -1[rsi]
	cmp	eax, 999
	ja	.L321
	cmp	edi, 1000
	jbe	.L318
	jmp	.L321
.L358:
.L363:
	mov	rcx, QWORD PTR 56[rsp]
	mov	rsi, rdx
	mov	rbx, rax
	call	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_disposeEv
	mov	rax, rsi
.L332:
	sub	rax, 1
	mov	rcx, rbx
	jne	.L364
	call	__cxa_begin_catch
	mov	rdx, QWORD PTR [rax]
	mov	rcx, rax
	call	[QWORD PTR 16[rdx]]
	mov	rcx, QWORD PTR .refptr._ZSt4cerr[rip]
	mov	rdx, rax
.LEHB35:
	call	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc
	mov	BYTE PTR 544[rsp], 10
	mov	rcx, rax
	mov	rax, QWORD PTR [rax]
	mov	rax, QWORD PTR -24[rax]
	cmp	QWORD PTR 16[rcx+rax], 0
	je	.L342
	lea	rdx, 544[rsp]
	mov	r8d, 1
	call	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x
.LEHE35:
.L344:
	call	__cxa_end_catch
	mov	DWORD PTR 76[rsp], 1
	jmp	.L314
.L351:
.L362:
	mov	rsi, rdx
	mov	rcx, rdi
	mov	rbx, rax
	call	__cxa_free_exception
	mov	rax, rsi
	jmp	.L332
.L356:
	mov	rbx, rax
	call	__cxa_end_catch
	mov	rcx, rbx
.L364:
.LEHB36:
	call	_Unwind_Resume
.LEHE36:
.L357:
	jmp	.L363
.L365:
	mov	ecx, 16
	call	__cxa_allocate_exception
	lea	rdx, .LC38[rip]
	mov	rcx, rax
	mov	rdi, rax
.LEHB37:
	call	_ZNSt13runtime_errorC1EPKc
.LEHE37:
	lea	r8, _ZNSt13runtime_errorD1Ev[rip]
	lea	rdx, _ZTISt13runtime_error[rip]
	mov	rcx, rdi
.LEHB38:
	call	__cxa_throw
.LEHE38:
.L354:
	mov	rsi, rax
	mov	rdi, rdx
.L340:
	mov	rcx, rbx
	mov	rbx, rsi
	mov	rsi, rdi
	call	_ZNSt14basic_ofstreamIcSt11char_traitsIcEED1Ev
.L338:
	mov	rcx, QWORD PTR 56[rsp]
	call	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev
	mov	rax, rsi
	jmp	.L332
.L348:
	jmp	.L362
.L368:
	mov	ecx, 16
	call	__cxa_allocate_exception
	lea	rdx, .LC43[rip]
	mov	rcx, rax
	mov	r12, rax
.LEHB39:
	call	_ZNSt13runtime_errorC1EPKc
.LEHE39:
	lea	r8, _ZNSt13runtime_errorD1Ev[rip]
	lea	rdx, _ZTISt13runtime_error[rip]
	mov	rcx, r12
.LEHB40:
	call	__cxa_throw
.LEHE40:
.L366:
	mov	ecx, 16
	call	__cxa_allocate_exception
	lea	rdx, .LC39[rip]
	mov	rcx, rax
	mov	rdi, rax
.LEHB41:
	call	_ZNSt13runtime_errorC1EPKc
.LEHE41:
	lea	r8, _ZNSt13runtime_errorD1Ev[rip]
	lea	rdx, _ZTISt13runtime_error[rip]
	mov	rcx, rdi
.LEHB42:
	call	__cxa_throw
.LEHE42:
.L367:
	mov	ecx, 16
	call	__cxa_allocate_exception
	lea	rdx, .LC42[rip]
	mov	rcx, rax
	mov	rdi, rax
.LEHB43:
	call	_ZNSt13runtime_errorC1EPKc
.LEHE43:
	lea	r8, _ZNSt13runtime_errorD1Ev[rip]
	lea	rdx, _ZTISt13runtime_error[rip]
	mov	rcx, rdi
.LEHB44:
	call	__cxa_throw
.LEHE44:
.L352:
	mov	rbx, rax
	mov	rsi, rdx
	jmp	.L338
.L349:
	mov	rbx, rax
	mov	rax, rdx
	jmp	.L332
.L350:
	jmp	.L362
.L342:
	mov	edx, 10
.LEHB45:
	call	_ZNSo3putEc
.LEHE45:
	jmp	.L344
.L355:
	mov	rcx, r12
	mov	rsi, rax
	mov	rdi, rdx
	call	__cxa_free_exception
	jmp	.L340
.L353:
	mov	rcx, rdi
	mov	rbx, rax
	mov	rsi, rdx
	call	__cxa_free_exception
	jmp	.L338
	.seh_handler	__gxx_personality_seh0, @unwind, @except
	.seh_handlerdata
	.align 4
.LLSDA10777:
	.byte	0xff
	.byte	0x9b
	.uleb128 .LLSDATT10777-.LLSDATTD10777
.LLSDATTD10777:
	.byte	0x1
	.uleb128 .LLSDACSE10777-.LLSDACSB10777
.LLSDACSB10777:
	.uleb128 .LEHB27-.LFB10777
	.uleb128 .LEHE27-.LEHB27
	.uleb128 .L349-.LFB10777
	.uleb128 0x1
	.uleb128 .LEHB28-.LFB10777
	.uleb128 .LEHE28-.LEHB28
	.uleb128 .L352-.LFB10777
	.uleb128 0x3
	.uleb128 .LEHB29-.LFB10777
	.uleb128 .LEHE29-.LEHB29
	.uleb128 .L354-.LFB10777
	.uleb128 0x3
	.uleb128 .LEHB30-.LFB10777
	.uleb128 .LEHE30-.LEHB30
	.uleb128 .L349-.LFB10777
	.uleb128 0x1
	.uleb128 .LEHB31-.LFB10777
	.uleb128 .LEHE31-.LEHB31
	.uleb128 .L358-.LFB10777
	.uleb128 0x3
	.uleb128 .LEHB32-.LFB10777
	.uleb128 .LEHE32-.LEHB32
	.uleb128 .L351-.LFB10777
	.uleb128 0x3
	.uleb128 .LEHB33-.LFB10777
	.uleb128 .LEHE33-.LEHB33
	.uleb128 .L349-.LFB10777
	.uleb128 0x1
	.uleb128 .LEHB34-.LFB10777
	.uleb128 .LEHE34-.LEHB34
	.uleb128 .L357-.LFB10777
	.uleb128 0x3
	.uleb128 .LEHB35-.LFB10777
	.uleb128 .LEHE35-.LEHB35
	.uleb128 .L356-.LFB10777
	.uleb128 0
	.uleb128 .LEHB36-.LFB10777
	.uleb128 .LEHE36-.LEHB36
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB37-.LFB10777
	.uleb128 .LEHE37-.LEHB37
	.uleb128 .L348-.LFB10777
	.uleb128 0x3
	.uleb128 .LEHB38-.LFB10777
	.uleb128 .LEHE38-.LEHB38
	.uleb128 .L349-.LFB10777
	.uleb128 0x1
	.uleb128 .LEHB39-.LFB10777
	.uleb128 .LEHE39-.LEHB39
	.uleb128 .L355-.LFB10777
	.uleb128 0x3
	.uleb128 .LEHB40-.LFB10777
	.uleb128 .LEHE40-.LEHB40
	.uleb128 .L354-.LFB10777
	.uleb128 0x3
	.uleb128 .LEHB41-.LFB10777
	.uleb128 .LEHE41-.LEHB41
	.uleb128 .L350-.LFB10777
	.uleb128 0x3
	.uleb128 .LEHB42-.LFB10777
	.uleb128 .LEHE42-.LEHB42
	.uleb128 .L349-.LFB10777
	.uleb128 0x1
	.uleb128 .LEHB43-.LFB10777
	.uleb128 .LEHE43-.LEHB43
	.uleb128 .L353-.LFB10777
	.uleb128 0x3
	.uleb128 .LEHB44-.LFB10777
	.uleb128 .LEHE44-.LEHB44
	.uleb128 .L352-.LFB10777
	.uleb128 0x3
	.uleb128 .LEHB45-.LFB10777
	.uleb128 .LEHE45-.LEHB45
	.uleb128 .L356-.LFB10777
	.uleb128 0
.LLSDACSE10777:
	.byte	0x1
	.byte	0
	.byte	0
	.byte	0x7d
	.align 4
	.long	.LDFCM0-.
.LLSDATT10777:
	.section	.text.startup,"x"
	.seh_endproc
	.section .rdata,"dr"
	.align 16
C.48.4:
	.long	0
	.long	1
	.long	1
	.long	0
	.align 16
C.25.3:
	.quad	_ZL8baselinePKtPfy
	.quad	_ZL13vector_expandPKtPfy
	.align 32
C.24.2:
	.long	1
	.long	2
	.long	7
	.long	8
	.long	9
	.long	15
	.long	16
	.long	17
	.long	31
	.long	32
	.long	33
	.long	63
	.long	64
	.long	65
	.long	127
	.long	129
	.align 16
C.8.1:
	.long	896
	.long	960
	.long	2560
	.long	4864
	.align 8
C.7.0:
	.long	6
	.long	96
	.globl	_ZTSSt9exception
	.section	.rdata$_ZTSSt9exception,"dr"
	.linkonce same_size
	.align 8
_ZTSSt9exception:
	.ascii "St9exception\0"
	.globl	_ZTISt9exception
	.section	.rdata$_ZTISt9exception,"dr"
	.linkonce same_size
	.align 8
_ZTISt9exception:
	.quad	_ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	_ZTSSt9exception
	.globl	_ZTSSt13runtime_error
	.section	.rdata$_ZTSSt13runtime_error,"dr"
	.linkonce same_size
	.align 16
_ZTSSt13runtime_error:
	.ascii "St13runtime_error\0"
	.globl	_ZTISt13runtime_error
	.section	.rdata$_ZTISt13runtime_error,"dr"
	.linkonce same_size
	.align 8
_ZTISt13runtime_error:
	.quad	_ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	_ZTSSt13runtime_error
	.quad	_ZTISt9exception
	.globl	expand_sink
	.bss
	.align 8
expand_sink:
	.space 8
	.section .rdata,"dr"
	.align 16
.LC3:
	.quad	0
	.quad	1
	.align 8
.LC32:
	.long	0
	.long	1093567616
	.data
	.align 8
.LDFCM0:
	.quad	_ZTISt9exception
	.def	__main;	.scl	2;	.type	32;	.endef
	.def	__gxx_personality_seh0;	.scl	2;	.type	32;	.endef
	.ident	"GCC: (Rev9, Built by MSYS2 project) 15.2.0"
	.def	strlen;	.scl	2;	.type	32;	.endef
	.def	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERyy;	.scl	2;	.type	32;	.endef
	.def	memcpy;	.scl	2;	.type	32;	.endef
	.def	_ZSt19__throw_logic_errorPKc;	.scl	2;	.type	32;	.endef
	.def	_ZNSo3putEc;	.scl	2;	.type	32;	.endef
	.def	_ZNSo5flushEv;	.scl	2;	.type	32;	.endef
	.def	_ZNKSt5ctypeIcE13_M_widen_initEv;	.scl	2;	.type	32;	.endef
	.def	_ZSt16__throw_bad_castv;	.scl	2;	.type	32;	.endef
	.def	_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_x;	.scl	2;	.type	32;	.endef
	.def	_ZNSo9_M_insertIdEERSoT_;	.scl	2;	.type	32;	.endef
	.def	_Znwy;	.scl	2;	.type	32;	.endef
	.def	memset;	.scl	2;	.type	32;	.endef
	.def	__cxa_allocate_exception;	.scl	2;	.type	32;	.endef
	.def	_ZNSt13runtime_errorC1EPKc;	.scl	2;	.type	32;	.endef
	.def	_ZNSt13runtime_errorD1Ev;	.scl	2;	.type	32;	.endef
	.def	__cxa_throw;	.scl	2;	.type	32;	.endef
	.def	_ZdlPvy;	.scl	2;	.type	32;	.endef
	.def	memcmp;	.scl	2;	.type	32;	.endef
	.def	_Unwind_Resume;	.scl	2;	.type	32;	.endef
	.def	__cxa_free_exception;	.scl	2;	.type	32;	.endef
	.def	_ZNSt6chrono3_V212steady_clock3nowEv;	.scl	2;	.type	32;	.endef
	.def	_ZNSo9_M_insertIyEERSoT_;	.scl	2;	.type	32;	.endef
	.def	_ZNSo9_M_insertImEERSoT_;	.scl	2;	.type	32;	.endef
	.def	_ZSt20__throw_length_errorPKc;	.scl	2;	.type	32;	.endef
	.def	_ZSt20__throw_out_of_rangePKc;	.scl	2;	.type	32;	.endef
	.def	_ZSt24__throw_invalid_argumentPKc;	.scl	2;	.type	32;	.endef
	.def	_ZNSt14basic_ifstreamIcSt11char_traitsIcEEC1EPKcSt13_Ios_Openmode;	.scl	2;	.type	32;	.endef
	.def	_ZNSt14basic_ofstreamIcSt11char_traitsIcEEC1EPKcSt13_Ios_Openmode;	.scl	2;	.type	32;	.endef
	.def	_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate;	.scl	2;	.type	32;	.endef
	.def	_ZNSt14basic_ofstreamIcSt11char_traitsIcEED1Ev;	.scl	2;	.type	32;	.endef
	.def	_ZNSt14basic_ifstreamIcSt11char_traitsIcEED1Ev;	.scl	2;	.type	32;	.endef
	.def	strtoul;	.scl	2;	.type	32;	.endef
	.def	_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_disposeEv;	.scl	2;	.type	32;	.endef
	.def	__cxa_begin_catch;	.scl	2;	.type	32;	.endef
	.def	_ZStlsISt11char_traitsIcEERSt13basic_ostreamIcT_ES5_PKc;	.scl	2;	.type	32;	.endef
	.def	__cxa_end_catch;	.scl	2;	.type	32;	.endef
	.section	.rdata$.refptr._ZSt4cerr, "dr"
	.p2align	3, 0
	.globl	.refptr._ZSt4cerr
	.linkonce	discard
.refptr._ZSt4cerr:
	.quad	_ZSt4cerr
	.section	.rdata$.refptr.strtoul, "dr"
	.p2align	3, 0
	.globl	.refptr.strtoul
	.linkonce	discard
.refptr.strtoul:
	.quad	strtoul
	.section	.rdata$.refptr.__cpu_model, "dr"
	.p2align	3, 0
	.globl	.refptr.__cpu_model
	.linkonce	discard
.refptr.__cpu_model:
	.quad	__cpu_model
	.section	.rdata$.refptr._ZSt4cout, "dr"
	.p2align	3, 0
	.globl	.refptr._ZSt4cout
	.linkonce	discard
.refptr._ZSt4cout:
	.quad	_ZSt4cout
	.section	.rdata$.refptr._ZNSt13runtime_errorD1Ev, "dr"
	.p2align	3, 0
	.globl	.refptr._ZNSt13runtime_errorD1Ev
	.linkonce	discard
.refptr._ZNSt13runtime_errorD1Ev:
	.quad	_ZNSt13runtime_errorD1Ev
