import json,subprocess,sys,hashlib,statistics
from pathlib import Path
import psutil
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from leaf.power import benchmark_power_mode_guard,keep_awake,require_benchmark_ac
from tools.decoder_validation import latency_stability
base=Path(__file__).resolve().parent
exe=base/'bf16_expand_layouts.exe';raw=base/'expansion-layouts.jsonl';report=base/'expansion-layouts.json'
if report.exists() or raw.exists():raise ValueError('Use fresh output paths')
paths=[exe,Path(__file__),root/'benchmark/bf16_expand_benchmark.cpp',root/'engine/include/leaf/kernels/source_bf16.h']
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=dict(complete=False,acceptance_timing=False,timing_qualified=False,power_mode={},hashes={str(p):digest(p) for p in paths},cpu=2,source='Identical reused buffers; isolated bit expansion, not model latency')
parent=psutil.Process();saved=parent.cpu_affinity();child=None
try:
 parent.cpu_affinity([2])
 with keep_awake(display=True),benchmark_power_mode_guard(r['power_mode'],required_mode='better-battery'):
  r['ac_before']=require_benchmark_ac()
  child=subprocess.Popen([str(exe),str(raw),'15','3'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,creationflags=subprocess.ABOVE_NORMAL_PRIORITY_CLASS)
  out,err=child.communicate();(base/'expansion-layouts.log').write_text(out+err,encoding='utf-8')
  if child.returncode:raise RuntimeError(err)
  r['ac_after']=require_benchmark_ac()
 rows=[json.loads(x) for x in raw.read_text(encoding='utf-8').splitlines()]
 assert len(rows)==20 and rows[0]['passed'] is True and rows[0]['all_bf16_patterns'] is True
 assert rows[-1]['complete'] is True and rows[-1]['cases']==18
 r['correctness']=rows[0];r['cases']=[]
 for c in rows[1:-1]:
  a,b=c['before_ms_per_expansion'],c['after_ms_per_expansion']
  assert len(a)==len(b)==30 and c['bits_and_guards_exact'] is True
  sa,sb=latency_stability(a),latency_stability(b)
  assert sa['p10_ms'] and sb['p10_ms']
  s=dict(values=c['values'],layout=c['layout'],source_mod64=c['source_mod64'],output_mod64=c['output_mod64'],before_ms=statistics.median(a),after_ms=statistics.median(b),median_paired_ratio=statistics.median(y/x for x,y in zip(a,b)),before_stability=sa,after_stability=sb)
  r['cases'].append(s);print(s['layout'],s['values'],round(s['median_paired_ratio'],4),sa['passed'] and sb['passed'],flush=True)
 assert all(digest(Path(p))==h for p,h in r['hashes'].items())
 r['complete']=True
finally:
 if child is not None and child.poll() is None:child.terminate();child.wait()
 parent.cpu_affinity(saved)
 report.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8',newline='\n')
