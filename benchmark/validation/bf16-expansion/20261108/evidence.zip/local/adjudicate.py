import hashlib,json,statistics
from pathlib import Path
base=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
quality=base/'trained/quality.json';q=json.loads(quality.read_text(encoding='utf-8'))
assert q['complete'] is True and q['passed'] is True
out=dict(complete=True,scope='Predeclared AVX2 expansion incremental gate vs prior six-row implementation; no competitor or universal-storage speed claim',
 gates=dict(prefill_max_ratio=.98,decode_max_ratio=1.02,p90_p10_max=1.25),models={},hashes={str(quality):sha(quality)},overall_competitor_speed_claim=False)
for name in ('smol','qwen'):
 path=base/(name+'-acceptance')/'comparison.json';r=json.loads(path.read_text(encoding='utf-8'))
 assert r['complete'] is True and r['inputs_unchanged'] is True
 assert r['pairs']==6 and r['runs']==31 and r['warmup']==10 and len(r['passes'])==12
 assert r['before_math']==r['after_math']=='accurate' and r['threads']==1 and r['worker_cpus']==[2]
 assert r['counters_enabled'] is False and r['power_mode']['passed'] is True
 assert r['power_mode']['initial_mode']==r['power_mode']['final_mode']=='better-battery'
 assert r['request']==dict(token_count=64,prefill_tokens=63,decode_tokens=1,reset_each_sample=True,all_token_logits=False)
 for i,p in enumerate(r['passes']):
  assert p['validated'] is True and p['pair']==i//2
  assert p['stage']==(('before','after') if (i//2)%2==0 else ('after','before'))[i%2]
  assert p['ac_before']['ac_line_status']==p['ac_after']['ac_line_status']==1
  assert all(len(p['metrics'][phase+'_samples_ms'])==31 for phase in ('prefill','decode'))
 # Storage is byte-identical; this comparison changes only its runtime kernel.
 assert r['hashes'][r['artifacts']['before']]==r['hashes'][r['artifacts']['after']]
 phases={}
 for phase,limit in [('prefill',.98),('decode',1.02)]:
  s=r['summary'][phase]
  passed=s['stable'] and s['pooled_ratio']<=limit and s['median_paired_ratio']<=limit
  phases[phase]=dict(passed=passed,stable=s['stable'],medians_ms=s['medians_ms'],pooled_ratio=s['pooled_ratio'],median_paired_ratio=s['median_paired_ratio'])
 out['models'][name]=dict(passed=all(s['passed'] for s in phases.values()),phases=phases,samples_per_runtime_per_phase=186)
 out['hashes'][str(path)]=sha(path)
 print(name,out['models'][name])
out['both_models_passed']=all(m['passed'] for m in out['models'].values())
(base/'incremental-gate.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
