<p align="center">
  <img src="docs/assets/leaf-logo.png" alt="Leaf" width="360">
</p>

# Leaf

**Native CPU inference for smaller models.**

Leaf helps people run trained models locally on the CPUs they already own.
It combines a C++ inference runtime, compact weight formats, reusable memory,
and a lightweight command-line interface. The goal is practical latency and
memory use without requiring a GPU.

[Get started](#quick-start) · [How it works](#how-it-works) ·
[Benchmarks](#measured-performance) · [Documentation](docs/README.md) ·
[Contributing](#development-and-contributing)

## Why Leaf?

- **Lightweight execution.** Native generation and document embeddings;
  PyTorch and Transformers stay outside deployed inference.
- **Measured CPU optimizations.** Tiled linear operations, SIMD kernels and
  reusable buffers, with portable fallbacks and explicit correctness checks.
- **Smaller artifacts when quality permits.** FP32, INT8/INT4 and calibrated
  W8A8 paths. Automatic lower precision requires a matching quality and speed
  profile; otherwise Leaf keeps FP32.
- **Local, reusable preparation.** Import supported snapshots once, cache native
  artifacts, and run offline with your own prompts and datasets.

Leaf is an early-stage inference engine with measured GPT-2 FP32 and TinyLlama
W8A8 wins on the tested Windows workloads. W8A8 trades some output quality for
speed; these results do not establish a win for every model or CPU.

## Quick start

Requires **Python 3.10+**. Installing from source also requires a **C++17 compiler**.
A platform wheel bundles the native decoder and embedding runtime; inference
does not require a compiler.

```sh
git clone https://github.com/Nbit-51/Leaf.git
cd Leaf
python -m pip install .
leaf --help
leaf doctor
leaf inspect openai-community/gpt2
leaf run openai-community/gpt2 --prompt "Local inference is" --max-tokens 32
```

The first Hub run downloads and prepares the model; subsequent runs reuse the
cache. `leaf inspect MODEL_ID` fetches decoder configuration only and reports
operator compatibility plus a lower bound on FP32 weight memory before a large
download. It does not certify checkpoint correctness or speed. To use a complete local snapshot containing configuration, safetensors
weights and tokenizer files:

```sh
leaf run ./models/decoder --offline --prompt "Explain CPU inference." --max-tokens 32
```

Chat templates are applied when supplied by the tokenizer configuration; use
`--raw` for an unformatted prompt. Generation is currently greedy.

For checkpoints originally stored in BF16, optional matrix storage keeps
those source values while computing in FP32:

```sh
leaf run HuggingFaceTB/SmolLM2-360M-Instruct --bits 32 --source-bf16 --prompt "Explain CPU inference." --max-tokens 32
```

FP32 source weights stay FP32. This uses a separate prepared cache; see
[storage semantics, exact-output checks and measured scope](docs/source-bf16.md).

For the explicit accurate FP32 accumulation policy, add `--fp32-math accurate`
to `leaf run` or `leaf evaluate`. For `leaf run`, it can be combined with
`--source-bf16` or `--source-bf16-head`;
weights remain unquantized and `--bits auto` selects FP32. The default math
policy is unchanged. See [accuracy checks and scope](docs/shared-accumulation.md#native-accuracy-option--october-26-2026).

For output checks without timing benchmarks, install `.[validation]` and run
`leaf evaluate MODEL_ID --dataset heldout.jsonl --dataset-source "name/test split" --output build/quality-run`.
It records perplexity, next-token agreement and paired continuations. See
[setup and quality evidence](docs/model-onboarding.md), including the remaining
strict-logit failures found by the larger Pythia checks.

For **EmbeddingGemma 300M FP32**, supply its model ID. Leaf downloads the
tokenizer, weights and projection layers together; no manual file assembly:

```sh
leaf embed google/embeddinggemma-300m --text "How does CPU inference work?" --task query --output query.npy
leaf embed google/embeddinggemma-300m --offline --dataset ./data/documents.jsonl --task document --output documents.npy
```

Gemma requires accepting its model access terms and signing in to Hugging Face
once (`hf auth login`). Complete local folders work too. Outputs are normalized
768-dimensional vectors in input order. The model is
loaded once per invocation. See [embedding usage and validation](docs/embedding.md)
for snapshot layout, limits and measured numerical accuracy.

To evaluate precision candidates, install the validation tools and use separate
calibration and held-out text:

```sh
python -m pip install ".[validation]"
leaf optimize ./models/decoder --offline --dataset ./data/test.jsonl --calibration-dataset ./data/train.jsonl --text-column text --threads 1
```

`--bits auto` is the default for generation. It only selects lower precision
when the validation profile matches the artifact, runtime, device settings and
workload. Explicit `--bits 8` or `--bits 4` overrides are experimental.

See the [usage reference](docs/project-reference.md#2-install-and-run-with-one-command)
for aliases, cache controls, metrics, CPU pinning and custom decoder plans.
For controlled multi-core runs, [explicit worker placement](docs/worker-placement.md)
assigns a distinct allowed CPU to each decoder thread on Windows/Linux.
On Windows, use ASCII cache/artifact paths; arbitrary Unicode paths are a known
native-loader limitation.

## What is implemented?

| Area | Current capabilities |
|---|---|
| Decoder execution | Full native prefill, single-token decode, chunked evaluation and greedy generation with all declared end tokens |
| Embedding execution | FP32 EmbeddingGemma: bidirectional local/full attention, Q/K normalization, mean pooling, dense projections and L2-normalized output |
| CPU kernels | Windows FP32 packed GEMM with shared SIMD input panels and row reuse, paired GEMV, vector GELU, vector attention/softmax, and FP32/W8A8 vector SiLU gating; AVX2/FMA checks and scalar fallback; optional VNNI quantized execution |
| Memory | Memory-mapped weights, reusable activation/logit buffers, per-session KV caches with dynamic growth and reset/reuse |
| Threading | Persistent workers; optional CPU placement with bounded waits and caller-affinity restoration on Windows/Linux |
| Precision | FP32 with optional accurate accumulation; original BF16 matrix storage with FP32 computation; weight-only INT8/INT4, dynamic W8A8, smoothing and optional FP32 protection |
| Graph execution | ONNX-to-Leaf IR, constant folding, supported CNN/Transformer fusions, native operators and an optional liveness-planned arena |
| Validation | Held-out quality, reference logits, generation/cache parity, matched latency workloads and retained timing samples |

Complete trained evaluations cover **GPT-2, TinyLlama-1.1B and ResNet-20**.
**EmbeddingGemma 300M** passes trained-reference numerical checks and has a
qualified local before/after gain on one short input. The other measured inputs
remain timing-unqualified, and llama.cpp had lower observed baseline medians.
See the [full embedding results and limits](docs/embedding.md).
Reduced-model tests exercise six decoder architecture families.
SmolLM2-360M-Instruct and Qwen2.5-0.5B-Instruct use the same shared decoder;
their bounded output-quality checks and remaining strict numerical failures
are recorded in the [onboarding report](docs/model-onboarding.md#smollm2-and-qwen25--october-17-2026).

Import adapters cover supported configurations from Llama/Qwen2, GPT-2,
GPT-NeoX, OPT and dense Mistral-style blocks. Compatibility depends on operators
and tensor layouts—not just a model-family name. The causal decoder does not
yet implement scaled RoPE or Q/K normalization. Uniform causal sliding windows
are implemented and tested on reduced Mistral configurations, including a
4096-token window boundary; trained Mistral 7B has not been executed here.
The separate embedding runtime supports its bidirectional local/full attention
and Q/K normalization. MoE, encoder-decoder models and general sampling
remain unsupported. Unsupported configurations fail explicitly.

[Detailed compatibility and operator boundaries](docs/project-reference.md#3-coverage-and-explicit-boundaries)

## How it works

Models enter through a decoder/embedding snapshot or an ONNX graph. Preparation
validates their semantics and produces a versioned native artifact.

```mermaid
flowchart TB
    H["Model ID · automatic download and cache"] --> S["Safetensors snapshot"]
    S --> P["Validated decoder plan<br/>Complete end-token policy"]
    S --> B["Validated bidirectional embedding plan"]
    B --> N["C++ encoder · local/full attention and Q/K norms<br/>Finite masked-span attention · shared RoPE · vector GELU"]
    N --> V["Mean pooling · dense projections · L2 normalization"]
    V --> F["Document/query vectors"]
    O["ONNX model"] --> G["Leaf IR · constant folding and fusions"]
    P --> D["Native decoder artifact<br/>Optional original BF16 matrix storage"]
    G --> A["Native graph artifact"]
    D --> R["C++ decoder · causal full/windowed attention<br/>Reusable activations/logits and session KV cache<br/>Final-layer FP32 MLP row selection<br/>Persistent workers · optional placement and bounded waits"]
    A --> E["C++ graph executor · reusable buffers or planned arena"]
    R --> M["Compute policy<br/>FP32: fast default or accurate opt-in<br/>INT8/INT4: existing dispatch"]
    M --> K["CPU-dispatched kernels<br/>Tiled GEMM · shared input panels<br/>Optional balanced FP32 sums and wider RMS<br/>Paired GEMV · SIMD BF16-to-FP32 expansion<br/>Vector GELU, attention, softmax and SiLU"]
    K --> T["Tokens and logits"]
    E --> U["Graph outputs"]
```

The validated FP32 kernel stack and FP32/W8A8 vector SiLU gating are enabled by
default on supported Windows CPUs. FP32 SiLU covers prefill and single-token
decode; W8A8 SiLU remains prefill-only. Forced-scalar execution retains its path.
Other operating systems retain their existing defaults pending performance
qualification. The CLI uses a lightweight Python/tokenizer launcher; the native
decoder owns the generation loop. Decoder, embedding and graph artifacts use
distinct formats.

Finite masked-span attention is enabled with a **15.55% kernel-level reduction**
on the tested 669-token local-attention case. Whole-model timing did not pass
stability; this is not a model-speed or llama.cpp win. [Evidence](docs/embedding.md#finite-masked-span-attention-and-product-workflow--october-13-2026).

Quantization and new kernels are evaluated against the work they actually replace:

```mermaid
%%{init: {"flowchart": {"nodeSpacing": 24, "rankSpacing": 24}}}%%
flowchart LR
    C["Candidate +<br/>FP32 reference"] --> Q["Held-out quality<br/>Logits, cache, generation"]
    Q --> B["Matched timings<br/>Same workload"]
    B --> V{"Quality +<br/>stable speed?"}
    V -- "Yes" --> I["Qualify tested<br/>configuration"]
    V -- "No" --> H["Keep current<br/>default"]
```

A kernel may also be released after exact-output checks and stable isolated
timing, with an explicitly kernel-only claim. Failed model gates stay recorded;
this exception does not enable automatic quantization.

## Measured performance

Measurements on one Windows host, one pinned P-core,
batch one, **63-token prefill + one cached decode token**, with last-token logits.
These are warmed native-forward timings, not model loading or complete-command
latency. GPT-2 was measured through the installed runtime; TinyLlama uses the
accepted SiLU candidate. The new installed wheel passes exact output parity
against that W8A8 candidate but has not been separately timed. Runtime and source
hashes are recorded in the linked reports.

| Model / runtime | Prefill | Decode | Result |
|---|---:|---:|---|
| GPT-2 · Leaf FP32 | **144.31 ms** | 28.11 ms | Stable; **4.85% lower prefill time** than SDPA |
| GPT-2 · PyTorch SDPA FP32 | 151.66 ms | 28.57 ms | Stable reference |
| TinyLlama 1.1B · Leaf SiLU W8A8 candidate | **861.60 ms** | **91.47 ms** | Stable; **2.05× prefill / 2.31× decode speedup** over SDPA FP32 |
| TinyLlama 1.1B · PyTorch eager FP32 | 1,804.02 ms | 212.69 ms | Stable reference |
| TinyLlama 1.1B · PyTorch SDPA FP32 | 1,767.88 ms | 211.43 ms | Stable reference |

GPT-2 decode passes non-regression; its 1.62% reduction falls below the separate
2% improvement threshold. GPT-2 uses 101 measured samples per pass; TinyLlama
uses 31. Both use ten warmups and forward/reverse process order. Failures and
all samples remain available, including earlier unsuccessful experiments.

A newer [final-layer row-selection change](docs/final-layer-row-selection.md)
reduces prefill versus the previous Leaf build by **5.20% on Pythia-70M**
(56.38 → 53.45 ms) and **2.54% on GPT-2** (144.05 → 140.40 ms), with byte-identical
tested outputs, stable timings and decode within non-regression. These are
separate incremental comparisons; the table above retains the earlier matched
PyTorch measurements.

The [FP32 SiLU release](docs/silu-gate-experiment.md#fp32-follow-up--october-15-2026)
reduces TinyLlama prefill **26.69% versus the previous Leaf default**
(1,897.61 → 1,391.20 ms). All twelve passes and pooled stability checks pass,
with decode within non-regression and trained quality preserved.

A [shared FP32 decode SiLU change](docs/fp32-decode-silu.md) lowers cached decode
**5.63% on SmolLM2-360M** (83.44 → 78.74 ms) and **5.48% on Qwen2.5-0.5B**
(115.61 → 109.27 ms) versus the previous Leaf default. All 24 passes are stable,
prefill passes non-regression, and tested outputs are byte-identical. These are
incremental Leaf comparisons; the existing strict logit-tolerance misses on
these two models remain open.

A fresh [TinyLlama FP32 comparison with Ollama](docs/tinyllama-ollama-comparison.md#october-17-fp32-silu-default)
measures **9.10% lower prefill** (1,391.42 vs 1,530.64 ms) and **11.35% lower
cached decode** (222.91 vs 251.45 ms), with all timing stability checks passing.
All continuations match, but one selected-logprob error narrowly exceeds the
unchanged tolerance. These remain diagnostic timings, not an overall qualified win.

TinyLlama W8A8 is a quality tradeoff: **95.08% next-token agreement**, **1.24%
higher held-out perplexity**, and non-identical generated text. Its artifact is
**1.10 GB versus 4.40 GB** for FP32. This is an artifact-size reduction from
quantization, not a measured PyTorch process-memory comparison or model pruning.

- [GPT-2 release, quality and performance evidence](docs/windows-attention-softmax.md)
- [TinyLlama SiLU release, fresh comparison and quality limits](docs/silu-gate-experiment.md)
- [Earlier TinyLlama evaluation and retained failures](docs/windows-tinyllama-current.md)
- [Pythia-70M vs llama.cpp: diagnostic timings, fidelity differences and next steps](docs/pythia-runtime-comparison.md)
- [Complete benchmark history and retained failures](docs/project-reference.md#7-current-trained-model-and-dataset-results)

## Scope and next steps

Leaf targets supported smaller trained models on local CPUs, particularly for
people without GPU access. Windows is the current performance-validation focus;
portable correctness CI runs on Windows, Linux and macOS. CI success does not
establish equivalent performance across those systems.

The [Windows W8A8 SiLU release](docs/silu-gate-experiment.md) passes correctness,
stable incremental acceptance and installed-package checks: **37.94% lower
prefill time than the previous Leaf W8A8 path** (1320.31 → 819.38 ms), with decode
passing non-regression. FP32 SiLU now passes its separate native acceptance
gate and is integrated. The final-layer
attention extension and [exact-erf GELU experiment](docs/gemm-activation-followup.md#exact-erf-gelu-experiment--october-15-2026)
retain passing output checks but unqualified whole-model timings. The
[TinyLlama/Ollama comparison](docs/tinyllama-ollama-comparison.md) has stable
diagnostic timings with lower Leaf prefill and decode latency on the new FP32
default; its probability tolerance miss remains open. A reproduced
[diagnostic startup-affinity race](docs/windows-timing-diagnosis.md#october-15-2026-diagnostic-startup-race)
is fixed before further kernel changes or model downloads.
An isolated [shared accumulation candidate](docs/shared-accumulation.md) now
passes the full SmolLM2/Qwen2.5 fidelity checks without relaxed tolerances.
It is available through `--fp32-math accurate`; it remains outside the default
math policy while its performance cost is evaluated.
Optional [original BF16 head storage](docs/source-bf16.md) preserves FP32 compute
and exact tested outputs. Against that accurate candidate's FP32 storage, it
reduces paired decode latency **5.12% on SmolLM2** and **11.65% on Qwen2.5**,
with stable timings and prefill non-regression. These are incremental Leaf results.
Quantized vector attention and broader matched runtime comparisons remain open.

Further work includes broader quality datasets, complete-command latency,
independent CPU/Linux evaluation, and compatible small Qwen, Mistral, Granite
and Gemma-family workloads. The [embedding validation plan](docs/embedding.md)
starts with retrieval quality and matched CPU comparisons before expanding
toward 10–15 trained models. Structured pruning remains future work; training
and GPU deployment are outside the current scope.

**Dataset acceleration means faster model inference over a collection:**
embedding documents for search, classifying images, or scoring examples. Measure
documents/images per second, peak memory and total job time at matched quality.
Leaf does not currently claim faster dataset loading, augmentation or training.

## Development and contributing

Bug reports, reproducible workloads, compatibility improvements and measured
kernel changes are welcome through [issues](https://github.com/Nbit-51/Leaf/issues)
and pull requests. Include the model/configuration, OS, CPU, runtime revision,
quality checks and retained samples with performance claims.

```sh
python -m pip install -r requirements-dev.txt
python -m pytest -q --basetemp build/pytest
cmake -S . -B build/cmake -DCMAKE_BUILD_TYPE=Release
cmake --build build/cmake --config Release
ctest --test-dir build/cmake -C Release --output-on-failure
```

Windows also provides `./scripts/verify_all.ps1` for the repository gate.
Trained-model runs require local model/data assets and are separate from the
automated suite. The SiLU release passed **870 Python tests**, nine reduced
architecture cases, ten trained-model parity checks, and installed-wheel offline
checks. Detailed evidence is linked above.

[Build and validation guide](docs/project-reference.md#6-reproduce-validation-and-benchmarks) ·
[Benchmark directory guide](benchmark/README.md) ·
[Architecture and artifact reference](docs/project-reference.md#4-architecture) ·
[Documentation index](docs/README.md)

## License

[Apache License 2.0](LICENSE).
