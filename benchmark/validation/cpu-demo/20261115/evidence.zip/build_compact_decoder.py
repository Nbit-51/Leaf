"""Test bounded BF16-to-FP32 expansion once per long prefill projection."""

from pathlib import Path
import subprocess


root = Path(__file__).resolve().parent
previous = root.parent / 'embedding-gemm-20261112'
source = (previous / 'decoder_combined.cpp').read_text(encoding='utf-8')
member = '    leaf::kernels::TokenPanelsF32 packed_float_input;'
old = '''        if (multi_threaded && packed_float && optimized_fp32 && !accurate_fp32 &&
            weight.bits == 32 && tokens >= 768) {
            workers.run(packed_float_input.panels(), [&](std::size_t first, std::size_t last) {
                leaf::kernels::row_reuse_detail::gemm(
                    reinterpret_cast<const float*>(weight.data), weight.rows, weight.cols, weight.cols,
'''
new = '''        // Keep the model in its original BF16 storage. Materialize only one
        // bounded projection for long prefill so workers can own token panels.
        constexpr std::size_t max_expanded_values = (32 * 1024 * 1024) / sizeof(float);
        const bool compact_panels = weight.bits == 16 && weight.rows <= max_expanded_values / weight.cols;
        if (multi_threaded && packed_float && optimized_fp32 && !accurate_fp32 &&
            (weight.bits == 32 || compact_panels) && tokens >= 768) {
            const float* panel_weights = reinterpret_cast<const float*>(weight.data);
            if (compact_panels) {
                expanded_prefill_weights.resize(weight.rows * weight.cols);
                const auto* stored = reinterpret_cast<const std::uint16_t*>(weight.data);
                workers.run(weight.rows, [&](std::size_t first, std::size_t last) {
                    const auto offset = first * weight.cols;
                    leaf::kernels::expand_source_bf16(stored + offset, expanded_prefill_weights.data() + offset,
                                                     (last - first) * weight.cols, avx);
                }, 32);
                panel_weights = expanded_prefill_weights.data();
            }
            workers.run(packed_float_input.panels(), [&](std::size_t first, std::size_t last) {
                leaf::kernels::row_reuse_detail::gemm(
                    panel_weights, weight.rows, weight.cols, weight.cols,
'''
assert source.count(member) == source.count(old) == 1
source = source.replace(member, member + '\n    std::vector<float> expanded_prefill_weights;')
edited = root / 'decoder_compact.cpp'
edited.write_text(source.replace(old, new), encoding='utf-8')
flags = ['g++', '-std=c++17', '-O3', '-DNDEBUG', '-pthread', '-static', '-static-libgcc', '-static-libstdc++',
         '-I', str(previous/'include'), '-I', 'engine/include']
obj = root / 'decoder_compact.o'
subprocess.run(flags + ['-c', str(edited), '-o', str(obj)], check=True)
for entry, final in (('engine/src/main_decoder.cpp','compact_decoder.exe'),
                     ('benchmark/decoder_generation_benchmark.cpp','compact_adapter.exe')):
    subprocess.run(flags + [str(obj), 'engine/src/kv_cache.cpp', 'engine/src/kernels/transformer.cpp',
                            entry, '-o', str(root/final), '-lpsapi'], check=True)
