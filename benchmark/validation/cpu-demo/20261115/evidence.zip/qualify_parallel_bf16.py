"""Build and check the production-scoped long-context BF16 implementation."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace

import numpy as np
from tokenizers import Tokenizer

from tools.benchmark_ollama_decoder import leaf_pass, prefix_workloads
from tools.decoder_validation import run_native
from tools.validate_decoder import digest


root = Path(__file__).resolve().parent
build = root / 'release-candidate'
build.mkdir(exist_ok=True)
scratch = build / 'tmp'
scratch.mkdir(exist_ok=True)
tempfile.tempdir = str(scratch)
baseline = root/'venv/Lib/site-packages/leaf/bin/leaf_decoder.exe'
baseline_adapter = root.parent/'embedding-packing-20261111/leaf-generation-benchmark.exe'
candidate = build/'leaf_decoder.exe'
candidate_adapter = build/'generation_adapter.exe'
flags = ['g++', '-std=c++17', '-O3', '-DNDEBUG', '-pthread', '-static',
         '-static-libgcc', '-static-libstdc++', '-I', 'engine/include']
obj = build/'decoder.o'
subprocess.run(flags+['-c', 'engine/src/decoder.cpp', '-o', str(obj)], check=True)
for entry, output in (('engine/src/main_decoder.cpp', candidate),
                      ('benchmark/decoder_generation_benchmark.cpp', candidate_adapter)):
    subprocess.run(flags+[str(obj), 'engine/src/kv_cache.cpp', 'engine/src/kernels/transformer.cpp',
                          entry, '-o', str(output), '-lpsapi'], check=True)
native_test = build/'token_panel_test.exe'
subprocess.run(flags+['tests/native/test_token_panel.cpp', '-o', str(native_test)], check=True)
subprocess.run([str(native_test)], check=True)

cpus = [0, 2, 4, 6]
previous = root.parent/'family-models-20261017/cache/hub'
report = dict(complete=False, passed=False, hashes={str(x.resolve()):digest(x) for x in (
    baseline, candidate, baseline_adapter, candidate_adapter,
    Path('engine/src/decoder.cpp'), Path('engine/include/leaf/kernels/row_reuse.h'),
)}, models={})
for name, alias in (('smol', 'HuggingFaceTB--SmolLM2-360M-Instruct'), ('qwen', 'Qwen--Qwen2.5-0.5B-Instruct')):
    path = root/(name+'-source-bf16')/'decoder-32-source-bf16.leaf'
    report['hashes'][str(path.resolve())] = digest(path)
    tokenizer_path, = (previous/('models--'+alias)/'snapshots').glob('*/tokenizer.json')
    tokenizer = Tokenizer.from_file(str(tokenizer_path))
    lengths = (511, 767, 768, 781) if name == 'smol' else (768, 781)
    verified = []
    for prefix in lengths:
        rows, _ = prefix_workloads(tokenizer, prefix+1)
        ids = rows[0]['ids']
        hashes = []
        for binary in (baseline, candidate):
            logits, _ = run_native(binary, path, [ids], mode='chunked', chunk=prefix, threads=4,
                                   worker_cpus=cpus)
            assert np.isfinite(logits).all()
            hashes.append(hashlib.sha256(memoryview(logits).cast('B')).hexdigest())
            count = len(logits)
            del logits
        assert hashes[0] == hashes[1], (name, prefix)
        verified.append(dict(prefill_tokens=prefix, cached_decode_forwards=1,
                             values=count, logits_sha256=hashes[0]))
        if prefix == 768:
            (build/(name+'-tokens.json')).write_text(json.dumps(dict(benchmark_ids=ids))+'\n')
        print(name, prefix, 'full logits exact:', count, flush=True)
    rows, cached = prefix_workloads(tokenizer, 768)
    results = [
        leaf_pass(SimpleNamespace(cpus=cpus, threads=4, leaf_executable=adapter, leaf_artifact=path),
                  rows, build/(name+'-'+side), maximum=64, quality=True, cached=cached)
        for side, adapter in (('before', baseline_adapter), ('after', candidate_adapter))
    ]
    assert all(len(x['generated_tokens']) == len(y['generated_tokens']) == 64 and
               x['generated_tokens'] == y['generated_tokens'] and x['selected_logprobs'] == y['selected_logprobs']
               for x, y in zip(*results))
    report['models'][name] = dict(full_logits=verified, generation_token_counts=[64,64],
                                   generation_and_selected_logprobs_exact=True)
    print(name, 'both 64-token continuations and probabilities exact', flush=True)
report.update(complete=True, passed=True)
(build/'quality.json').write_text(json.dumps(report, indent=2)+'\n')
