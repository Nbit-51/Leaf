"""Audit source-BF16 storage and real 768-token trained continuations."""

import hashlib
import json
from pathlib import Path
import shutil
import tempfile
from types import SimpleNamespace

import numpy as np
from tokenizers import Tokenizer

from tools.benchmark_ollama_decoder import leaf_pass, prefix_workloads
from tools.decoder_validation import run_native
from tools.validate_decoder import digest, write_export_provenance
from tools.validate_source_bf16_matrices import audit_payloads


root = Path('build/presentation-20261115').resolve()
scratch = root / 'storage-tmp'
scratch.mkdir(exist_ok=True)
tempfile.tempdir = str(scratch)
previous = Path('build/embedding-gemm-20261112').resolve()
hub = Path('build/family-models-20261017/cache/hub')
record = dict(complete=False, models={},
              runtime_sha256={path.name: digest(path) for path in (
                  previous/'combined_decoder.exe', previous/'combined_adapter.exe',
                  root/'compact_decoder.exe', root/'compact_adapter.exe', root/'decoder_compact.cpp')})
for name, alias in (('smol', 'HuggingFaceTB--SmolLM2-360M-Instruct'), ('qwen', 'Qwen--Qwen2.5-0.5B-Instruct')):
    source = Path('build/source-bf16-timing-20261108/trained') / name
    original = Path('build/ollama-family-20261019') / name / 'decoder-32.leaf'
    provenance = json.loads(original.with_suffix('.provenance.json').read_bytes())
    snapshot, = (hub / ('models--' + alias) / 'snapshots').iterdir()
    assert provenance['request']['source_weight_sha256'] == {'model.safetensors': digest(snapshot / 'model.safetensors')}
    assert provenance['artifact_sha256'] == digest(original)
    compact = source / 'decoder-32-source-bf16.leaf'
    audit = audit_payloads(original, compact, json.loads((source / 'export.json').read_bytes()))
    directory = root / (name + '-source-bf16')
    directory.mkdir(exist_ok=True)
    candidate = directory / 'decoder-32-source-bf16.leaf'
    shutil.copyfile(compact, candidate)
    write_export_provenance(candidate, dict(provenance['request'],
                                          source_bf16_storage='matrices', source_bf16_tensors=audit['bf16_names']))
    tok = Tokenizer.from_file(str(snapshot / 'tokenizer.json'))
    rows, cached = prefix_workloads(tok, 768)
    hashes = []
    for binary, artifact in ((previous / 'combined_decoder.exe', original), (root / 'compact_decoder.exe', candidate)):
        logits, _ = run_native(binary, artifact, [rows[0]['ids']],
                               mode='chunked', chunk=768, threads=4, worker_cpus=[0, 2, 4, 6])
        assert np.isfinite(logits).all()
        hashes.append(hashlib.sha256(memoryview(logits).cast('B')).hexdigest())
        count = len(logits)
        del logits
    common = dict(cpus=[0, 2, 4, 6], threads=4)
    continuations = [
        leaf_pass(SimpleNamespace(**common, leaf_executable=adapter, leaf_artifact=artifact), rows, directory / side,
                  maximum=64, quality=True, cached=cached)
        for side, adapter, artifact in (('fp32', previous/'combined_adapter.exe', original),
                                        ('source-bf16', root/'compact_adapter.exe', candidate))
    ]
    exact_tokens = all(a['generated_tokens'] == b['generated_tokens'] for a, b in zip(*continuations))
    max_error = max(abs(x-y) for a,b in zip(*continuations)
                    for x,y in zip(a['selected_logprobs'], b['selected_logprobs']))
    record['models'][name] = dict(audit=audit, weights_sha256=digest(candidate), logits_values=count,
                                  bit_exact_logits=hashes[0] == hashes[1], logit_hashes=hashes,
                                  exact_generated_tokens=exact_tokens,
                                  generated_token_counts=[len(r['generated_tokens']) for r in continuations[0]],
                                  selected_logprob_max_abs_error=max_error)
    print(name, count, hashes[0] == hashes[1], exact_tokens, max_error, flush=True)
    (root / 'storage-quality.json').write_text(json.dumps(record, indent=2) + '\n')
record['complete'] = True
(root / 'storage-quality.json').write_text(json.dumps(record, indent=2) + '\n')
