"""Apply the unchanged Leaf release gates to the same-artifact comparison."""

import json
from pathlib import Path


root = Path(__file__).resolve().parent / 'release-candidate'
quality = json.loads((root/'quality.json').read_bytes())
assert quality['complete'] and quality['passed']
models = {}
for name in ('smol', 'qwen'):
    data = json.loads((root/(name+'-paired')/'comparison.json').read_bytes())
    assert data['complete'] and data['inputs_unchanged'] and data['power_mode']['passed']
    assert data['before_math'] == data['after_math'] == 'fast'
    assert data['worker_cpus'] == [0, 2, 4, 6] and not data['counters_enabled']
    assert data['artifacts']['before'] == data['artifacts']['after']
    assert data['hashes'][data['artifacts']['after']] == quality['hashes'][data['artifacts']['after']]
    assert all(data['hashes'][p] == quality['hashes'][p] for p in data['binaries'].values())
    assert data['request'] == dict(token_count=769, prefill_tokens=768, decode_tokens=1,
                                   reset_each_sample=True, all_token_logits=False)
    assert data['pairs'] == 6 and data['runs'] == 5 and data['warmup'] == 2
    assert len(data['passes']) == 12
    for index, part in enumerate(data['passes']):
        order = ('before', 'after') if (index // 2) % 2 == 0 else ('after', 'before')
        assert part['validated'] and part['pair'] == index // 2 and part['stage'] == order[index % 2]
        assert part['ac_before']['ac_line_status'] == part['ac_after']['ac_line_status'] == 1
    phases = {}
    for phase, limit in (('prefill', .98), ('decode', 1.02)):
        values = data['summary'][phase]
        phases[phase] = dict(medians_ms=values['medians_ms'], stable=values['stable'],
                             paired_ratio=values['median_paired_ratio'], pooled_ratio=values['pooled_ratio'],
                             passed=values['stable'] and max(values['median_paired_ratio'], values['pooled_ratio']) <= limit)
    models[name] = phases
report = dict(passed=all(phase['passed'] for phases in models.values() for phase in phases.values()),
              models=models, scope='Same source-BF16 artifact and fast FP32 math; candidate changes dispatch only.')
(root/'release-gates.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
