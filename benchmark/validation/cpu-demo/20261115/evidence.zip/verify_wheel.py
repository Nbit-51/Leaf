"""Check all three native workflows from the installed Windows wheel."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import numpy as np


root = Path(__file__).resolve().parent
repo = root.parents[1]
work = root / 'wheel-smoke'
venv = root / 'venv'
optimized = sys.argv[1:] == ['optimized']
wheel_directory = 'optimized-wheel' if optimized else 'final-wheel'
if optimized:
    work = root / 'optimized-wheel-smoke'
    venv = root / 'optimized-venv'
work.mkdir()
wheel, = (root / wheel_directory).glob('*.whl')
python = venv / 'Scripts/python.exe'
leaf = venv / 'Scripts/leaf.exe'
subprocess.run([sys.executable, '-m', 'venv', '--system-site-packages', str(venv)], check=True)
subprocess.run([str(python), '-m', 'pip', 'install', '--no-deps', '--ignore-installed', str(wheel)], check=True)
env = {k: v for k, v in os.environ.items() if not k.startswith('LEAF_') and k not in ('PYTHONPATH', 'CXX', 'CC')}
env.update(PATH=os.pathsep.join((str(leaf.parent), str(Path(os.environ['SystemRoot']) / 'System32'))),
           LEAF_CACHE_DIR=str(work / 'cache'), HF_HUB_OFFLINE='1')
assert all(shutil.which(name, path=env['PATH']) is None for name in ('g++', 'clang++', 'cl'))


def run(binary, *args):
    result = subprocess.run([str(binary), *map(str, args)], cwd=work, env=env,
                            capture_output=True, encoding='utf-8')
    if result.returncode:
        raise RuntimeError(result.stderr + result.stdout)
    return result


doctor = json.loads(run(leaf, 'doctor').stdout)
assert all(r['selection'] == 'bundled' for r in doctor['runtimes'].values())
snapshot, = (repo / 'build/family-models-20261017/cache/hub/models--HuggingFaceTB--SmolLM2-360M-Instruct/snapshots').iterdir()
metrics = work / 'generation.json'
generation = run(leaf, 'run', snapshot, '--offline', '--bits', 32, '--prompt',
                 'Give three reasons to run a small language model locally.', '--max-tokens', 32, '--metrics', metrics)
assert generation.stdout.strip()
compact = None
if optimized:
    read = lambda path: json.loads(path.read_bytes())
    request = read(root/'smol-source-bf16-vs-ollama/comparison.json')['workload'][0]['prompt']
    expected_ids = json.loads((root/'release-candidate/smol-after/results.jsonl').read_bytes().splitlines()[0])['generated_tokens']
    run(leaf, 'run', snapshot, '--offline', '--bits', 32, '--source-bf16', '--raw', '--prompt', request,
        '--max-tokens', 64, '--threads', 4, '--worker-cpus', 0, 2, 4, 6, '--metrics', 'source-bf16.json')
    compact = read(work/'source-bf16.json')
    assert compact['generated_tokens'] == expected_ids and compact['worker_cpus'] == [0, 2, 4, 6]
    assert compact['source_bf16_tensors'] > 0 and compact['source_bf16_linear_calls'] > 0
    assert compact['optimized_fp32_active'] and compact['activation_bits'] == 32

net = repo / 'build/cifar10_full'
array = np.fromfile(net / 'inputs.bin', dtype='<f4', count=3072).reshape(1, 3, 32, 32)
expected = np.fromfile(net / 'expected.bin', dtype='<f4', count=10).reshape(1, 10)
np.save(work / 'image.npy', array, allow_pickle=False)
run(leaf, 'infer', net / 'resnet20.onnx', '--input', 'image.npy', '--output', 'logits.npy')
observed = np.load(work / 'logits.npy', allow_pickle=False)
np.testing.assert_allclose(observed, expected, rtol=1e-3, atol=1e-3)
assert observed.argmax() == expected.argmax()

pilot = repo / 'build/trained-operator-validation-20261109-211516/scifact'
embedding = repo / 'build/models/embeddinggemma-300m'
common = ('index', embedding, '--offline', '--threads', 4, '--chunk-size', 16)
docs = (*common, '--dataset', pilot/'documents.jsonl', '--directory', 'docs', '--task', 'raw')
queries = (*common, '--dataset', pilot/'queries.jsonl', '--directory', 'queries', '--task', 'query')
stopped = run(leaf, *docs, '--max-new-chunks', 1)
assert '"complete": false' in stopped.stdout
resumed = run(leaf, *docs)
assert '"complete": true' in resumed.stdout and '"new_chunks": 1' in resumed.stdout
run(leaf, *queries)
run(python, '-m', 'tools.evaluate_retrieval', '--query-rows', pilot/'queries.jsonl',
    '--document-rows', pilot/'documents.jsonl', '--query-vectors', 'queries/embeddings.npy',
    '--document-vectors', 'docs/embeddings.npy', '--qrels', pilot/'test.tsv', '--k', 10,
    '--output', 'retrieval.json')
retrieval = json.loads((work / 'retrieval.json').read_bytes())
reference = json.loads((pilot / 'leaf-retrieval.json').read_bytes())
ranking = lambda report: [[r['document_id'] for r in row['results']] for row in report['queries']]
assert ranking(retrieval) == ranking(reference)
record = dict(wheel=wheel.name, wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
              compiler_on_path=False, generation=json.loads(metrics.read_bytes()),
              graph=dict(shape=observed.shape, predicted_class=int(observed.argmax()),
                         max_abs_error=float(np.max(np.abs(observed-expected)))),
              retrieval={key: retrieval[key] for key in ('document_count','query_count','ndcg','recall')},
              first_batch_reused=True, saved_ranking_matches=True)
if optimized:
    record['source_bf16_generation'] = compact
    record['accepted_artifact_tokens_match'] = True
(root / (work.name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print('Generation:', generation.stdout.strip())
print('Graph:', record['graph'])
print('Retrieval:', record['retrieval'])
