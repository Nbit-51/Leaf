"""Rerun the unchanged SmolLM2 256 -> 16 Ollama workload with the candidate."""
import subprocess
import sys
from pathlib import Path

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake

work = Path(__file__).resolve().parent
build = work.parent
previous = build/"ollama-validation-20261116"
family = build/"ollama-family-20261019"
model = build/"presentation-20261115/smol-source-bf16"
snapshot = build/"family-models-20261017/cache/hub/models--HuggingFaceTB--SmolLM2-360M-Instruct/snapshots/a10cc1512eabd3dde888204e902eca88bddb4951"
output = work/"ollama-comparison"
power = {}
result = dict(power_mode=power, exit_code=None)
try:
    with keep_awake(), benchmark_power_mode_guard(power, required_mode="better-battery"):
        done = subprocess.run([
            sys.executable, "-m", "tools.benchmark_ollama_decoder",
            "--ollama-executable", str(previous/"latest/runtime/ollama.exe"),
            "--ollama-models", str(family/"models"), "--ollama-model", "leaf-smollm2-360m-f32",
            "--leaf-executable", str(work/"adapter.exe"),
            "--leaf-artifact", str(model/"decoder-32-source-bf16.leaf"),
            "--leaf-fp32-reference", str(family/"smol/decoder-32.leaf"),
            "--snapshot", str(snapshot), "--gguf-audit", str(family/"smol/gguf-audit.json"),
            "--worker-cpus", "0", "2", "4", "6", "--prompt-tokens", "256",
            "--generated-tokens", "16", "--output", str(output), "--diagnostic-timing",
        ])
        result["exit_code"] = done.returncode
finally:
    write_record(work/"ollama-power.json", result)
sys.exit(result["exit_code"])
