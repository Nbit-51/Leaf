"""Check source-BF16 scheduling at the 256-token dispatch boundary."""
import hashlib
import json
import os
from pathlib import Path
from statistics import median
import tempfile

import numpy as np
import psutil

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest


work = Path(__file__).resolve().parent
build = work.parent
tempfile.tempdir = str(work)
binaries = {
    "before": build/"scalar-prefill-20261116/venv/Lib/site-packages/leaf/bin/leaf_decoder.exe",
    "after": work/"attention-only.exe",
}
prev = build/"presentation-20261115"
smol_request = json.loads((build/"ollama-validation-20261116/smol-256-16-latest/comparison.json").read_bytes())["workload"][0]["ids"]
qwen = json.loads((prev/"release-candidate/qwen-tokens.json").read_bytes())["benchmark_ids"]
models = {
    "SmolLM2-360M": (prev/"smol-source-bf16/decoder-32-source-bf16.leaf", [*smol_request, *smol_request[:3]]),
    "Qwen2.5-0.5B": (prev/"qwen-source-bf16/decoder-32-source-bf16.leaf", qwen),
}
models = {"SmolLM2-360M": models["SmolLM2-360M"]}
report = dict(complete=False, scope=__doc__, affinity=[0,2,4,6], power_mode={}, cases={},
              binary_sha256={name:digest(exe) for name,exe in binaries.items()},
              candidate_source_sha256=digest(work/"decoder-attention-only.cpp"))
output = work/"attention-only.json"
process = psutil.Process()
original = process.cpu_affinity()


def bit_digest(values):
    assert np.isfinite(values).all()
    return dict(count=int(values.size), sha256=hashlib.sha256(memoryview(values).cast("B")).hexdigest())


try:
    process.cpu_affinity(report["affinity"])
    assert process.cpu_affinity() == report["affinity"]
    for name,(artifact,seq) in models.items():
        case = dict(artifact_sha256=digest(artifact), exact={}, pairs=[])
        report["cases"][name] = case
        for length in (255,256,257):
            fixture = seq[:length+1]
            assert len(fixture) == length+1
            values = [bit_digest(run_native(exe, artifact, [fixture], mode="chunked",
                                           threads=4, chunk=length, fp32_math="fast")[0])
                      for exe in binaries.values()]
            assert values[0] == values[1], (name,length)
            case["exact"][str(length)] = values[0]
        outputs = [run_native(exe, artifact, [seq[:256]], mode="generate",
                              threads=4, generate=16, fp32_math="fast")[1]["generated_tokens"]
                   for exe in binaries.values()]
        assert outputs[0] and outputs[0] == outputs[1]
        case["exact_continuation"] = outputs[0]
        print(name, "matched logits at 255/256/257", flush=True)
        write_record(output,report)
    os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
    with keep_awake(), benchmark_power_mode_guard(report["power_mode"], required_mode="better-battery"):
        for name,(artifact,seq) in models.items():
            case = report["cases"][name]
            for index in range(6):
                order = ("before","after") if index%2==0 else ("after","before")
                pair = dict(order=order)
                for side in order:
                    _, m = run_native(binaries[side],artifact,[seq[:257]], mode="bench",threads=4,
                                      runs=5,warmup=2,fp32_math="fast")
                    assert m["benchmark_ac_checked"] and m["avx2"] and m["source_bf16_linear_calls"] > 0
                    pair[side] = dict(prefill=m["prefill_samples_ms"],decode=m["decode_samples_ms"],
                                      peak_rss_bytes=m["peak_rss_bytes"])
                case["pairs"].append(pair)
                print(name, index+1, *(round(median(pair[s]["prefill"]),2) for s in binaries), flush=True)
                write_record(output, report)
            case["summary"] = {}
            for phase,limit in (("prefill",.98),("decode",1.02)):
                rows = {side:[p[side][phase] for p in case["pairs"]] for side in binaries}
                pooled = {side:sum(samples,[]) for side,samples in rows.items()}
                stable = all(latency_stability(r)["passed"] for groups in
                             (*rows.values(), list(pooled.values())) for r in groups)
                ratio = median(median(a)/median(b) for b,a in zip(rows["before"], rows["after"]))
                case["summary"][phase] = dict(medians_ms={s:median(r) for s,r in pooled.items()},
                                             paired_ratio=ratio,stable=stable,passed=stable and ratio<=limit)
            print(name,case["summary"],flush=True)
            assert case["artifact_sha256"] == digest(artifact)
    assert report["binary_sha256"] == {name:digest(exe) for name,exe in binaries.items()}
    report["complete"] = True
finally:
    process.cpu_affinity(original)
    write_record(output,report)
