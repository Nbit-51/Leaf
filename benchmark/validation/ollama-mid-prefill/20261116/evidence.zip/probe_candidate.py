"""Record operation timings and Windows CPU accounting for the 256-token candidate."""
import json
import os
from pathlib import Path
from statistics import median
import tempfile

import psutil

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake
from tools.decoder_validation import run_native

work = Path(__file__).resolve().parent
build = work.parent
tempfile.tempdir = str(work)
request = json.loads((build/"ollama-validation-20261116/smol-256-16-latest/comparison.json").read_bytes())["workload"][0]["ids"]
artifact = build/"presentation-20261115/smol-source-bf16/decoder-32-source-bf16.leaf"
exes = {"before": build/"scalar-prefill-20261116/venv/Lib/site-packages/leaf/bin/leaf_decoder.exe",
        "after": work/"decoder.exe"}
os.environ.update(LEAF_DECODER_PROFILE="1",LEAF_BENCHMARK_REQUIRE_AC="1")
verification = dict(power_mode={}, readings={})
parent = psutil.Process()
original = parent.cpu_affinity()
try:
    parent.cpu_affinity([0,2,4,6])
    with keep_awake(), benchmark_power_mode_guard(verification["power_mode"], required_mode="better-battery"):
        for side,exe in exes.items():
            _, m=run_native(exe,artifact,[[*request, request[0]]],mode="bench",threads=4,runs=5,warmup=2,
                            capture_profile=True,benchmark_counters=True)
            verification["readings"][side]=m
            p=m["diagnostic_profile"]["timings"]["prefill"]
            print(side,{k:round(v["milliseconds"]/7,2) for k,v in p.items() if k in ("forward","attention","linear_fp32")},
                  "median process cycles",median(m["benchmark_counters"]["prefill"]["process_cycles"]),flush=True)
finally:
    parent.cpu_affinity(original)
    write_record(work/"candidate-profile.json",verification)
