#define main benchmark_original_main
#include "initial-gemm_alignment_benchmark.cpp"
#undef main

__attribute__((noinline)) float library_oracle(const float* w, const float* x, std::size_t k) {
    float value = 0;
    for (std::size_t c = 0; c < k; ++c) value = std::fma(w[c], x[c], value);
    return value + 0.0f;
}
__attribute__((target("avx2,fma"),noinline)) float hardware_oracle(const float* w, const float* x, std::size_t k) {
    float value = 0;
    for (std::size_t c = 0; c < k; ++c) value = std::fma(w[c], x[c], value);
    return value + 0.0f;
}
std::uint32_t bits(float v) { std::uint32_t b; std::memcpy(&b,&v,4); return b; }
int main() {
    constexpr std::size_t tokens=63,rows=2560,columns=960;
    std::vector<float> x(tokens*columns),w(rows*columns),y(tokens*rows);
    for (std::size_t i=0;i<x.size();++i)x[i]=float(int((i*17+3)%101)-50)/53.0f;
    for (std::size_t i=0;i<w.size();++i)w[i]=float(int((i*13+7)%97)-48)/71.0f;
    leaf::kernels::TokenPanelsF32 panels; panels.pack(x.data(),tokens,columns,columns,true);
    leaf::kernels::gemm_token_panels_f32_row_reuse(w.data(),rows,columns,columns,panels,y.data(),rows);
    for (auto t: {0U,1U,7U,31U,61U,62U})for(auto r:{0U,1U,5U,1280U,2558U,2559U}) {
        const auto lib=library_oracle(w.data()+r*columns,x.data()+t*columns,columns);
        const auto hw=hardware_oracle(w.data()+r*columns,x.data()+t*columns,columns);
        const auto simd=y[t*rows+r];
        std::cout<<"t="<<t<<" r="<<r<<std::hex<<" library="<<bits(lib)<<" hw="<<bits(hw)<<" simd="<<bits(simd)<<std::dec<<'\n';
        if(bits(hw)!=bits(simd))return 2;
    }
}
