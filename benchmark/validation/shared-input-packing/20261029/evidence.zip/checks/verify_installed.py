"""Compiler-free installed wheel must support accurate math and compact storage together."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

root=Path(__file__).resolve().parents[2]
directory=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
spec=importlib.util.spec_from_file_location('compact_fixture',root/'tests/unit/test_source_bf16.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
before,_,_=fixture.fixture_model(directory/'installed-model')
from tokenizers import Tokenizer,models,pre_tokenizers
tokenizer=Tokenizer(models.WordLevel({'[UNK]':0,**{f'tok{i}':i for i in range(1,101)}},unk_token='[UNK]'))
tokenizer.pre_tokenizer=pre_tokenizers.Whitespace()
tokenizer.save(str(before.parent/'tokenizer.json'))
installed=directory/'installed'
environment={k:v for k,v in os.environ.items() if k not in
 ('LEAF_DECODER_BIN','LEAF_EMBED_BIN','CXX','PYTHONPATH','PYTHONHOME','LEAF_DECODER_PROFILE') and not k.startswith('LEAF_EXPERIMENTAL_')}
environment.update(PATH=str(Path(os.environ['SystemRoot'])/'System32'),
 LEAF_CACHE_DIR=str(directory/'installed-cache'),HF_HUB_OFFLINE='1',
 TEMP=str(directory/'wheel-scratch'),TMP=str(directory/'wheel-scratch'))
code="""import sys
from pathlib import Path
installed=Path(sys.argv.pop(1));sys.path.insert(0,str(installed))
import leaf.cli
assert Path(leaf.cli.__file__).is_relative_to(installed)
assert leaf.cli.executable(leaf.cli.cache_root()).is_relative_to(installed)
sys.argv[0]='leaf'
assert leaf.cli.main()==0
assert not any(m in sys.modules for m in ('torch','transformers'))
"""
records=[]
for arguments in [['doctor'],['run',str(before.parent),'--offline','--bits','auto',
 '--source-bf16-head','--fp32-math','accurate','--threads','2','--worker-cpus','0','1',
 '--raw','--prompt','tok5 tok6 tok7','--max-tokens','2','--metrics',str(directory/'installed-metrics.json')]]:
    completed=subprocess.run([sys.executable,'-I','-c',code,str(installed),*arguments],
      env=environment,cwd=directory,check=True,capture_output=True,text=True,timeout=60)
    records.append(dict(arguments=arguments,stdout=completed.stdout,stderr=completed.stderr))
m=json.loads((directory/'installed-metrics.json').read_text())
assert m['reusable_logits'] is True
assert m['fp32_math']=='accurate' and m['source_bf16_tensors']==2 and m['source_bf16_linear_calls']>0
assert m['weight_bits']==m['activation_bits']==32 and m['worker_cpus']==[0,1]
wheel=next((directory/'wheels').glob('*.whl'))
with zipfile.ZipFile(wheel) as z:
    assert any(n.endswith('/leaf/kernels/accurate_fp32.h') for n in z.namelist())
record=dict(passed=True,timing_qualified=False,compiler_path_removed=True,decoder_override_removed=True,
 isolated_installed_import=True,torch_transformers_not_imported=True,records=records,metrics=m)
(directory/'installed-check.json').write_text(json.dumps(record,indent=2)+'\n')
print('PASS installed wheel: accurate FP32 + source BF16 + explicit workers; offline, no compiler/overrides/Torch')
