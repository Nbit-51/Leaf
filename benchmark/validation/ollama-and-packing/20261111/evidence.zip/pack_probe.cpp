#include "leaf/kernels/token_panel.h"
#include <chrono>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <vector>

using leaf::kernels::TokenPanelsF32;
using Clock = std::chrono::steady_clock;

double measure(TokenPanelsF32& packed, const float* hidden, const float* gate,
               std::size_t tokens, bool reused, volatile float& observed) {
    const auto start = Clock::now();
    for (int repetition = 0; repetition < 40; ++repetition) {
        const auto copies = reused ? 3 : 6;
        for (int call = 0; call < copies; ++call) {
            packed.pack(hidden, tokens, 768, 768, reused);
            observed = packed.panel(repetition % packed.panels())[call];
        }
        packed.pack(gate, tokens, 1152, 1152, reused);
        observed = packed.panel(repetition % packed.panels())[repetition];
    }
    return std::chrono::duration<double, std::milli>(Clock::now() - start).count() / 40;
}

int main() {
    if (!leaf::kernels::token_panel_f32_avx2_available()) return 2;
    volatile float observed = 0;
    for (const std::size_t tokens : {129, 320, 1014}) {
        std::vector<float> hidden(tokens * 768), gate(tokens * 1152);
        for (std::size_t i = 0; i < gate.size(); ++i) gate[i] = (i % 4096) * 0.001f;
        for (std::size_t i = 0; i < hidden.size(); ++i) hidden[i] = (i % 811) * 0.003f;
        TokenPanelsF32 baseline, candidate;
        for (auto* input : {&hidden, &gate}) {
            const auto width = input->size() / tokens;
            baseline.pack(input->data(), tokens, width, width, false);
            candidate.pack(input->data(), tokens, width, width, true);
            for (std::size_t i = 0; i < baseline.panels(); ++i) {
                if (std::memcmp(baseline.panel(i), candidate.panel(i), width * 16 * sizeof(float)))
                    throw std::runtime_error("Vector packing changed output bits");
            }
        }
        for (int pair = 0; pair < 6; ++pair) {
            double before, after;
            if (pair % 2 == 0) {
                before = measure(baseline, hidden.data(), gate.data(), tokens, false, observed);
                after = measure(candidate, hidden.data(), gate.data(), tokens, true, observed);
            } else {
                after = measure(candidate, hidden.data(), gate.data(), tokens, true, observed);
                before = measure(baseline, hidden.data(), gate.data(), tokens, false, observed);
            }
            std::cout << tokens << ',' << pair + 1 << ',' << before << ',' << after << '\n';
        }
    }
}
