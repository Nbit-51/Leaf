import hashlib
import json
from pathlib import Path
import subprocess

from tokenizers import Tokenizer

from tools.benchmark_ollama_decoder import prefix_workloads
from tools.decoder_validation import run_native
from tools.verify_embeddinggemma_reference import digest


work = Path(__file__).resolve().parent
repo = work.parent.parent
source = (work/'decoder_candidate.cpp').read_text(encoding='utf-8')
start = '                    leaf::kernels::attention_f32_gqa_strided_vector(q_heads.data(), cache.keys_data(),'
end = '                } else\n#endif\n                caches[layer].attend'
assert source.count(start) == source.count(end) == 1
left = source.index(start)
right = source.index(end) + len('                } else\n')
replacement = '''                    const float scale = 1.0f / std::sqrt(std::sqrt(static_cast<float>(dim)));
                    auto attend_heads = [&](std::size_t first, std::size_t last) {
                        leaf::kernels::attention_f32_gqa_strided_vector(q_heads.data(), cache.keys_data(),
                            cache.values_data(), mask.data(), attention.data(), 1, heads, kv_heads, tokens,
                            total, cache.capacity(), dim, mask_shape, scale, true, true, first, last);
                    };
                    if (multi_threaded && tokens >= 128 && heads > 1)
                        workers.run(heads, attend_heads, 1);
                    else
                        attend_heads(0, heads);
                } else if (optimized_fp32 && multi_threaded && tokens == 1 && total >= 512 && heads > 1) {
                    const auto& cache = caches[layer];
                    const float scale = 1.0f / std::sqrt(std::sqrt(static_cast<float>(dim)));
                    workers.run(heads, [&](std::size_t first, std::size_t last) {
                        leaf::kernels::attention_f32_gqa_strided(q_heads.data(), cache.keys_data(),
                            cache.values_data(), mask.data(), attention.data(), 1, heads, kv_heads,
                            tokens, total, cache.capacity(), dim, mask_shape, scale, true, first, last);
                    }, 1);
                } else
'''
combined = work/'decoder_combined.cpp'
combined.write_text(source[:left] + replacement + source[right:],encoding='utf-8')
flags = ['g++','-std=c++17','-O3','-DNDEBUG','-pthread','-static','-static-libgcc','-static-libstdc++',
         '-I',str(work/'include'),'-I','engine/include']
obj = work/'decoder_combined.o'
subprocess.run(flags+['-c',str(combined),'-o',str(obj)],check=True)
for entry,exe in (('engine/src/main_decoder.cpp','combined_decoder.exe'),
                  ('benchmark/decoder_generation_benchmark.cpp','combined_adapter.exe')):
    subprocess.run(flags+[str(obj),'engine/src/kv_cache.cpp','engine/src/kernels/transformer.cpp',
                          entry,'-o',str(work/exe),'-lpsapi'],check=True)

snapshot = work.parent/'family-models-20261017/cache/hub/models--HuggingFaceTB--SmolLM2-360M-Instruct/snapshots/a10cc1512eabd3dde888204e902eca88bddb4951'
artifact = work.parent/'ollama-family-20261019/smol/decoder-32.leaf'
tokenizer = Tokenizer.from_file(str(snapshot/'tokenizer.json'))
prompts, _ = prefix_workloads(tokenizer,769)
common = dict(threads=4,worker_cpus=[0,2,4,6],mode='chunked',chunk=768)
digests = []
for exe in ('baseline_decoder.exe','combined_decoder.exe'):
    logits,_ = run_native(work/exe,artifact,[prompts[0]['ids']],**common)
    digests.append(hashlib.sha256(memoryview(logits).cast('B')).hexdigest())
    count = len(logits)
    del logits
assert digests[0]==digests[1]
record = dict(scope='SmolLM2, 768-token prefill plus one cached token. Full FP32 logit bit parity.',
              exact_logits=count, logits_sha256=digests[0], artifact_sha256=digest(artifact),
              combined_decoder_sha256=digest(work/'combined_decoder.exe'),
              combined_adapter_sha256=digest(work/'combined_adapter.exe'),
              combined_source_sha256=digest(combined))
(work/'combined-quality.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('Combined candidate exact logits:',count,flush=True)

runner = (repo/'tools/benchmark_ollama_decoder.py').read_text(encoding='utf-8')
runner = runner.replace('parents[1]', 'parents[2]', 1)
runner = runner.replace('args.pairs < 6', 'args.pairs < 2').replace('args.runs < 11','args.runs < 5')
runner = runner.replace('Require fresh output, even >=6 pairs, >=11 measurements and >=3 warmups',
                        'Require fresh output, even >=2 pairs, >=5 measurements and >=3 warmups')
runner = runner.replace("overall_speed_claim=quality['passed'] and text_matches and all(p['passed'] for p in summary.values())",
                        "diagnostic_screen=True, overall_speed_claim=False")
runner = runner.replace("scope=__doc__, cpu=", "scope='Short matched Ollama screen for candidate selection. No acceptance claim.', cpu=")
(work/'ollama_screen.py').write_text(runner,encoding='utf-8')
