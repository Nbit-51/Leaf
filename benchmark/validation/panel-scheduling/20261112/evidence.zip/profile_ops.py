import json
from pathlib import Path

from tokenizers import Tokenizer

from leaf.power import keep_awake
from tools.benchmark_ollama_decoder import prefix_workloads
from tools.decoder_validation import run_native
from tools.verify_embeddinggemma_reference import digest


work = Path(__file__).resolve().parent
cache = work.parent/'family-models-20261017/cache/hub'
models = {
    'SmolLM2-360M': ('smol', 'models--HuggingFaceTB--SmolLM2-360M-Instruct', 'a10cc1512eabd3dde888204e902eca88bddb4951'),
    'Qwen2.5-0.5B': ('qwen', 'models--Qwen--Qwen2.5-0.5B-Instruct', '7ae557604adf67be50417f59c2c2f167def9a775'),
}
binaries = {side: work/f'{side}_decoder.exe' for side in ('baseline','candidate')}
record = dict(scope='Instrumented phase attribution only. Linear detail and packing timers are nested.',
              threads=4, worker_cpus=[0,2,4,6], measured_passes=3, warmup_passes=1,
              binary_sha256={side:digest(path) for side,path in binaries.items()}, cases=[])
with keep_awake():
    for model,(name,snapshot,revision) in models.items():
        tokenizer = Tokenizer.from_file(str(cache/snapshot/'snapshots'/revision/'tokenizer.json'))
        artifact = work.parent/'ollama-family-20261019'/name/'decoder-32.leaf'
        for tokens in (64,768):
            prompts, _ = prefix_workloads(tokenizer,tokens+1)
            for side,exe in binaries.items():
                _, metrics = run_native(exe,artifact,[prompts[0]['ids']],mode='bench',runs=3,warmup=1,
                    threads=4,worker_cpus=[0,2,4,6],windows_above_normal=True,capture_profile=True)
                profile = metrics['diagnostic_profile']
                shares = {}
                for bucket,values in profile['timings'].items():
                    forward = values['forward']['milliseconds']
                    linear = profile['linear_details'][bucket]
                    percent = {key:100*value['milliseconds']/forward for key,value in values.items() if key!='forward'}
                    percent['pack'] = 100*sum(linear[key]['milliseconds'] for key in ('mlp_pack','other_pack'))/forward
                    percent['mlp'] = 100*linear['mlp_total']['milliseconds']/forward
                    shares[bucket] = dict(forward_ms=forward/values['forward']['calls'], percent=percent)
                record['cases'].append(dict(model=model,tokens=tokens,side=side,phase=shares,raw=profile))
                print(model,tokens,side,[(bucket,round(values['forward_ms'],1),
                    {name:round(values['percent'].get(name,0),1) for name in ('linear_fp32','mlp','attention','pack')})
                    for bucket,values in shares.items()],flush=True)
(work/'decoder-operations.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
