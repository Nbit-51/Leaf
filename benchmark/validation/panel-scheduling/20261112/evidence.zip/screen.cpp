#include "leaf/kernels/row_reuse.h"
#include "leaf/runtime/host_support.h"
#include <chrono>
#include <cstring>
#include <iostream>
#include <random>

using namespace leaf::kernels;
using leaf::runtime::detail::Workers;
using Clock = std::chrono::steady_clock;

void screen(Workers& workers, std::size_t tokens, std::size_t rows, std::size_t columns, bool llms) {
    std::mt19937 random(1415);
    std::uniform_real_distribution<float> sample(-.25f, .25f);
    std::vector<float> x(tokens * columns), w(rows * columns), expected(tokens * rows), y(expected.size());
    for (auto* values : {&x, &w})
        for (auto& value : *values) value = sample(random);
    TokenPanelsF32 panels;
    panels.pack(x.data(), tokens, columns, columns);
    const char* names[] = {"rows32", "rows48", "blocked48", "panels2", "panels4"};
    auto run = [&](int policy) {
        if (policy >= 3) {
            workers.run(panels.panels(), [&](std::size_t begin, std::size_t end) {
                row_reuse_detail::gemm(w.data(), rows, columns, columns, panels,
                                       y.data(), rows, nullptr, begin, end);
            }, policy == 3 ? 2 : 4);
        } else {
            workers.run(rows, [&](std::size_t begin, std::size_t end) {
                const auto kernel = policy == 2 ? gemm_token_panels_f32_kblocked : gemm_token_panels_f32_row_reuse;
                kernel(w.data() + begin * columns, end - begin, columns, columns,
                       panels, y.data() + begin, rows, nullptr, true);
            }, policy == 0 ? 32 : 48);
        }
    };
    run(0);
    expected = y;
    for (int policy = 1; policy < 5; ++policy) {
        std::fill(y.begin(), y.end(), 9876.0f);
        run(policy);
        if (std::memcmp(y.data(), expected.data(), y.size() * sizeof(float)))
            throw std::runtime_error("GEMM output bits differed");
    }
    for (int round = 0; round < 6; ++round) {
        for (int step = 0; step < 5; ++step) {
            const int policy = (round % 2) ? 4 - step : step;
            if (llms && policy != 0 && policy != 3) continue;
            const auto start = Clock::now();
            const int trials = llms ? 3 : 4;
            for (int trial = 0; trial < trials; ++trial) run(policy);
            const auto ms = std::chrono::duration<double, std::milli>(Clock::now() - start).count() / trials;
            std::cout << tokens << ',' << rows << ',' << columns << ',' << round + 1
                      << ',' << names[policy] << ',' << ms << '\n';
        }
    }
}

int main(int argc, char**) {
    if (!token_panel_f32_avx2_available()) return 2;
    Workers workers(4, {0, 2, 4, 6});
    std::cout << "tokens,rows,columns,round,policy,ms\n";
    if (argc > 1) {
        for (const std::size_t tokens : {768, 1014})
            for (const auto shape : {std::pair{960u, 2560u}, std::pair{896u, 4864u}, std::pair{768u, 3072u}}) {
                screen(workers, tokens, shape.second, shape.first, true);
                screen(workers, tokens, shape.first, shape.second, true);
            }
    } else {
        for (const std::size_t tokens : {127, 320, 1014})
            for (const auto shape : {std::pair{768u, 768u}, std::pair{1152u, 768u}, std::pair{768u, 1152u}})
                screen(workers, tokens, shape.first, shape.second, false);
    }
}
