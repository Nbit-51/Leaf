import hashlib
import json
from pathlib import Path
import subprocess
import sys

import numpy as np
from tokenizers import Tokenizer

from leaf.power import keep_awake
from tools.benchmark_ollama_decoder import prefix_workloads
from tools.decoder_validation import latency_stability, run_native
from tools.verify_embeddinggemma_reference import digest


work = Path(__file__).resolve().parent
repeat = 'qwen-repeat' in sys.argv[1:]
repo = work.parent.parent
source = repo / 'engine/src/decoder.cpp'
original = source.read_text(encoding='utf-8')
member = '    Workers workers;'
init = 'workers(threads, worker_cpus), activation_precision(activation_bits)'
anchor = '        workers.run(weight.rows, [&](std::size_t first, std::size_t last) {'
assert original.count(member) == original.count(init) == original.count(anchor) == 1
dispatch = '''#if LEAF_OPTIMIZED_FP32 && defined(__x86_64__) && defined(__GNUC__)
        if (multi_threaded && packed_float && optimized_fp32 && !accurate_fp32 &&
            weight.bits == 32 && tokens >= 768) {
            workers.run(packed_float_input.panels(), [&](std::size_t first, std::size_t last) {
                leaf::kernels::row_reuse_detail::gemm(
                    reinterpret_cast<const float*>(weight.data), weight.rows, weight.cols, weight.cols,
                    packed_float_input, output.data(), weight.rows,
                    bias ? reinterpret_cast<const float*>(bias->data) : nullptr, first, last);
            }, 2);
            return;
        }
#endif
'''
candidate_source = work / 'decoder_candidate.cpp'
candidate_source.write_text(original.replace(member, member + '\n    bool multi_threaded;')
                            .replace(init, 'workers(threads, worker_cpus), multi_threaded(threads > 1), activation_precision(activation_bits)')
                            .replace(anchor, dispatch + anchor), encoding='utf-8')
binaries = {}
for name, path in (('baseline', source), ('candidate', candidate_source)):
    binary = work / f'{name}_decoder.exe'
    if not repeat:
        subprocess.run(['g++', '-std=c++17', '-O3', '-DNDEBUG', '-pthread', '-static',
                        '-static-libgcc', '-static-libstdc++', '-I', 'engine/include', str(path),
                        'engine/src/kv_cache.cpp', 'engine/src/kernels/transformer.cpp',
                        'engine/src/main_decoder.cpp', '-o', str(binary), '-lpsapi'], check=True)
    binaries[name] = binary

model_cache = work.parent / 'family-models-20261017/cache/hub'
artifacts = work.parent / 'ollama-family-20261019'
models = {
    'SmolLM2-360M': ('smol', 'models--HuggingFaceTB--SmolLM2-360M-Instruct', 'a10cc1512eabd3dde888204e902eca88bddb4951'),
    'Qwen2.5-0.5B': ('qwen', 'models--Qwen--Qwen2.5-0.5B-Instruct', '7ae557604adf67be50417f59c2c2f167def9a775'),
}
common = dict(threads=4, worker_cpus=[0, 2, 4, 6], activation_bits=32)
out = work / ('decoder-qwen-repeat.json' if repeat else 'decoder-pilot.json')
report = dict(complete=False, scope='Native FP32 fast path, 768 prefill tokens and one decode token.',
              warmups=2 if repeat else 1,
              binary_sha256={name: digest(path) for name, path in binaries.items()},
              candidate_source_sha256=digest(candidate_source), models={})
if repeat:
    models = {name: model for name, model in models.items() if name.startswith('Qwen')}
    previous = json.loads((work/'decoder-pilot.json').read_bytes())
    assert previous['complete'] and previous['binary_sha256'] == report['binary_sha256']
with keep_awake():
    for label, (folder, cache_key, revision) in models.items():
        artifact = artifacts / folder / 'decoder-32.leaf'
        tokenizer_path = model_cache / cache_key / 'snapshots' / revision / 'tokenizer.json'
        prompts, _ = prefix_workloads(Tokenizer.from_file(str(tokenizer_path)), 769)
        ids = prompts[0]['ids']
        data = dict(artifact_sha256=digest(artifact),
                    input_sha256=hashlib.sha256(np.asarray(ids, dtype='<u4').tobytes()).hexdigest(), pairs=[])
        if repeat:
            checked = previous['models'][label]
            assert checked['logits_bit_identical'] and all(checked[key] == data[key]
                for key in ('artifact_sha256', 'input_sha256'))
            data.update(shape=checked['shape'], logits_bit_identical=True)
        else:
            old, _ = run_native(binaries['baseline'], artifact, [ids], **common)
            new, _ = run_native(binaries['candidate'], artifact, [ids], **common)
            assert np.isfinite(new).all() and np.array_equal(old.view(np.uint32), new.view(np.uint32))
            data.update(shape=list(new.shape), logits_bit_identical=True)
            del old, new
        report['models'][label] = data
        for index in range(6):
            order = ['baseline', 'candidate'] if index % 2 == 0 else ['candidate', 'baseline']
            pair = dict(order=order)
            for side in order:
                _, metrics = run_native(binaries[side], artifact, [ids], mode='bench', runs=5, warmup=report['warmups'],
                                        windows_above_normal=True, **common)
                assert metrics['optimized_fp32_active'] and metrics['benchmark_ac_checked']
                pair[side] = {f'{phase}_samples_ms': metrics[f'{phase}_samples_ms'] for phase in ('prefill', 'decode')}
            data['pairs'].append(pair)
            out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
            print(label, index + 1, *(round(np.median(pair[side]['prefill_samples_ms']), 1) for side in ('baseline', 'candidate')), flush=True)
        data['timing'] = {}
        for phase in ('prefill', 'decode'):
            raw = {side: [pair[side][f'{phase}_samples_ms'] for pair in data['pairs']]
                   for side in ('baseline', 'candidate')}
            baseline, candidate = (np.median(raw[side], axis=1) for side in ('baseline', 'candidate'))
            stable = {side: dict(pooled=latency_stability(sum(samples, [])),
                                 passes=[latency_stability(row) for row in samples])
                      for side, samples in raw.items()}
            data['timing'][phase] = dict(p50_ms=[float(np.median(baseline)), float(np.median(candidate))],
                                         paired_ratio=float(np.median(candidate / baseline)), stability=stable)
        print(label, {phase: values['paired_ratio'] for phase, values in data['timing'].items()}, flush=True)
report['complete'] = True
out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
