import json
from pathlib import Path
import statistics

from tokenizers import Tokenizer

from leaf.power import keep_awake
from tools.benchmark_ollama_decoder import prefix_workloads
from tools.decoder_validation import run_native
from tools.verify_embeddinggemma_reference import digest


work = Path(__file__).resolve().parent
snapshot = work.parent/'family-models-20261017/cache/hub/models--Qwen--Qwen2.5-0.5B-Instruct/snapshots/7ae557604adf67be50417f59c2c2f167def9a775'
artifact = work.parent/'ollama-family-20261019/qwen/decoder-32.leaf'
rows, _ = prefix_workloads(Tokenizer.from_file(str(snapshot/'tokenizer.json')),769)
profiles = json.loads((work/'decoder-operations.json').read_bytes())
work_counts = {}
for name in ('SmolLM2-360M','Qwen2.5-0.5B'):
    cases = [entry for entry in profiles['cases'] if entry['model']==name and entry['tokens']==768]
    assert len(cases)==2
    phase_counts = [{bucket: {phase: (value['calls'],value['tokens']) for phase,value in data.items()}
                     for bucket,data in case['raw']['timings'].items()} for case in cases]
    work_counts[name] = phase_counts[0] == phase_counts[1]
    assert work_counts[name]
report = dict(scope='Instrumented Qwen2.5 768-token prefill and one decode step. Windows process CPU and all page faults.',
              matched_profile_work_counts=work_counts, sides={})
with keep_awake():
    for side in ('baseline','candidate'):
        executable = work/f'{side}_decoder.exe'
        _, stats = run_native(executable,artifact,[rows[0]['ids']],mode='bench',threads=4,
                              worker_cpus=[0,2,4,6],runs=5,warmup=1,
                              windows_above_normal=True,benchmark_counters=True)
        counters = stats['benchmark_counters']['decode']
        values = dict(wall_ms=stats['decode_samples_ms'], process_cpu_ms=counters['process_cpu_ms'],
                      process_cycles=counters['process_cycles'], page_faults=counters['process_page_faults'])
        report['sides'][side] = dict(binary_sha256=digest(executable),values=values,raw=stats,
                                     medians={key:statistics.median(value) for key,value in values.items()})
        print(side,report['sides'][side]['medians'],flush=True)
(work/'decode-counters.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
