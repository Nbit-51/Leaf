import json
from pathlib import Path
import subprocess

import numpy as np
from tokenizers import Tokenizer

from leaf.power import keep_awake
from tools.benchmark_ollama_decoder import prefix_workloads
from tools.decoder_validation import latency_stability, run_native
from tools.verify_embeddinggemma_reference import digest


work = Path(__file__).resolve().parent
source = (work / 'decoder_candidate.cpp').read_text(encoding='utf-8')
old = '        });\n    }\n    void prepare_rotary_tables'
new = '''        }, tokens == 1 && multi_threaded && optimized_fp32 && weight.bits == 32 &&
               weight.rows >= 4096 ? 128 : 32);
    }
    void prepare_rotary_tables'''
assert source.count(old) == 1
candidate_source = work / 'decoder_candidate_grain.cpp'
candidate_source.write_text(source.replace(old, new), encoding='utf-8')
baseline, candidate = work / 'baseline_decoder.exe', work / 'candidate_grain_decoder.exe'
subprocess.run(['g++', '-std=c++17', '-O3', '-DNDEBUG', '-pthread', '-static',
                '-static-libgcc', '-static-libstdc++', '-I', 'engine/include', str(candidate_source),
                'engine/src/kv_cache.cpp', 'engine/src/kernels/transformer.cpp',
                'engine/src/main_decoder.cpp', '-o', str(candidate), '-lpsapi'], check=True)
model_cache = work.parent / 'family-models-20261017/cache/hub'
models = {
    'SmolLM2-360M': ('smol', 'models--HuggingFaceTB--SmolLM2-360M-Instruct', 'a10cc1512eabd3dde888204e902eca88bddb4951'),
    'Qwen2.5-0.5B': ('qwen', 'models--Qwen--Qwen2.5-0.5B-Instruct', '7ae557604adf67be50417f59c2c2f167def9a775'),
}
common = dict(threads=4, worker_cpus=[0,2,4,6], activation_bits=32)
record = dict(complete=False, scope='FP32 64-token prefill, one decode token, above-normal priority and four pinned P-cores.',
              sha256={'baseline':digest(baseline),'candidate':digest(candidate)}, models={})
out = work / 'decode-screen.json'
with keep_awake():
    for name, (folder, snapshot, revision) in models.items():
        artifact = work.parent / 'ollama-family-20261019' / folder / 'decoder-32.leaf'
        tokenizer = Tokenizer.from_file(str(model_cache/snapshot/'snapshots'/revision/'tokenizer.json'))
        prompts, _ = prefix_workloads(tokenizer, 65)
        ids = prompts[0]['ids']
        a,_ = run_native(baseline, artifact, [ids], **common)
        b,_ = run_native(candidate, artifact, [ids], **common)
        assert np.array_equal(a.view(np.uint32), b.view(np.uint32))
        report = dict(bit_identical=True, pairs=[])
        record['models'][name] = report
        for index in range(6):
            order = ['baseline','candidate'] if index % 2 == 0 else ['candidate','baseline']
            pair = dict(order=order)
            for side in order:
                _, stats = run_native(baseline if side == 'baseline' else candidate, artifact, [ids],
                                      mode='bench', runs=5, warmup=2, windows_above_normal=True, **common)
                pair[side] = {f'{phase}_samples_ms': stats[f'{phase}_samples_ms'] for phase in ('prefill','decode')}
            report['pairs'].append(pair)
            out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
        for phase in ('prefill','decode'):
            arrays = [[row[side][phase+'_samples_ms'] for row in report['pairs']] for side in ('baseline','candidate')]
            a,b = (np.median(v,axis=1) for v in arrays)
            report[phase] = dict(ratio=float(np.median(b/a)), pooled=[latency_stability(sum(v,[])) for v in arrays],
                                 max_pass_spread=[max(latency_stability(row)['p90_p10_ratio'] for row in v) for v in arrays])
        print(name, {phase: report[phase] for phase in ('prefill','decode')}, flush=True)
record['complete'] = True
out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
