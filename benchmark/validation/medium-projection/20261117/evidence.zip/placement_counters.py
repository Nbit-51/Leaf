"""Compare the normal process mask with Leaf's existing per-worker placement policy."""
import json
import os
from statistics import median
import tempfile

import psutil

from compare import BEFORE, CORES, MODELS, WORK, fixtures
from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest, utc_now

ORDERS = (("mask","bound"),("bound","mask"),("bound","mask"),("mask","bound"))
WARMUP = 3
RUNS = 5


def summarize(passes):
    result = {}
    for phase in ("prefill","decode"):
        result[phase] = {}
        for policy in ("mask","bound"):
            rows = [p["metrics"] for p in passes if p["policy"] == policy]
            series = [r[phase+"_samples_ms"] for r in rows]
            counters = [r["benchmark_counters"][phase] for r in rows]
            times = sum(series,[])
            cpu = sum([r["process_cpu_ms"] for r in counters],[])
            cycles = sum([r["process_cycles"] for r in counters],[])
            faults = sum([r["process_page_faults"] for r in counters],[])
            result[phase][policy] = dict(
                time_range_ms=[min(times),max(times)], pooled_p50_ms=median(times),
                pooled=latency_stability(times), per_pass=[latency_stability(x) for x in series],
                median_process_cpu_ms=median(cpu), median_process_cycles=median(cycles),
                cpu_to_wall_range=[min(c/t for c,t in zip(cpu,times)),max(c/t for c,t in zip(cpu,times))],
                samples_with_faults=sum(f > 0 for f in faults),
            )
    return result


def main():
    tempfile.tempdir = str(WORK)
    prior = json.loads((WORK/"warmup-faults.json").read_bytes())
    assert prior["complete"] and prior["power_mode"]["passed"]
    artifact,tokens = fixtures(MODELS["SmolLM2-360M"])
    assert digest(BEFORE) == prior["binary_sha256"] and digest(artifact) == prior["artifact_sha256"]
    out = WORK/"placement-counters.json"
    record = dict(complete=False, power_mode={}, passes=[], orders=ORDERS, runs=RUNS, warmup=WARMUP,
                  affinity=CORES, binary_sha256=prior["binary_sha256"], artifact_sha256=prior["artifact_sha256"],
                  scope=__doc__, prefill_tokens=384)
    parent = psutil.Process()
    original = parent.cpu_affinity()
    try:
        parent.cpu_affinity(CORES)
        assert parent.cpu_affinity() == CORES
        os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
        with keep_awake(), benchmark_power_mode_guard(record["power_mode"],required_mode="better-battery"):
            for number,order in enumerate(ORDERS,1):
                for policy in order:
                    cpus = CORES if policy == "bound" else None
                    entry = dict(round=number,policy=policy,started_at_utc=utc_now(),
                                 ac_before=require_benchmark_ac())
                    _, metrics = run_native(BEFORE,artifact,[tokens[:385]],mode="bench",threads=4,
                                            worker_cpus=cpus,runs=RUNS,warmup=WARMUP,benchmark_counters=True)
                    assert metrics["benchmark_ac_checked"] and metrics["avx2"] and metrics["threads"] == 4
                    assert metrics["worker_cpus"] == (cpus or [])
                    assert metrics["worker_spin_us"] == (50 if cpus else 0)
                    entry.update(metrics=metrics,ac_after=require_benchmark_ac(),ended_at_utc=utc_now())
                    record["passes"].append(entry)
                    write_record(out,record)
                    wall = metrics["prefill_samples_ms"]
                    print(number,policy,round(median(wall),2),round(min(wall),2),round(max(wall),2),flush=True)
        record["summary"] = summarize(record["passes"])
        record["complete"] = True
    finally:
        parent.cpu_affinity(original)
        write_record(out,record)


if __name__ == "__main__":
    main()
