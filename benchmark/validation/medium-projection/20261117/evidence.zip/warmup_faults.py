"""Locate recurrent page faults by absolute inference iteration across fresh processes."""
import json
import os
from pathlib import Path
from statistics import median
import tempfile

import psutil

from compare import BEFORE, CORES, MODELS, OUTPUT, WORK, fixtures
from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest, utc_now

ORDERS = ((0, 1, 3), (3, 0, 1), (1, 3, 0))
TOTAL_ITERATIONS = 9
PHASES = ("prefill", "decode")


def describe(passes):
    summaries = {}
    for warmup in (0, 1, 3):
        group = [item for item in passes if item["warmup"] == warmup]
        summaries[str(warmup)] = {}
        for phase in PHASES:
            samples = [row for item in group for row in item[phase]]
            times = [row["ms"] for row in samples]
            faults = [row for row in samples if row["faults"] > 0]
            fault_free = [row["ms"] for row in samples if row["faults"] == 0]
            summaries[str(warmup)][phase] = dict(
                sample_count=len(samples), p50_ms=median(times), range_ms=[min(times),max(times)],
                faults_by_launch=[[row["faults"] for row in item[phase]] for item in group],
                fault_iterations=sorted({row["iteration"] for row in faults}),
                largest_fault_count=max(row["faults"] for row in samples),
                fault_free_count=len(fault_free),
                fault_free_range_ms=[min(fault_free),max(fault_free)] if fault_free else None,
                pooled_stability=latency_stability(times),
            )
    return summaries


def main():
    tempfile.tempdir = str(WORK)
    prior = json.loads(OUTPUT.read_bytes())
    artifact, tokens = fixtures(MODELS["SmolLM2-360M"])
    tokens = tokens[:385]
    identity = digest(BEFORE)
    artifact_identity = digest(artifact)
    assert prior["complete"] and prior["power_mode"]["passed"]
    assert identity == prior["binaries"]["before"] == prior["binaries"]["control"]
    assert artifact_identity == prior["cases"]["SmolLM2-360M"]["artifact_sha256"]
    assert tokens == prior["cases"]["SmolLM2-360M"]["tokens"][:385]
    report = dict(complete=False, power_mode={}, binary_sha256=identity,
                  artifact_sha256=artifact_identity, affinity=CORES, threads=4,
                  model="SmolLM2-360M", prefill_tokens=384, orders=ORDERS,
                  total_iterations_per_launch=TOTAL_ITERATIONS, passes=[])
    output = WORK/"warmup-faults.json"
    parent = psutil.Process()
    original = parent.cpu_affinity()
    try:
        parent.cpu_affinity(CORES)
        assert parent.cpu_affinity() == CORES
        os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
        with keep_awake(), benchmark_power_mode_guard(report["power_mode"],required_mode="better-battery"):
            for number,order in enumerate(ORDERS,1):
                for warmup in order:
                    runs = TOTAL_ITERATIONS - warmup
                    item = dict(round=number,warmup=warmup,runs=runs,started_at_utc=utc_now(),
                                ac_before=require_benchmark_ac())
                    _, result = run_native(BEFORE,artifact,[tokens],mode="bench",threads=4,
                                           runs=runs,warmup=warmup,benchmark_counters=True)
                    assert result["benchmark_ac_checked"] and result["avx2"]
                    assert result["threads"] == 4 and result["source_bf16_linear_calls"] > 0
                    item.update(ac_after=require_benchmark_ac(), ended_at_utc=utc_now())
                    for phase in PHASES:
                        time = result[phase+"_samples_ms"]
                        counters = result["benchmark_counters"][phase]
                        assert len(time) == runs
                        item[phase] = [dict(iteration=warmup+i+1,ms=ms,
                            faults=counters["process_page_faults"][i],
                            cpu_ms=counters["process_cpu_ms"][i],
                            cycles=counters["process_cycles"][i])
                            for i,ms in enumerate(time)]
                    report["passes"].append(item)
                    write_record(output,report)
                    rows = item["prefill"]
                    print(number,warmup,round(median(row["ms"] for row in rows),2),
                          [(row["iteration"],row["faults"]) for row in rows],flush=True)
        assert digest(BEFORE) == identity and digest(artifact) == artifact_identity
        report["summary"] = describe(report["passes"])
        report["complete"] = True
    finally:
        parent.cpu_affinity(original)
        write_record(output,report)


if __name__ == "__main__":
    main()
