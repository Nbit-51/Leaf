"""Print the paired ratios and largest same-binary timing swing."""
import json
from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parent
report = json.loads((root / "projection-comparison.json").read_bytes())
for model, case in report["cases"].items():
    for length, result in case["timings"].items():
        if not result.get("summary"):
            continue
        for phase, stats in result["summary"].items():
            ratios = [median(row["control"][phase]) / median(row["before"][phase])
                      for row in result["rounds"]]
            largest = max(max(ratio, 1/ratio) for ratio in ratios)
            spreads = [s["pooled"]["p90_p10_ratio"] for s in stats["stability"].values()]
            print(model, length, phase, 
                  "paired", [round(v,3) for v in stats["paired_ratios"].values()],
                  "max-A/A-fold", round(largest,3),
                  "pooled-spreads", [round(v,3) for v in spreads], "passed", stats["passed"])
