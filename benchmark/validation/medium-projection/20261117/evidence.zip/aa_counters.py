"""Record CPU accounting for repeated launches of an identical decoder."""
import json
import os
from statistics import median
import tempfile

import psutil

from compare import BEFORE, CORES, MODELS, OUTPUT, WORK, fixtures
from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake
from tools.decoder_validation import run_native
from tools.validate_decoder import digest

tempfile.tempdir = str(WORK)
previous = json.loads(OUTPUT.read_bytes())
assert previous["complete"] and previous["power_mode"]["passed"]
assert digest(BEFORE) == previous["binaries"]["before"]
artifact, tokens = fixtures(MODELS["SmolLM2-360M"])
record = dict(complete=False, power_mode={}, binary_sha256=digest(BEFORE),
              model="SmolLM2-360M", prefill_tokens=384, passes=[])

parent = psutil.Process()
original = parent.cpu_affinity()
try:
    parent.cpu_affinity(CORES)
    assert parent.cpu_affinity() == CORES
    os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
    with keep_awake(), benchmark_power_mode_guard(record["power_mode"],required_mode="better-battery"):
        for index in range(3):
            _, result = run_native(BEFORE, artifact, [tokens[:385]], mode="bench", threads=4,
                                   runs=5, warmup=1, benchmark_counters=True)
            assert result["benchmark_ac_checked"]
            record["passes"].append(result)
            write_record(WORK/"aa-counters.json",record)
            phase = result["benchmark_counters"]["prefill"]
            print(index + 1, {"wall_ms":round(median(result["prefill_samples_ms"]), 2),
                              "process_cpu_ms":round(median(phase["process_cpu_ms"]), 2),
                              "median_process_cycles":median(phase["process_cycles"]),
                              "median_page_faults":median(phase["process_page_faults"])},flush=True)
    record["complete"] = True
finally:
    parent.cpu_affinity(original)
    write_record(WORK/"aa-counters.json",record)
