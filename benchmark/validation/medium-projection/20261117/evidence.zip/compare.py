"""Isolate earlier source-BF16 projection scheduling with an identical-binary control."""
from hashlib import sha256
import json
import os
from pathlib import Path
from statistics import median
import tempfile

import numpy as np
import psutil

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest


WORK = Path(__file__).resolve().parent
FIXTURES = WORK.parent / "presentation-20261115"
OUTPUT = WORK / "projection-comparison.json"
BEFORE = WORK / "before.exe"
CANDIDATE = WORK / "candidate.exe"
BINARIES = {"before": BEFORE, "control": BEFORE, "candidate": CANDIDATE}
MODELS = {"SmolLM2-360M": "smol", "Qwen2.5-0.5B": "qwen"}
LENGTHS = (384, 512, 767)
CHECK_LENGTHS = (383, 384, 767, 768)
ORDERS = (
    ("before", "control", "candidate"),
    ("candidate", "control", "before"),
    ("control", "candidate", "before"),
    ("before", "candidate", "control"),
)
CORES = [0, 2, 4, 6]
RUNS = 5
WARMUP = 1


def fixtures(slug):
    artifact = FIXTURES / f"{slug}-source-bf16/decoder-32-source-bf16.leaf"
    data = FIXTURES / f"release-candidate/{slug}-tokens.json"
    tokens = json.loads(data.read_bytes())["benchmark_ids"]
    assert len(tokens) >= max(CHECK_LENGTHS) + 1
    return artifact, tokens


def check_model(artifact, tokens):
    comparisons = {}
    for length in CHECK_LENGTHS:
        values = []
        for executable in (BEFORE, CANDIDATE):
            logits, _ = run_native(executable, artifact, [tokens[:length + 1]],
                                   mode="chunked", threads=4, chunk=length)
            assert logits.size and np.isfinite(logits).all()
            values.append(dict(count=int(logits.size), sha256=sha256(memoryview(logits).cast("B")).hexdigest()))
            del logits
        assert values[0] == values[1], (length, values)
        comparisons[str(length)] = values[0]
    generation = [run_native(exe, artifact, [tokens[:512]], mode="generate", threads=4,
                             generate=16)[1]["generated_tokens"] for exe in (BEFORE, CANDIDATE)]
    assert generation[0] and generation[0] == generation[1]
    return dict(logits=comparisons, continuation=generation[0])


def summary(rounds, phase):
    measured = {name: [row[name][phase] for row in rounds] for name in BINARIES}
    pooled = {name: sum(samples, []) for name, samples in measured.items()}
    medians = {name: [median(sample) for sample in samples] for name, samples in measured.items()}
    before, control, candidate = (medians[name] for name in BINARIES)
    ratios = {
        "control_vs_before": median(c / b for b, c in zip(before, control)),
        "candidate_vs_before": median(a / b for b, a in zip(before, candidate)),
        "candidate_vs_control": median(a / c for c, a in zip(control, candidate)),
    }
    stability = {name: dict(pooled=latency_stability(pooled[name]),
                            rounds=[latency_stability(sample) for sample in measured[name]])
                 for name in BINARIES}
    stable = all(s["pooled"]["passed"] and all(r["passed"] for r in s["rounds"])
                 for s in stability.values())
    limit = .98 if phase == "prefill" else 1.02
    return dict(p50_ms={name: median(samples) for name, samples in pooled.items()},
                paired_ratios=ratios, stability=stability, stable=stable,
                passed=stable and ratios["candidate_vs_before"] <= limit and ratios["candidate_vs_control"] <= limit)


def main():
    tempfile.tempdir = str(WORK)
    identities = {name: digest(executable) for name, executable in BINARIES.items()}
    assert identities["before"] == identities["control"] != identities["candidate"]
    report = dict(complete=False, binaries=identities, power_mode={}, cases={},
                  affinity=CORES, lengths=LENGTHS, check_lengths=CHECK_LENGTHS,
                  runs=RUNS, warmup=WARMUP, before_projection_tokens=768,
                  candidate_projection_tokens=384, attention_tokens=768)
    parent = psutil.Process()
    original = parent.cpu_affinity()
    try:
        parent.cpu_affinity(CORES)
        assert parent.cpu_affinity() == CORES
        for model, slug in MODELS.items():
            artifact, tokens = fixtures(slug)
            case = report["cases"][model] = dict(artifact_sha256=digest(artifact),
                                                 tokens=tokens, checks={}, timings={})
            case["checks"] = check_model(artifact, tokens)
            write_record(OUTPUT, report)
            print(model, "bit-identical logits at all four boundaries and the tested continuation", flush=True)

        os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
        with keep_awake(), benchmark_power_mode_guard(report["power_mode"], required_mode="better-battery"):
            for model, slug in MODELS.items():
                artifact, tokens = fixtures(slug)
                case = report["cases"][model]
                for length in LENGTHS:
                    result = case["timings"][str(length)] = dict(rounds=[])
                    orders = ORDERS if length == 512 else ORDERS[:2]
                    for order in orders:
                        row = dict(order=order)
                        for name in order:
                            _, metrics = run_native(BINARIES[name], artifact, [tokens[:length + 1]], mode="bench",
                                                    threads=4, runs=RUNS, warmup=WARMUP)
                            assert metrics["benchmark_ac_checked"] and metrics["avx2"]
                            assert metrics["source_bf16_linear_calls"] > 0
                            row[name] = dict(prefill=metrics["prefill_samples_ms"],
                                             decode=metrics["decode_samples_ms"],
                                             peak_rss_bytes=metrics["peak_rss_bytes"])
                        result["rounds"].append(row)
                        print(model, length, len(result["rounds"]),
                              {name: round(median(row[name]["prefill"]), 1) for name in order}, flush=True)
                        write_record(OUTPUT, report)
                    result["summary"] = {phase: summary(result["rounds"], phase) for phase in ("prefill", "decode")}
                    write_record(OUTPUT, report)
                assert case["artifact_sha256"] == digest(artifact)
        assert identities == {name: digest(exe) for name, exe in BINARIES.items()}
        report["complete"] = True
    finally:
        parent.cpu_affinity(original)
        write_record(OUTPUT, report)


if __name__ == "__main__":
    main()
