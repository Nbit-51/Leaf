from pathlib import Path

work = Path("build/medium-gemm-20261116")
source = (work/"decoder-batched.cpp").read_text(encoding="utf-8")
anchor = """        if (packed_float && parallel_bf16 && weight.bits == 16 && mlp_projection &&
            tokens >= 128 && tokens < parallel_prefill_tokens) {
            // A task owns disjoint output channels. Expand its local BF16 rows
            // once, then reuse each K slice of the packed activations across rows.
            constexpr std::size_t rows_per_task = 48;"""
candidate = """        constexpr std::size_t bf16_prefill_rows_per_task = 48;
        constexpr std::size_t bf16_prefill_scratch_bytes = 1024 * 1024;
        if (packed_float && parallel_bf16 && weight.bits == 16 && mlp_projection &&
            tokens >= 128 && tokens <= 192 &&
            weight.cols <= bf16_prefill_scratch_bytes / (sizeof(float) * bf16_prefill_rows_per_task)) {
            // Expand one worker's output rows together, retaining full-K FP32
            // accumulation and the existing token-major output layout."""
assert source.count(anchor) == 1
source = source.replace(anchor,candidate).replace("}, rows_per_task);", "}, bf16_prefill_rows_per_task);")
(work/"decoder-narrow.cpp").write_text(source, encoding="utf-8")
