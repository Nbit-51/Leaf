"""Compare two bounded source-BF16 MLP candidates with the unmodified decoder."""
import hashlib
from itertools import permutations
import json
import os
from pathlib import Path
from statistics import median
import tempfile

import numpy as np
import psutil

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest


work = Path(__file__).resolve().parent
build = work.parent
tempfile.tempdir = str(work)
binaries = {name: work/f"{name}.exe" for name in ("before", "batched", "kblocked")}
prev = build/"presentation-20261115"
smol = json.loads((build/"ollama-validation-20261116/smol-256-16-latest/comparison.json").read_bytes())["workload"][0]["ids"]
qwen = json.loads((prev/"release-candidate/qwen-tokens.json").read_bytes())["benchmark_ids"]
models = {
    "SmolLM2-360M": (prev/"smol-source-bf16/decoder-32-source-bf16.leaf", [*smol, smol[0]]),
    "Qwen2.5-0.5B": (prev/"qwen-source-bf16/decoder-32-source-bf16.leaf", qwen),
}
report = dict(complete=False, affinity=[0,2,4,6], power_mode={}, cases={},
              binaries={name:digest(exe) for name,exe in binaries.items()},
              check_lengths=[127,128,256], timing=dict(length=256, runs=5, warmup=2,
                                                        prefill_limit=.98, decode_limit=1.02))
output = work/"comparison.json"


def summarize(passes, phase, variant):
    series = {key:[entry[key][phase] for entry in passes] for key in ("before",variant)}
    pooled = {key:sum(rows,[]) for key,rows in series.items()}
    detail = {key:dict(p50_ms=median(values), pooled=latency_stability(values),
                       passes=[latency_stability(r) for r in series[key]]) for key,values in pooled.items()}
    ratio = median(median(a)/median(b) for b,a in zip(series["before"],series[variant]))
    stable = all(d["pooled"]["passed"] and all(p["passed"] for p in d["passes"]) for d in detail.values())
    return dict(detail=detail, paired_ratio=ratio, stable=stable,
                passed=stable and ratio<=report["timing"][phase+"_limit"])


def exact_digest(logits):
    assert np.isfinite(logits).all()
    return dict(count=int(logits.size), sha256=hashlib.sha256(memoryview(logits).cast("B")).hexdigest())


process = psutil.Process()
original = process.cpu_affinity()
try:
    process.cpu_affinity(report["affinity"])
    assert process.cpu_affinity() == report["affinity"]
    if os.getenv("LEAF_RESUME_GEMM_TIMING") == "1":
        previous = json.loads(output.read_bytes())
        assert previous["binaries"] == report["binaries"]
        assert previous["check_lengths"] == report["check_lengths"]
        for name,(artifact,_) in models.items():
            case = previous["cases"][name]
            assert case["artifact_sha256"] == digest(artifact) and not case["passes"]
            assert set(case["logits"]) == {str(length) for length in report["check_lengths"]}
            assert case["continuation"]
        report["cases"] = previous["cases"]
    for name,(artifact,seq) in models.items():
        if name in report["cases"]:
            continue
        case = dict(artifact_sha256=digest(artifact), logits={}, passes=[])
        report["cases"][name] = case
        for length in report["check_lengths"]:
            assert len(seq) >= length+1
            actual = [exact_digest(run_native(exe,artifact,[seq[:length+1]],mode="chunked",
                                   threads=4,chunk=length,fp32_math="fast")[0]) for exe in binaries.values()]
            assert all(values == actual[0] for values in actual), (name,length,actual)
            case["logits"][str(length)] = actual[0]
        tokens = [run_native(exe,artifact,[seq[:256]],mode="generate",generate=16,
                            threads=4,fp32_math="fast")[1]["generated_tokens"] for exe in binaries.values()]
        assert tokens[0] and all(t == tokens[0] for t in tokens), (name,tokens)
        case["continuation"] = tokens[0]
        print(name, "identical logits and continuations", flush=True)
        write_record(output,report)
    os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
    with keep_awake(), benchmark_power_mode_guard(report["power_mode"],required_mode="better-battery"):
        for name,(artifact,seq) in models.items():
            case = report["cases"][name]
            for index,order in enumerate(permutations(binaries), 1):
                entry = dict(order=order)
                for side in order:
                    _, m = run_native(binaries[side],artifact,[seq[:257]],mode="bench",threads=4,
                                      runs=report["timing"]["runs"],warmup=report["timing"]["warmup"],fp32_math="fast")
                    assert m["benchmark_ac_checked"] and m["avx2"] and m["source_bf16_linear_calls"] > 0
                    entry[side] = dict(prefill=m["prefill_samples_ms"],decode=m["decode_samples_ms"],
                                       peak_rss_bytes=m["peak_rss_bytes"])
                case["passes"].append(entry)
                print(name,index, {side:round(median(entry[side]["prefill"]),2) for side in binaries}, flush=True)
                write_record(output,report)
            case["summary"] = {variant:{phase:summarize(case["passes"],phase,variant)
                               for phase in ("prefill","decode")} for variant in ("batched","kblocked")}
            assert case["artifact_sha256"] == digest(artifact)
    assert report["binaries"] == {name:digest(exe) for name,exe in binaries.items()}
    report["complete"] = True
finally:
    process.cpu_affinity(original)
    write_record(output,report)
