"""Confirm a bounded BF16 batching path on a narrow range of prompt lengths."""
import hashlib
import json
import os
from pathlib import Path
from statistics import median
import tempfile

import numpy as np
import psutil

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest

work = Path(__file__).resolve().parent
build = work.parent
tempfile.tempdir = str(work)
prev = build/"presentation-20261115"
binaries = {"before":work/"before.exe","after":work/"narrow.exe"}
lengths = (128,160,192)
check_lengths = (127,128,160,192,193)
report = dict(complete=False, power_mode={}, cases={}, affinity=[0,2,4,6],
              runs=5,warmup=2,lengths=lengths,check_lengths=check_lengths,
              binaries={name:digest(exe) for name,exe in binaries.items()})
output = work/"narrow.json"
models = {"SmolLM2-360M":"smol","Qwen2.5-0.5B":"qwen"}


def result(passes, phase):
    rows = {side:[entry[side][phase] for entry in passes] for side in binaries}
    pooled = {side:sum(values,[]) for side,values in rows.items()}
    limit = .98 if phase == "prefill" else 1.02
    stable = all(latency_stability(group)["passed"] for series in (*rows.values(), list(pooled.values()))
                 for group in series)
    ratio = median(median(a)/median(b) for b,a in zip(rows["before"],rows["after"]))
    return dict(medians_ms={side:median(values) for side,values in pooled.items()},
                paired_ratio=ratio,stable=stable,passed=stable and ratio<=limit)


def fixture(slug):
    artifact = prev/f"{slug}-source-bf16/decoder-32-source-bf16.leaf"
    seq = json.loads((prev/f"release-candidate/{slug}-tokens.json").read_bytes())["benchmark_ids"]
    return artifact,seq


def logits_digest(values):
    assert np.isfinite(values).all()
    return dict(count=int(values.size),sha256=hashlib.sha256(memoryview(values).cast("B")).hexdigest())


parent = psutil.Process()
original = parent.cpu_affinity()
try:
    parent.cpu_affinity(report["affinity"])
    assert parent.cpu_affinity() == report["affinity"]
    for name,slug in models.items():
        artifact,seq = fixture(slug)
        case = report["cases"][name] = dict(artifact_sha256=digest(artifact),logits={},timings={})
        for length in check_lengths:
            rows = [logits_digest(run_native(exe,artifact,[seq[:length+1]],mode="chunked",threads=4,
                                  fp32_math="fast",chunk=length)[0]) for exe in binaries.values()]
            assert rows[0] == rows[1], (name,length,rows)
            case["logits"][str(length)] = rows[0]
        tokens = [run_native(exe,artifact,[seq[:160]],mode="generate",generate=16,
                            threads=4,fp32_math="fast")[1]["generated_tokens"] for exe in binaries.values()]
        assert tokens[0] and tokens[0] == tokens[1]
        case["continuation"] = tokens[0]
        print(name,"narrow build matches logits and continuation",flush=True)
        write_record(output,report)

    os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
    with keep_awake(), benchmark_power_mode_guard(report["power_mode"],required_mode="better-battery"):
        for name,slug in models.items():
            artifact,seq = fixture(slug)
            case = report["cases"][name]
            for length in lengths:
                timing = case["timings"][str(length)] = dict(passes=[])
                for order in (("before","after"),("after","before"),("after","before"),("before","after")):
                    entry = dict(order=order)
                    for side in order:
                        _, measurements = run_native(binaries[side],artifact,[seq[:length+1]],mode="bench",
                                                     threads=4,runs=report["runs"],warmup=report["warmup"],fp32_math="fast")
                        assert measurements["benchmark_ac_checked"] and measurements["avx2"]
                        assert measurements["source_bf16_linear_calls"] > 0
                        entry[side] = dict(prefill=measurements["prefill_samples_ms"],
                                           decode=measurements["decode_samples_ms"],
                                           peak_rss_bytes=measurements["peak_rss_bytes"])
                    timing["passes"].append(entry)
                    write_record(output,report)
                timing["summary"] = {phase:result(timing["passes"],phase) for phase in ("prefill","decode")}
                print(name,length,timing["summary"],flush=True)
                write_record(output,report)
    report["complete"] = True
finally:
    parent.cpu_affinity(original)
    write_record(output,report)
