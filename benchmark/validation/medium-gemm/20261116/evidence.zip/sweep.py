"""Screen both projection variants at additional prompt lengths."""
import json
import os
from pathlib import Path
from statistics import median
import tempfile

import psutil

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest

work = Path(__file__).resolve().parent
build = work.parent
tempfile.tempdir = str(work)
prev = build/"presentation-20261115"
binaries = {name:work/f"{name}.exe" for name in ("before","batched","kblocked")}
models = {"SmolLM2-360M":"smol", "Qwen2.5-0.5B":"qwen"}
previous = json.loads((work/"comparison.json").read_bytes())
identities = {name:digest(exe) for name,exe in binaries.items()}
assert previous["complete"] and previous["binaries"] == identities
lengths = (64,128,256,384,512,768)
orders = (("before","batched","kblocked"), ("kblocked","batched","before"))
report = dict(complete=False, binaries=identities, affinity=previous["affinity"],
              runs=5, warmup=1, lengths=lengths, power_mode={}, cases={})
output = work/"length-sweep.json"


def result(passes, phase, variant):
    rows = {side:[entry[side][phase] for entry in passes] for side in ("before",variant)}
    pooled = {side:sum(values,[]) for side,values in rows.items()}
    return dict(medians_ms={side:median(values) for side,values in pooled.items()},
                paired_ratio=median(median(a)/median(b) for b,a in zip(rows["before"],rows[variant])),
                pooled_spread={side:latency_stability(values)["p90_p10_ratio"] for side,values in pooled.items()},
                stable=all(latency_stability(group)["passed"] for series in (*rows.values(), list(pooled.values()))
                           for group in series))


parent = psutil.Process()
original = parent.cpu_affinity()
try:
    parent.cpu_affinity(report["affinity"])
    assert parent.cpu_affinity() == report["affinity"]
    os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
    with keep_awake(), benchmark_power_mode_guard(report["power_mode"],required_mode="better-battery"):
        for name,slug in models.items():
            artifact = prev/f"{slug}-source-bf16/decoder-32-source-bf16.leaf"
            assert previous["cases"][name]["artifact_sha256"] == digest(artifact)
            seq = json.loads((prev/f"release-candidate/{slug}-tokens.json").read_bytes())["benchmark_ids"]
            assert len(seq) >= max(lengths)+1
            cases = report["cases"][name] = {}
            for length in lengths:
                case = cases[str(length)] = dict(passes=[])
                for order in (orders if length in (64,384,768) else reversed(orders)):
                    entry = dict(order=order)
                    for side in order:
                        _, m = run_native(binaries[side],artifact,[seq[:length+1]],mode="bench",threads=4,
                                          runs=report["runs"],warmup=report["warmup"],fp32_math="fast")
                        assert m["benchmark_ac_checked"] and m["avx2"] and m["source_bf16_linear_calls"] > 0
                        entry[side] = dict(prefill=m["prefill_samples_ms"],decode=m["decode_samples_ms"],
                                           peak_rss_bytes=m["peak_rss_bytes"])
                    case["passes"].append(entry)
                    write_record(output,report)
                case["summary"] = {side:{phase:result(case["passes"],phase,side)
                                   for phase in ("prefill","decode")} for side in binaries if side != "before"}
                print(name,length,{side:{phase:round(data["paired_ratio"],3) for phase,data in phases.items()}
                                  for side,phases in case["summary"].items()},flush=True)
                write_record(output,report)
    report["complete"] = True
finally:
    parent.cpu_affinity(original)
    write_record(output,report)
