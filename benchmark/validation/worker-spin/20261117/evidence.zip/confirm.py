"""Confirm the spin-wait comparison on bound workers with counters disabled."""
import json
import os
from statistics import median
import tempfile

import psutil

from factorial import CORES, EXE, MODELS, SWITCH, WORK, fixture, run
from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.decoder_validation import latency_stability
from tools.validate_decoder import digest, utc_now

ORDERS = (("bound-no-spin","bound-spin"),("bound-spin","bound-no-spin"))


def summarize(rounds,phase):
    runs = {policy:[row[policy][phase] for row in rounds] for policy in ORDERS[0]}
    medians = {policy:median(sum(rows,[])) for policy,rows in runs.items()}
    ratios = [median(a)/median(b) for b,a in zip(*runs.values())]
    checks = {policy:dict(pooled=latency_stability(sum(rows,[])),
                          per_pass=[latency_stability(r) for r in rows]) for policy,rows in runs.items()}
    return dict(p50_ms=medians,paired_spin_ratio=median(ratios),checks=checks)


def main():
    tempfile.tempdir = str(WORK)
    screening = json.loads((WORK/"factorial.json").read_bytes())
    assert screening["complete"] and screening["power_mode"]["passed"]
    identity = digest(EXE)
    assert screening["binaries"]["diagnostic"] == identity
    report = dict(complete=False,power_mode={},cpus=CORES,binary_sha256=identity,
                  prefill_tokens=384,runs=5,warmup=3,orders=ORDERS,cases={})
    output = WORK/"bound-confirm.json"
    process = psutil.Process()
    affinity = process.cpu_affinity()
    previous = os.environ.get(SWITCH)
    try:
        process.cpu_affinity(CORES)
        assert process.cpu_affinity() == CORES
        os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
        with keep_awake(),benchmark_power_mode_guard(report["power_mode"],required_mode="better-battery"):
            for name,slug in MODELS.items():
                artifact,tokens = fixture(slug)
                assert digest(artifact) == screening["cases"][name]["artifact_sha256"]
                case = report["cases"][name] = dict(rounds=[])
                for order in ORDERS:
                    row = dict(order=order)
                    for policy in order:
                        start = utc_now()
                        require_benchmark_ac()
                        _, metrics = run(policy,artifact,tokens[:385],mode="bench",
                                         runs=report["runs"],warmup=report["warmup"])
                        assert "benchmark_counters" not in metrics
                        assert metrics["benchmark_ac_checked"] and metrics["avx2"]
                        require_benchmark_ac()
                        row[policy] = dict(prefill=metrics["prefill_samples_ms"],decode=metrics["decode_samples_ms"],
                                           start=start,end=utc_now())
                        print(name,policy,round(median(row[policy]["prefill"]),2),flush=True)
                    case["rounds"].append(row)
                    write_record(output,report)
                case["summary"] = {phase:summarize(case["rounds"],phase) for phase in ("prefill","decode")}
                write_record(output,report)
        assert identity == digest(EXE)
        report["complete"] = True
    finally:
        process.cpu_affinity(affinity)
        if previous is not None:
            os.environ[SWITCH] = previous
        else:
            os.environ.pop(SWITCH,None)
        write_record(output,report)


if __name__ == "__main__":
    main()
