"""Factorial check of worker binding and spin-wait behavior in one native build."""
from hashlib import sha256
import json
import os
from pathlib import Path
from statistics import median
import tempfile

import numpy as np
import psutil

from leaf.evaluation import write_record
from leaf.power import benchmark_power_mode_guard, keep_awake, require_benchmark_ac
from tools.decoder_validation import latency_stability, run_native
from tools.validate_decoder import digest, utc_now

WORK = Path(__file__).resolve().parent
BUILD = WORK.parent
BASE = BUILD/"medium-projection-20261117"/"before.exe"
EXE = WORK/"spin.exe"
MODELS = {"SmolLM2-360M":"smol","Qwen2.5-0.5B":"qwen"}
CORES = [0,2,4,6]
SWITCH = "LEAF_DIAGNOSTIC_WORKER_SPIN_US"
POLICIES = {"mask-no-spin":(False,0), "mask-spin":(False,50),
            "bound-no-spin":(True,0), "bound-spin":(True,50)}
ORDERS = (
    ("mask-no-spin","mask-spin","bound-no-spin","bound-spin"),
    ("bound-spin","bound-no-spin","mask-spin","mask-no-spin"),
)
LENGTHS = (64,384)


def fixture(slug):
    saved = BUILD/"presentation-20261115"
    artifact = saved/f"{slug}-source-bf16/decoder-32-source-bf16.leaf"
    tokens = json.loads((saved/f"release-candidate/{slug}-tokens.json").read_bytes())["benchmark_ids"]
    return artifact,tokens


def run(policy,artifact,seq,*,threads=4,**options):
    bound, spin = POLICIES[policy]
    cpus = CORES[:threads] if bound else None
    os.environ[SWITCH] = str(spin)
    result,metrics = run_native(EXE,artifact,[seq],threads=threads,worker_cpus=cpus,**options)
    assert metrics["worker_cpus"] == (cpus or [])
    assert metrics["worker_spin_us"] == (spin if threads > 1 else 0)
    assert metrics["threads"] == threads
    return result,metrics


def fingerprint(array):
    assert array.size and np.isfinite(array).all()
    return {"count":int(array.size),"sha256":sha256(memoryview(array).cast("B")).hexdigest()}


def quality(artifact,tokens):
    checks = {}
    for length in LENGTHS:
        seq = tokens[:length+1]
        values,_ = run_native(BASE,artifact,[seq],mode="chunked",threads=4,chunk=length)
        control = fingerprint(values)
        del values
        for policy in POLICIES:
            values,_ = run(policy,artifact,seq,mode="chunked",chunk=length)
            assert fingerprint(values) == control, (policy,length)
            del values
        checks[str(length)] = control
    raw = [run_native(BASE,artifact,[tokens[:64]],mode="generate",threads=n,generate=8)[1]["generated_tokens"]
           for n in (1,2,4)]
    for threads, expected in zip((1,2,4),raw):
        assert expected
        for policy in POLICIES:
            _, metrics = run(policy,artifact,tokens[:64],mode="generate",threads=threads,generate=8)
            assert metrics["generated_tokens"] == expected, (threads,policy)
    return {"logits":checks,"continuations":dict(zip((1,2,4),raw))}


def summarize(rows,phase):
    result = {}
    for policy in POLICIES:
        metrics = [row[policy]["metrics"] for row in rows]
        samples = [m[phase+"_samples_ms"] for m in metrics]
        pooled = sum(samples,[])
        result[policy] = dict(
            p50_ms=median(pooled),range_ms=[min(pooled),max(pooled)],
            pooled=latency_stability(pooled),per_pass=[latency_stability(sample) for sample in samples],
            process_cpu_ms=median(x for m in metrics for x in m["benchmark_counters"][phase]["process_cpu_ms"]),
            faulted_samples=sum(n>0 for m in metrics for n in m["benchmark_counters"][phase]["process_page_faults"]),
        )
    return result


def main():
    tempfile.tempdir = str(WORK)
    output = WORK/"factorial.json"
    parent = psutil.Process()
    affinity = parent.cpu_affinity()
    previous = os.environ.get(SWITCH)
    binaries = {"baseline":digest(BASE),"diagnostic":digest(EXE)}
    report = dict(complete=False, power_mode={}, cpus=CORES, binaries=binaries,
                  policies=POLICIES, orders=ORDERS, runs=5, warmup=3, cases={})
    try:
        parent.cpu_affinity(CORES)
        assert parent.cpu_affinity() == CORES
        for name,slug in MODELS.items():
            artifact,tokens = fixture(slug)
            case = report["cases"][name] = dict(artifact_sha256=digest(artifact),timing={})
            case["quality"] = quality(artifact,tokens)
            print(name,"all four policies matched logits and 1/2/4-thread continuations",flush=True)
            write_record(output,report)

        os.environ["LEAF_BENCHMARK_REQUIRE_AC"] = "1"
        with keep_awake(), benchmark_power_mode_guard(report["power_mode"],required_mode="better-battery"):
            for name,slug in MODELS.items():
                artifact,tokens = fixture(slug)
                case = report["cases"][name]
                for length in LENGTHS:
                    section = case["timing"][str(length)] = dict(rounds=[])
                    for index,order in enumerate(ORDERS,1):
                        row = dict(order=order)
                        for policy in order:
                            start = utc_now()
                            require_benchmark_ac()
                            _, metrics = run(policy,artifact,tokens[:length+1],mode="bench",
                                             runs=report["runs"],warmup=report["warmup"],benchmark_counters=True)
                            assert metrics["benchmark_ac_checked"] and metrics["avx2"]
                            assert metrics["source_bf16_linear_calls"] > 0
                            require_benchmark_ac()
                            row[policy] = dict(metrics=metrics,start=start,end=utc_now())
                            print(name,length,index,policy,round(median(metrics["prefill_samples_ms"]),2),flush=True)
                        section["rounds"].append(row)
                        write_record(output,report)
                    section["summary"] = {phase:summarize(section["rounds"],phase) for phase in ("prefill","decode")}
                    write_record(output,report)
                assert case["artifact_sha256"] == digest(artifact)
        assert binaries == {"baseline":digest(BASE),"diagnostic":digest(EXE)}
        report["complete"] = True
    finally:
        parent.cpu_affinity(affinity)
        if previous is None:
            os.environ.pop(SWITCH,None)
        else:
            os.environ[SWITCH] = previous
        write_record(output,report)


if __name__ == "__main__":
    main()
